"""Repackage the signed original 228; change Android installation version only."""
from pathlib import Path
import copy, hashlib, json, re, struct, subprocess, sys, tempfile, zipfile, os

ROOT = Path(__file__).resolve().parent
BASE = Path(sys.argv[1]).resolve()
BACKUP = Path(sys.argv[2]).resolve()
CONFIG = json.loads((ROOT / 'build-config.json').read_text())
TOOLS = Path(CONFIG['build_tools'])
OUT = ROOT / 'out'
DELIVER = ROOT / 'deliverables'
OUT.mkdir(exist_ok=True)
DELIVER.mkdir(exist_ok=True)
DEST = DELIVER / 'FlipCheck237-228-originale.apk'
CERT = 'cf7cb81d2bcb16fd34b4e8ed87691d586417a579b5723a3d8d97cfd77386f04c'
BASE_SHA = '378afebddb171845f90fb55ce53e0ec13be7a0f968136966343669d9456964ad'
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(BASE.read_bytes()) == BASE_SHA

def u16(data, at): return struct.unpack_from('<H', data, at)[0]
def u32(data, at): return struct.unpack_from('<I', data, at)[0]

def string_pool(data, at):
    count = u32(data, at + 8)
    start = at + u32(data, at + 20)
    flags = u32(data, at + 16)
    header = u16(data, at + 2)
    result = []
    for index in range(count):
        pos = start + u32(data, at + header + index * 4)
        if flags & 256:
            def length(p):
                value = data[p]
                return ((((value & 127) << 8) | data[p + 1]), p + 2) if value & 128 else (value, p + 1)
            _, pos = length(pos)
            size, pos = length(pos)
            encoding = 'utf-8'
        else:
            size = u16(data, pos)
            pos += 2
            if size & 32768:
                size = ((size & 32767) << 16) | u16(data, pos)
                pos += 2
            size *= 2
            encoding = 'utf-16le'
        result.append((data[pos:pos + size].decode(encoding), pos, size, encoding))
    return result

def signature_entry(name):
    return name.startswith('META-INF/') and name.endswith(('.SF', '.RSA', '.DSA', '.EC', '.MF'))

with zipfile.ZipFile(BASE) as original:
    assert original.testzip() is None
    manifest = original.read('AndroidManifest.xml')
    patched = bytearray(manifest)
    at = 8
    table = None
    version_at = None
    while at < len(patched):
        kind, size = u16(patched, at), u32(patched, at + 4)
        assert size >= 8
        if kind == 1:
            table = string_pool(patched, at)
        if kind == 258 and table[u32(patched, at + 20)][0] == 'manifest':
            start = at + 16 + u16(patched, at + 24)
            width, count = u16(patched, at + 26), u16(patched, at + 28)
            for index in range(count):
                pos = start + index * width
                name = table[u32(patched, pos + 4)][0]
                if name == 'versionCode':
                    assert version_at is None and patched[pos + 15] == 16 and u32(patched, pos + 16) == 359
                    version_at = pos + 16
                    struct.pack_into('<I', patched, version_at, 368)
                elif name == 'versionName':
                    assert table[u32(patched, pos + 16)][0] == '2.31-test228'
        at += size
    assert version_at is not None
    old_names = [entry for entry in table if entry[0] == '2.31-test228']
    assert len(old_names) == 1
    _, name_at, name_size, encoding = old_names[0]
    new_name = '2.31-test237'.encode(encoding)
    assert len(new_name) == name_size
    patched[name_at:name_at + name_size] = new_name
    diff = [pos for pos, (a, b) in enumerate(zip(manifest, patched)) if a != b]
    permitted = set(range(version_at, version_at + 4)) | set(range(name_at, name_at + name_size))
    assert diff and set(diff).issubset(permitted) and len(manifest) == len(patched)
    (OUT / 'AndroidManifest.xml').write_bytes(patched)
    with zipfile.ZipFile(OUT / 'unsigned.apk', 'w') as output:
        for entry in original.infolist():
            if signature_entry(entry.filename):
                continue
            data = bytes(patched) if entry.filename == 'AndroidManifest.xml' else original.read(entry.filename)
            output.writestr(copy.copy(entry), data)

subprocess.run([str(TOOLS / 'zipalign'), '-P', '16', '-f', '4', str(OUT / 'unsigned.apk'), str(OUT / 'aligned.apk')], check=True)
try:
    os.chmod(BACKUP, 0o600)
    with tempfile.TemporaryDirectory(prefix='flipcheck368-sign-', dir='/tmp') as directory:
        private = Path(directory)
        os.chmod(private, 0o700)
        with zipfile.ZipFile(BACKUP) as archive:
            for name in ['flipcheck-release.p12', 'password.txt']:
                target = private / name
                target.write_bytes(archive.read(name))
                os.chmod(target, 0o600)
        keypass = private / 'key-password.txt'
        keypass.write_bytes((private / 'password.txt').read_bytes())
        os.chmod(keypass, 0o600)
        signed = private / 'signed.apk'
        result = subprocess.run([
            'java', '-XX:-UsePerfData', '-jar', str(TOOLS / 'lib/apksigner.jar'), 'sign',
            '--ks', str(private / 'flipcheck-release.p12'), '--ks-type', 'PKCS12', '--ks-key-alias', 'flipcheck',
            '--ks-pass', 'file:' + str(private / 'password.txt'), '--key-pass', 'file:' + str(keypass),
            '--v1-signing-enabled', 'true', '--v2-signing-enabled', 'true', '--v3-signing-enabled', 'true',
            '--v4-signing-enabled', 'false', '--out', str(signed), str(OUT / 'aligned.apk')
        ], capture_output=True)
        if result.returncode:
            raise RuntimeError('Signing failed; private diagnostics withheld')
        ready = DEST.with_suffix('.ready')
        ready.write_bytes(signed.read_bytes())
        assert sha(ready.read_bytes()) == sha(signed.read_bytes())
        ready.replace(DEST)
finally:
    BACKUP.unlink(missing_ok=True)

def verify(apk):
    result = subprocess.run(['java', '-XX:-UsePerfData', '-jar', str(TOOLS / 'lib/apksigner.jar'),
        'verify', '--verbose', '--print-certs', str(apk)], capture_output=True, text=True, check=True)
    assert re.search(r'Signer #1 certificate SHA-256 digest: ' + CERT, result.stdout)
    for version in [1, 2, 3]:
        assert re.search(r'Verified using v' + str(version) + r' scheme.*: true', result.stdout)
    return result.stdout

verify(BASE)
(OUT / 'signature-verification.txt').write_text(verify(DEST))
subprocess.run([str(TOOLS / 'zipalign'), '-c', '-P', '16', '4', str(DEST)], check=True)
package = subprocess.run([str(TOOLS / 'aapt'), 'dump', 'badging', str(DEST)], capture_output=True, text=True, check=True).stdout.splitlines()[0]
assert "versionCode='368'" in package and "versionName='2.31-test237'" in package
with zipfile.ZipFile(BASE) as original, zipfile.ZipFile(DEST) as final:
    assert final.testzip() is None
    original_names = {n for n in original.namelist() if not signature_entry(n)}
    final_names = {n for n in final.namelist() if not signature_entry(n)}
    assert original_names == final_names
    changed = sorted(n for n in original_names if original.read(n) != final.read(n))
    assert changed == ['AndroidManifest.xml']
    assert final.read('AndroidManifest.xml') == bytes(patched)
    dex_hashes = {name: sha(final.read(name)) for name in sorted(final_names) if name.endswith('.dex')}
    assert dex_hashes['classes.dex'] == '4d8856a67f875780a71fac7d3a7930e7777f058d04195613a3325d398aca62f7'
    identical = len(original_names) - 1
audit = {
    'status': 'PASS', 'base_apk_sha256': BASE_SHA, 'base': '2.31-test228',
    'version': '2.31-test237', 'version_code': 368, 'package': package,
    'apk': DEST.name, 'apk_sha256': sha(DEST.read_bytes()), 'apk_bytes': DEST.stat().st_size,
    'changed_payloads': changed, 'identical_payload_count': identical,
    'manifest_allowed_changes': ['android:versionCode', 'android:versionName'],
    'manifest_changed_offsets': diff, 'manifest_version_code_offset': version_at,
    'manifest_version_name_offset': name_at, 'manifest_version_name_size': name_size,
    'dex_sha256': dex_hashes, 'all_dex_exact_original228': True,
    'all_assets_native_resources_exact_original228': True,
    'prompt_schema_model_controller_prices_ui_unchanged': True,
    'closure_v361_not_added': True, 'certificate_sha256': CERT,
    'signature_schemes': [1, 2, 3], 'zipalign_16kb': True,
    'version368_installation_upgrade_over367': True,
    'internal_diagnostic_and_ui_labels_retained_from_original228': True,
    'phone_installation_tested': False, 'live_api_calls': 0
}
(OUT / 'repackage-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps(audit, indent=2))
