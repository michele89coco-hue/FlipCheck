"""Repackage original build 228 using a temporary copy of its signing backup."""
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--signing-backup", type=Path, required=True)
    parser.add_argument("--build-tools", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    base = args.base.resolve(strict=True)
    backup = args.signing_backup.resolve(strict=True)
    tools = args.build_tools.resolve(strict=True)
    output = args.output.resolve()
    if output.exists():
        parser.error("The output file already exists; choose a new path")
    for name in ("aapt", "zipalign", "lib/apksigner.jar"):
        if not (tools / name).is_file():
            parser.error("Missing Android Build Tools file: " + name)
    source = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix="flipcheck237-rebuild-") as temp:
        work = Path(temp)
        private_backup = work / "signing-backup.zip"
        shutil.copyfile(backup, private_backup)
        os.chmod(private_backup, 0o600)
        shutil.copyfile(source / "repackage237.py", work / "repackage237.py")
        (work / "build-config.json").write_text(json.dumps({"build_tools": str(tools)}))
        subprocess.run([sys.executable, str(work / "repackage237.py"), str(base), str(private_backup)], check=True)
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(work / "deliverables/FlipCheck237-228-originale.apk", output)
        shutil.copyfile(work / "out/repackage-audit.json", output.with_suffix(".verification.json"))
    print("APK created: " + str(output))


if __name__ == "__main__":
    main()
