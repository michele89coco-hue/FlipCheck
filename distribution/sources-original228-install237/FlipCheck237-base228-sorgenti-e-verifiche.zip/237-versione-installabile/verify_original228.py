"""Independent read-only audit: original 228 payload with Android version 237/368."""
from pathlib import Path
import hashlib
import json
import re
import struct
import subprocess
import sys
import zipfile

BASE_SHA = "378afebddb171845f90fb55ce53e0ec13be7a0f968136966343669d9456964ad"
DEX_SHA = "4d8856a67f875780a71fac7d3a7930e7777f058d04195613a3325d398aca62f7"
CERT_SHA = "cf7cb81d2bcb16fd34b4e8ed87691d586417a579b5723a3d8d97cfd77386f04c"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def u16(data, at):
    return struct.unpack_from("<H", data, at)[0]


def u32(data, at):
    return struct.unpack_from("<I", data, at)[0]


def manifest_fields(data):
    """Read version attributes from the binary manifest without decoding/rebuilding it."""
    assert u16(data, 0) == 3 and u32(data, 4) == len(data)
    pool = None
    versions = {}
    at = u16(data, 2)
    while at < len(data):
        kind, header_size, chunk_size = struct.unpack_from("<HHI", data, at)
        assert chunk_size >= header_size >= 8 and at + chunk_size <= len(data)
        if kind == 1:
            count = u32(data, at + 8)
            flags = u32(data, at + 16)
            start = at + u32(data, at + 20)
            pool = []
            for index in range(count):
                pos = start + u32(data, at + header_size + index * 4)
                if flags & 256:
                    def read_len(pos):
                        first = data[pos]
                        if first & 128:
                            return (first & 127) * 256 + data[pos + 1], pos + 2
                        return first, pos + 1
                    _, pos = read_len(pos)
                    n, pos = read_len(pos)
                    width, encoding = n, "utf-8"
                else:
                    n = u16(data, pos)
                    pos += 2
                    if n & 32768:
                        n = ((n & 32767) << 16) | u16(data, pos)
                        pos += 2
                    width, encoding = 2 * n, "utf-16le"
                pool.append({"text": data[pos:pos + width].decode(encoding),
                             "offset": pos, "size": width, "encoding": encoding})
        elif kind == 258:
            assert pool is not None
            node = pool[u32(data, at + 20)]["text"]
            attrs = at + 16 + u16(data, at + 24)
            width, count = u16(data, at + 26), u16(data, at + 28)
            if node == "manifest":
                for i in range(count):
                    attr = attrs + i * width
                    name = pool[u32(data, attr + 4)]["text"]
                    if name not in ("versionCode", "versionName"):
                        continue
                    assert name not in versions
                    assert pool[u32(data, attr)]["text"] == "http://schemas.android.com/apk/res/android"
                    value_type = data[attr + 15]
                    typed_value = u32(data, attr + 16)
                    if name == "versionCode":
                        assert value_type == 16
                        versions[name] = {"value": typed_value, "offset": attr + 16, "size": 4}
                    else:
                        assert value_type == 3
                        versions[name] = dict(pool[typed_value])
        at += chunk_size
    assert at == len(data) and set(versions) == {"versionCode", "versionName"}
    return versions


def payload_name(name):
    return not (name.startswith("META-INF/") and name.endswith((".SF", ".RSA", ".DSA", ".EC", ".MF")))


def run(args):
    result = subprocess.run(args, check=True, capture_output=True, text=True)
    return result.stdout


base, final, config_path, report_path = map(Path, sys.argv[1:5])
config = json.loads(config_path.read_text())
tool_root = Path(config["build_tools"])
checks = 0
assert sha(base.read_bytes()) == BASE_SHA
checks += 1
with zipfile.ZipFile(base) as old, zipfile.ZipFile(final) as new:
    assert old.testzip() is None and new.testzip() is None
    assert len(old.namelist()) == len(set(old.namelist()))
    assert len(new.namelist()) == len(set(new.namelist()))
    checks += 3
    original_names = {n for n in old.namelist() if payload_name(n)}
    final_names = {n for n in new.namelist() if payload_name(n)}
    assert original_names == final_names
    checks += 1
    changed = []
    unchanged = 0
    dex_hashes = {}
    for name in sorted(original_names):
        before, after = old.read(name), new.read(name)
        if before == after:
            unchanged += 1
        else:
            changed.append(name)
            assert name == "AndroidManifest.xml", "Unexpected payload change: " + name
        checks += 1
        if re.fullmatch(r"classes\d*\.dex", name):
            assert before == after
            dex_hashes[name] = sha(after)
            checks += 1
    assert changed == ["AndroidManifest.xml"]
    assert dex_hashes["classes.dex"] == DEX_SHA
    checks += 2
    before, after = old.read("AndroidManifest.xml"), new.read("AndroidManifest.xml")
    old_fields, new_fields = manifest_fields(before), manifest_fields(after)
    assert old_fields["versionCode"]["value"] == 359
    assert new_fields["versionCode"]["value"] == 368
    assert old_fields["versionName"]["text"] == "2.31-test228"
    assert new_fields["versionName"]["text"] == "2.31-test237"
    checks += 4
    allowed = set()
    for field in ("versionCode", "versionName"):
        assert old_fields[field]["offset"] == new_fields[field]["offset"]
        assert old_fields[field]["size"] == new_fields[field]["size"]
        allowed.update(range(old_fields[field]["offset"], old_fields[field]["offset"] + old_fields[field]["size"]))
        checks += 2
    assert len(before) == len(after)
    expected = bytearray(before)
    struct.pack_into("<I", expected, old_fields["versionCode"]["offset"], 368)
    name_field = old_fields["versionName"]
    offset, width = name_field["offset"], name_field["size"]
    expected[offset:offset + width] = "2.31-test237".encode(name_field["encoding"])
    assert bytes(expected) == after
    diff_offsets = [index for index, (a, b) in enumerate(zip(before, after)) if a != b]
    assert set(diff_offsets) <= allowed
    checks += 3

signature_reports = {}
for label, path in (("base228", base), ("repack237", final)):
    output = run(["java", "-XX:-UsePerfData", "-jar", str(tool_root / "lib/apksigner.jar"),
                  "verify", "--verbose", "--print-certs", str(path)])
    assert re.search(r"Signer #1 certificate SHA-256 digest: " + CERT_SHA, output)
    assert "Number of signers: 1" in output
    for scheme in (1, 2, 3):
        assert re.search(r"Verified using v" + str(scheme) + r" scheme.*: true", output)
        checks += 1
    checks += 2
    signature_reports[label] = output

run([str(tool_root / "zipalign"), "-c", "-P", "16", "4", str(final)])
checks += 1
badging = run([str(tool_root / "aapt"), "dump", "badging", str(final)]).splitlines()[0]
assert "versionCode='368'" in badging and "versionName='2.31-test237'" in badging
checks += 1
report = {
    "status": "PASS_INDEPENDENT_ORIGINAL228_VERSION_ONLY",
    "assertions": checks,
    "base_apk_sha256": BASE_SHA,
    "final_apk_sha256": sha(final.read_bytes()),
    "final_apk_bytes": final.stat().st_size,
    "changed_payload_entries": changed,
    "unchanged_payload_entries": unchanged,
    "manifest_changed_byte_offsets": diff_offsets,
    "manifest_exactly_version_only": True,
    "version_code_from_to": [359, 368],
    "version_name_from_to": ["2.31-test228", "2.31-test237"],
    "dex_payload_hashes_identical_to_original228": dex_hashes,
    "all_assets_and_native_payloads_identical": True,
    "original_internal228_labels_preserved": True,
    "signer_certificate_sha256": CERT_SHA,
    "same_original_certificate": True,
    "apk_signature_schemes": [1, 2, 3],
    "zipalign_16kb": True,
    "aapt_package": badging,
    "new_phone_scans": 0,
    "live_api_calls": 0,
}
report_path.parent.mkdir(parents=True, exist_ok=True)
report_path.write_text(json.dumps(report, indent=2) + "\n")
(report_path.parent / "independent-signature-reports.json").write_text(json.dumps(signature_reports, indent=2) + "\n")
print(json.dumps(report, indent=2))
