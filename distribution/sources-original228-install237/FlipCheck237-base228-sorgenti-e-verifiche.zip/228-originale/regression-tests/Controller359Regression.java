package com.flipcheck.nativebeta;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONArray;
import org.json.JSONObject;

/** Integration replay: complete probable identities, sourced estimates and native fast gates. */
public final class Controller359Regression {
 static int checks,network;static boolean finalDex;
 static JSONArray cases=new JSONArray();static JSONObject zoro,trade,lugia,bulba,oldLugia;
 static JSONObject o(JSONObject r,String k){return CatalogEvidenceV150.obj(r,k);}
 static JSONObject cp(JSONObject r)throws Exception{return new JSONObject(r.toString());}
 static String hash(JSONObject r)throws Exception{return ObservedIdentityV309.hash(r);}
 static void ok(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
 static JSONObject load(String path)throws Exception{return new JSONObject(new String(Files.readAllBytes(Paths.get(path)),StandardCharsets.UTF_8));}
 static JSONObject decision(JSONObject r){return o(o(r,ControllerCompletionV358.KEY),"decision");}
 static JSONObject target(JSONObject r){return o(o(r,"result"),"identity");}
 static JSONObject quote(JSONObject r){return o(o(r,"market_presentation"),"current");}
 static void item(String name,String status)throws Exception{cases.put(new JSONObject().put("case",name).put("status",status));}
 static void save(String name,JSONObject r)throws Exception{
  String text=r.toString(2);ok(!text.matches("(?s).*(?:AIza[A-Za-z0-9_-]{20,}|AQ\\.[A-Za-z0-9_-]{20,}|sk-proj-[A-Za-z0-9_-]{20,}).*"),"No credential token in output "+name);
  Files.createDirectories(Paths.get("work359/regression-tests/output"));Files.write(Paths.get("work359/regression-tests/output",name+".json"),text.getBytes(StandardCharsets.UTF_8));
 }
 static JSONObject publish(JSONObject initial)throws Exception{JSONObject r=cp(initial);ReviewerV354.publish(r);ControllerCompletionV358.finalSave(r);return r;}
 static void probable()throws Exception{
  for(boolean isZoro:new boolean[]{true,false}){
   JSONObject initial=isZoro?zoro:trade,r=publish(initial),d=decision(r),id=target(r),q=quote(r);
   String name=isZoro?"zoro":"trade",originalHash=hash(ControllerV348.original(initial));
   ok(ControllerCompletionV358.active(r)&&"PROVISIONAL".equals(d.optString("outcome")),name+" has terminal probable identity");
   ok(d.optInt("policy_revision")==359,name+" migrated to current policy");
   ok(!ControllerCompletionV358.exact(r)&&!FinalIdentityV319.active(r),name+" remains without an exact identity seal");
   ok(!d.optBoolean("identity_verified")&&!d.optBoolean("exact_printing_verified"),name+" confidence not fabricated");
   ok("JPN".equals(id.optString("language"))&&"RAW".equals(id.optString("state")),name+" photo language and state preserved");
   ok("2022".equals(id.optString("year"))==isZoro,name+" probable year complete");
   ok(isZoro?"2022".equals(id.optString("year")):"1998".equals(id.optString("year")),name+" retains correct probable release year");
   ok(isZoro?"One Piece Japanese Romance Dawn".equals(id.optString("set")):"Unnumbered Promos".equals(id.optString("set")),name+" probable set restored");
   ok(isZoro?"OP01-025".equals(id.optString("card_number")):id.optString("card_number").isEmpty(),name+" collector number/absence preserved");
   ok(isZoro?id.optString("variant").contains("Alternate Art"):"Non-Holo".equals(id.optString("variant")),name+" visible finish preserved");
   ok(isZoro?"8508433".equals(o(d,"reference_candidate").optString("catalog_id")):"202942".equals(o(d,"reference_candidate").optString("catalog_id")),name+" selected identity reference correct");
   ok(Math.abs(q.optDouble("amount")-(isZoro?52.62:282.75))<0.005,name+" correct probable estimate");
   ok("EUR".equals(q.optString("currency")),name+" recorded FX produces explicit euro quote");
   ok(isZoro?"8508433".equals(q.optString("catalog_id")):"5154287".equals(q.optString("catalog_id")),name+" price source correctly selected");
   ok(q.optBoolean("provisional_identity")&&!q.optBoolean("exact_identity_bound"),name+" price remains explicitly approximate");
   ok(!q.optBoolean("prices_are_live")&&q.optString("catalog_snapshot_date").length()==10,name+" snapshot freshness is preserved truthfully");
   ok(q.optString("qualification").contains("identità più probabile"),name+" price notice states probable identity");
   ok(!q.optBoolean("indicative_grade")&&!q.optString("qualification").contains("stesso grader"),name+" RAW quote is not mislabeled as a graded comparison");
   if(!isZoro)ok(q.optBoolean("price_reference_only")&&q.optString("qualification").contains("senza equivalenza esatta"),"Trade CT identity and PC reference not asserted equivalent");
   ok(originalHash.equals(hash(ControllerV348.original(r))),name+" source observations unchanged");
   ok(r.getJSONArray("requests").toString().equals(initial.getJSONArray("requests").toString()),name+" no request added or modified");
   String firstTarget=hash(id),firstDecision=hash(d),firstHypothesis=hash(o(d,"hypothesis"));double amount=q.optDouble("amount");
   for(int n=0;n<3;n++){ReviewerV354.publish(r);ControllerV348.sync(r,"LATE_PRICE_PUBLICATION");ControllerV348.finish(r);}
   ok(firstTarget.equals(hash(target(r))),name+" repeated native publication retains full identity");
   ok(firstDecision.equals(hash(decision(r)))&&firstHypothesis.equals(hash(o(decision(r),"hypothesis"))),name+" immutable probable decision stable");
   ok(amount==quote(r).optDouble("amount"),name+" repeated publication retains probable money");
   ok(o(r,ControllerCompletionV358.KEY).has("previous_policy_decision"),name+" old227 decision archived during migration");
   ok(o(o(r,ControllerCompletionV358.KEY),"policy_migration").optInt("additional_api_calls")==0,name+" migration performs no APIs");
   save("probable-"+name,r);item("full_probable_"+name,"PROVISIONAL_WITH_SOURCED_ESTIMATE");
  }
 }
 static void exact()throws Exception{
  for(int index=0;index<3;index++){
   JSONObject initial=index==0?lugia:index==1?bulba:oldLugia,r=cp(initial);
   String name=index==0?"lugia227":index==1?"bulbasaur226":"lugia226",seal=hash(o(r,"controller_final_v351")),identity=hash(ControllerV348.target(r)),money=hash(quote(r));
   ok(ControllerCompletionV358.exact(r),name+" exact source fixture has native proof");
   ReviewerV354.publish(r);ControllerCompletionV358.finalSave(r);ControllerV348.sync(r,"UNCHANGED_EXACT");
   ok(ControllerCompletionV358.exact(r)&&"VERIFIED_EXACT".equals(decision(r).optString("outcome")),name+" exact identity not downgraded");
   ok(seal.equals(hash(o(r,"controller_final_v351")))&&identity.equals(hash(ControllerV348.target(r))),name+" seal and exact target untouched");
   ok(money.equals(hash(quote(r))),name+" exact quote untouched");
   if(index==0)ok(quote(r).optDouble("amount")==169.85,"Actual exact Lugia EUR169.85 preserved");
   if(index==1)ok(quote(r).optDouble("amount")==200.44,"Actual exact Bulbasaur EUR200.44 preserved");
   ok(!QuickIdentityV359.fastReviewPolicy(r),name+" exact identity not reranked into hypothesis");
   save("exact-"+name,r);item("unchanged_exact_"+name,"VERIFIED_EXACT");
  }
 }
 static JSONObject oneRow(JSONObject original,JSONObject row)throws Exception{
  JSONObject r=cp(original),a=o(r,ControllerAlgorithmsV355.KEY);r.remove("charting_selection");r.remove("charting_result");r.remove("catalog_snapshot_products_v284");r.remove("cardtrader_visual_v168");
  a.put("candidates",new JSONArray().put(row));a.put("ranking",new JSONObject().put("candidates",new JSONArray().put(cp(row))));
  a.put("candidate_sha256",hash(new JSONObject().put("rows",a.getJSONArray("candidates")))).put("hypothesis_sha256",hash(o(a,"ranking")));
  r.put(ControllerAlgorithmsV355.KEY,a);return r;
 }
 static void priceGuards()throws Exception{
  JSONObject h=IdentityHypothesisV359.hypothesis(zoro),base=o(h,"row");
  for(String defect:new String[]{"wrong_number","wrong_name","wrong_game","wrong_language"}){
   JSONObject row=cp(base);
   if(defect.equals("wrong_number"))row.put("product-name","Roronoa Zoro [Alternate Art] OP01-026");
   if(defect.equals("wrong_name"))row.put("product-name","Monkey D. Luffy [Alternate Art] OP01-025");
   if(defect.equals("wrong_game"))row.put("console-name","Pokemon Japanese Romance Dawn").put("game","Pokemon");
   if(defect.equals("wrong_language"))row.put("page_language","ENG").put("language","ENG").put("console-name","One Piece Romance Dawn");
   JSONObject r=oneRow(zoro,row),bad=IdentityHypothesisV359.hypothesis(r);
   ok(bad.optString("catalog_id").isEmpty(),"Conflicting "+defect+" not selected as probable catalog identity");
   ok(PriceHypothesisV359.quote(r,bad).length()==0,"Conflicting "+defect+" cannot produce fabricated quote");
   ok(!QuickIdentityV359.fastReviewPolicy(r),"Conflicting "+defect+" cannot bypass model review with a price");
   item("price_guard_"+defect,"REJECTED");
  }
  JSONObject wrong=cp(h).put("original_sha256","changed");ok(PriceHypothesisV359.quote(zoro,wrong).length()==0,"Changed evidence hash rejects probable quote");
  wrong=cp(zoro).put("scan_id","new-scan");ok(PriceHypothesisV359.quote(wrong,h).length()==0,"Other scan cannot borrow a hypothesis price");
  JSONObject unknown=cp(h);o(unknown,"target").put("state","SLAB").put("grader","").put("grade","");
  ok(PriceHypothesisV359.quote(zoro,unknown).length()==0,"Unknown slab grade does not receive raw or fabricated graded quote");
  JSONObject noFx=cp(zoro);noFx.remove("market_fx");JSONObject usd=PriceHypothesisV359.quote(noFx,h);
  ok("USD".equals(usd.optString("currency"))&&usd.optDouble("amount")==58.95,"Missing FX keeps USD58.95, never invents EUR");
  PriceHypothesisV359.publish(noFx,h);
  ok("USD".equals(o(o(noFx,"result"),"market").optString("currency"))&&o(o(noFx,"result"),"market").optDouble("current_estimate")==58.95,"Publication preserves quote currency and magnitude for UI");
  ReviewerV354.publish(noFx);ControllerCompletionV358.finalSave(noFx);
  ok(decision(noFx).optInt("policy_revision")==359&&"USD".equals(quote(noFx).optString("currency"))&&quote(noFx).optDouble("amount")==58.95,"Full terminal migration preserves USD when recorded FX is missing");
  save("probable-zoro-usd-no-fx",noFx);item("missing_currency_conversion","USD_PRESERVED");
  JSONObject negative=cp(h);o(negative,"row").put("loose-price",-1);ok(PriceHypothesisV359.quote(zoro,negative).length()==0,"Negative source amount not fabricated into positive estimate");
 }
 static JSONObject beforeReview(JSONObject initial)throws Exception{
  JSONObject r=cp(initial).put("state","MARKET_RUNNING");r.remove(ControllerCompletionV358.KEY);r.remove(ControllerRuntimeV353.WAIT);
  r.remove("second_identity_call");r.remove("cardtrader_visual_v168");
  o(r,ControllerV348.KEY).put("state","NEEDS_EVIDENCE").put("next_action","COMPARE_EXISTING_REFERENCES");
  o(r,ControllerAlgorithmsV355.KEY).put("review_attempts",0).put("review_running",false).put("next_action","COMPARE_EXISTING_REFERENCES");
  o(r,"controller_authority_v350").put("model_reviews_started",0).put("review_limit",1);
  JSONArray requests=new JSONArray(),original=r.optJSONArray("requests");for(int i=0;original!=null&&i<original.length();i++)if(!"catalog_variant_verification".equals(original.getJSONObject(i).optString("phase")))requests.put(original.getJSONObject(i));
  r.put("requests",requests);return r;
 }
 static JSONObject primaryModelFixture()throws Exception{
  JSONObject r=cp(zoro);
  for(String field:new String[]{ControllerCompletionV358.KEY,ControllerAlgorithmsV355.KEY,ControllerV348.KEY,ControllerDecisionV349.KEY,"charting_selection","charting_result","catalog_snapshot_products_v284","cardtrader_visual_v168","ai_estimate"})r.remove(field);
  r.put("market_presentation",new JSONObject()).put("controlled_regression_fixture",true);o(r,"result").remove("market");o(r,"result").put("sources",new JSONArray());
  JSONObject raw=ControllerV348.original(r);
  raw.put("market_estimate",new JSONObject().put("basis","MODEL_ESTIMATE").put("currency","EUR").put("low",40).put("high",80)
   .put("state","RAW").put("grader","").put("grade",""));
  return r;
 }
 static void primaryModelEstimate()throws Exception{
  JSONObject r=primaryModelFixture(),h=IdentityHypothesisV359.hypothesis(r),q=PriceHypothesisV359.quote(r,h);
  if(q.length()==0)System.out.println(new JSONObject().put("primary_model_scope",ObservationGraphV348.id(ControllerV348.original(r))).put("hypothesis_scope",o(h,"target")));
  ok("model".equals(h.optString("provider"))&&h.optString("catalog_id").isEmpty(),"Controlled primary fallback does not borrow a catalogue identity");
  ok("Romance Dawn".equals(o(h,"target").optString("set"))&&"2022".equals(o(h,"target").optString("year")),"Actual raw schema aliases preserve model set and year with no catalogue");
  ok("Foil / Textured Alternate Art".equals(o(h,"target").optString("variant")),"Primary fallback retains actual observed variant without rewriting raw model response");
  ok(q.optBoolean("model_only_estimate")&&!q.optBoolean("source_bound")&&q.optDouble("amount")==60,"Validated current-primary EUR40–80 becomes explicitly model-only EUR60 estimate");
  ok(q.optDouble("low")==40&&q.optDouble("high")==80&&"EUR".equals(q.optString("currency")),"Model interval and currency retained");
  ok(q.optString("url").isEmpty()&&q.optString("qualification").contains("non quotazione osservata"),"Model fallback has no invented market link or observed-price claim");
  ReviewerV354.publish(r);ControllerCompletionV358.finalSave(r);
  ok("PROVISIONAL".equals(decision(r).optString("outcome"))&&quote(r).optDouble("amount")==60,"No-catalog model fallback publishes full probable identity and estimate");
  ok(o(r,"result").getJSONArray("sources").length()==0,"Model-only publication creates no fictitious catalogue source links");
  ok(!FinalIdentityV319.active(r)&&!ControllerCompletionV358.exact(r),"Model fallback cannot create exact identity seal");
  save("controlled-primary-model-estimate",r);item("controlled_current_primary_model_estimate","MODEL_ONLY_EUR_INTERVAL");
  for(String defect:new String[]{"reversed_interval","negative_interval","wrong_currency","wrong_grade","wrong_language","different_inferred_year","contradicted_variant","wrong_complete_number"}){
   JSONObject bad=primaryModelFixture(),e=o(ControllerV348.original(bad),"market_estimate");
   if(defect.equals("reversed_interval"))e.put("low",80).put("high",40);
   if(defect.equals("negative_interval"))e.put("low",-1);
   if(defect.equals("wrong_currency"))e.put("currency","USD");
   if(defect.equals("wrong_grade"))e.put("grade","10");
   JSONObject hypothesis=IdentityHypothesisV359.hypothesis(bad);
   if(defect.equals("wrong_language"))o(hypothesis,"target").put("language","ENG");
   if(defect.equals("different_inferred_year"))o(hypothesis,"target").put("year","2023");
   if(defect.equals("contradicted_variant"))o(hypothesis,"target").put("variant","Manga Rare");
   if(defect.equals("wrong_complete_number"))o(hypothesis,"target").put("card_number","OP01-026");
   ok(PriceHypothesisV359.quote(bad,hypothesis).length()==0,"Primary estimate cannot fabricate a quote for "+defect);
   item("primary_estimate_guard_"+defect,"REJECTED");
  }
  JSONObject stale=primaryModelFixture();ControllerV348.original(stale).remove("market_estimate");JSONObject sh=IdentityHypothesisV359.hypothesis(stale);
  stale.put("ai_estimate",new JSONObject().put("status","OK").put("amount",60).put("currency","EUR").put("state","RAW")
   .put("scan_id","different-scan").put("original_sha256",sh.optString("original_sha256")).put("identity_snapshot",cp(o(sh,"target"))));
  ok(PriceHypothesisV359.quote(stale,sh).length()==0,"AI snapshot from another scan cannot be used as a current estimate");
  o(stale,"ai_estimate").put("scan_id",stale.optString("scan_id")).put("original_sha256","stale-evidence");
  ok(PriceHypothesisV359.quote(stale,sh).length()==0,"AI snapshot with stale original hash cannot be used as a current estimate");
  item("primary_estimate_stale_snapshot_guards","REJECTED");
  JSONObject modelRunning=beforeReview(primaryModelFixture());modelRunning.remove(ControllerV348.KEY);modelRunning.remove(ControllerDecisionV349.KEY);
  ok(QuickIdentityV359.fastReviewPolicy(modelRunning),"Current primary model-only positive range can avoid an unnecessary second model call");
  ok("CURRENT_PRIMARY_MODEL_ESTIMATE".equals(o(modelRunning,"quick_review_policy_v359").optString("basis")),"Model fast skip is restricted to the current primary estimate");
  if(finalDex){
   for(String action:new String[]{"CONTROLLER_ALGORITHM_REVIEW","CARDTRADER_REVIEW","CATALOG_CHOICE","OCR_REVIEW","VARIANT_CHECK","REFERENCE_PREPARATION"})
    ok(!ControllerAuthorityV350.allow(modelRunning,action),"Native model-only primary range skips optional second action "+action);
   ok(!ControllerAuthorityV350.authorizeRequest(modelRunning,"catalog_variant_verification"),"Native current-primary estimate prevents second photographic call");
   ok(ControllerAuthorityV350.authorizeRequest(modelRunning,"price_estimate")&&ControllerAuthorityV350.authorizeRequest(modelRunning,"identity"),"Current-primary estimate preserves unrelated market and primary request scope");
  }
  for(String defect:new String[]{"no_range","wrong_grade_scope","contradicted_variant"}){
   JSONObject bad=primaryModelFixture(),raw=ControllerV348.original(bad);
   if(defect.equals("no_range"))raw.remove("market_estimate");
   if(defect.equals("wrong_grade_scope"))o(raw,"market_estimate").put("grade","10");
   if(defect.equals("contradicted_variant"))o(o(raw,"printing_evidence"),"finish_observation").put("value","Manga Rare");
   bad=beforeReview(bad);bad.remove(ControllerV348.KEY);bad.remove(ControllerDecisionV349.KEY);
   ok(!QuickIdentityV359.fastReviewPolicy(bad),"No model fast skip for "+defect);
   if(finalDex)ok(ControllerAuthorityV350.allow(bad,"CONTROLLER_ALGORITHM_REVIEW"),"Native extra evidence path remains available for "+defect);
  }
  item("model_only_fast_review_policy",finalDex?"NATIVE_SECOND_CALL_BLOCKED_WHEN_VALID":"HELPER_VALID_RANGE_ONLY");
 }
 static void quickPolicy()throws Exception{
  JSONObject running=beforeReview(zoro);int count=running.getJSONArray("requests").length();
  ok(QuickIdentityV359.fastReviewPolicy(running),"Already priced compatible Zoro hypothesis can skip extra identity review");
  ok(!ControllerCompletionV358.exact(running),"Fast probable review policy cannot create exact seal");
  ok("8508433".equals(o(running,"quick_review_policy_v359").optString("catalog_id")),"Fast policy is tied to actual JPN catalog row");
  ok(running.getJSONArray("requests").length()==count,"Fast policy adds no request");
  JSONObject first=new JSONObject().put("scan_id","first-primary-request").put("state","IDENTIFYING").put("result",new JSONObject().put("identity",new JSONObject()));
  ok(!QuickIdentityV359.fastReviewPolicy(first),"Before primary recognition no fast skip from an absent hypothesis");
  if(finalDex){
   for(String action:new String[]{"PRICECHARTING_LOOKUP","CATALOG_DISCOVERY","INITIAL_IDENTITY"})
    ok(ControllerAuthorityV350.allow(running,action),"Priced probable identity does not block unrelated native action "+action);
   ok(!ControllerAuthorityV350.allow(running,"CONTROLLER_ALGORITHM_REVIEW"),"Native authority skips secondary review for the priced probable row");
   ok(!ControllerAuthorityV350.authorizeRequest(running,"catalog_variant_verification"),"Native request gate prevents second Gemini call");
   ok(o(running,"controller_authority_v350").optInt("model_reviews_started")==0,"Skipped secondary request consumes no model attempt");
   ok(ControllerAuthorityV350.authorizeRequest(running,"price_estimate"),"Other market-phase requests remain allowed");
   ok(ControllerAuthorityV350.authorizeRequest(first,"identity"),"Primary photographic request remains allowed before any recognition");
   JSONObject unpricedRow=cp(o(IdentityHypothesisV359.hypothesis(zoro),"row")).put("loose-price",0),unpriced=beforeReview(oneRow(zoro,unpricedRow));
   ok(!QuickIdentityV359.fastReviewPolicy(unpriced),"Unpriced candidate cannot suppress an evidence review");
   ok(ControllerAuthorityV350.allow(unpriced,"CONTROLLER_ALGORITHM_REVIEW"),"Native authority still allows unpriced ambiguous card review");
   ok(ControllerAuthorityV350.authorizeRequest(unpriced,"catalog_variant_verification"),"Unpriced current candidate retains model-review path");
   nativePrimaryBodyHook();
  }
  item("priced_hypothesis_fast_review_policy",finalDex?"NATIVE_EXTRA_CALL_BLOCKED":"HELPER_READY");
 }
 static void nativePrimaryBodyHook()throws Exception{
  JSONObject request=zoro.getJSONArray("requests").getJSONObject(0),record=new JSONObject().put("scan_id","native-primary-body-test").put("state","IDENTIFYING");
  JSONObject image=new JSONObject().put("inlineData",new JSONObject().put("mimeType","image/jpeg").put("data","TEST_SENTINEL_NEVER_TRANSMITTED"));
  JSONObject ocr=new JSONObject().put("text","CURRENT OCR: OP01-025 ロロノア・ゾロ");
  JSONArray parts=new JSONArray().put(new JSONObject().put("text",request.optString("prompt"))).put(image).put(ocr);
  JSONObject body=new JSONObject().put("contents",new JSONArray().put(new JSONObject().put("role","user").put("parts",parts))).put("generationConfig",cp(o(request,"generation_config")));
  IdentityRequestV309.configure(record,"identity",body);
  ok(o(record,QuickIdentityV359.KEY).optInt("app_instruction_parts_replaced")>0,"Actual native request configure hook executes compact primary policy");
  JSONObject cfg=o(body,"generationConfig");
  ok(cfg.optInt("maxOutputTokens")==8192&&"low".equals(o(cfg,"thinkingConfig").optString("thinkingLevel")),"Actual native primary request retains LOW and safe output ceiling");
  JSONArray current=body.getJSONArray("contents").getJSONObject(0).getJSONArray("parts");boolean imageSame=false,ocrSame=false;
  for(int i=0;i<current.length();i++){imageSame|=current.getJSONObject(i).toString().equals(image.toString());ocrSame|=current.getJSONObject(i).toString().equals(ocr.toString());}
  ok(imageSame&&ocrSame,"Actual native compact hook preserves image and OCR bytes");
  JSONObject props=o(o(cfg,"responseSchema"),"properties");
  for(String field:new String[]{"number_evidence","number_kind","printing_evidence","variant_check","grading_evidence","printed_subject","card_language"})
   ok(props.has(field),"Actual request hook retains discriminant schema field "+field);
  ok(props.has("market_estimate")&&o(props,"market_estimate").optString("type").equals("OBJECT"),"Actual primary schema supports optional explicitly model-only price interval");
  item("actual_native_primary_prompt_hook","LOW_COMPACT_WITH_EVIDENCE");
 }
 static void oldRawProof()throws Exception{
  JSONObject raw=load("upload/flipcheck-9d8dd84e-c44a-4804-813f-46cf1f4b8e5e.json"),trace=o(raw,"second_identity_call"),context=cp(o(trace,"context")),answer=cp(o(trace,"response"));
  ok("VERIFIED".equals(BoundDecisionV355.evaluate(raw,context,answer).optString("status")),"Old226 exact current-image paired proof still accepted unchanged");
  ok(!QuickIdentityV359.fastReviewPolicy(beforeReview(raw)),"Visible initial25 versus catalog30 requires reread rather than an unchecked fast price skip");
  for(String field:new String[]{"user_collector_number","user_language","reference_image_sha256"}){
   JSONObject changed=cp(answer),check=o(changed,"selected_check");check.put(field,field.equals("user_collector_number")?"143/103":field.equals("user_language")?"en":"bad");
   ok(!"VERIFIED".equals(BoundDecisionV355.evaluate(raw,context,changed).optString("status")),"Exact proof negative remains blocking after probable policies: "+field);
  }
  item("old226_bound_proof_contract","UNCHANGED");
 }
 public static void main(String[] args)throws Exception{
  finalDex=args.length>1&&"--final-dex".equals(args[1]);
  URL.setURLStreamHandlerFactory(p->p.matches("https?")?new URLStreamHandler(){protected URLConnection openConnection(URL url)throws IOException{network++;throw new IOException("Independent replay forbids HTTP");}}:null);
  zoro=load("upload/flipcheck-05ca52dc-7db1-4ba1-9f2d-984e09783c3c.json");trade=load("upload/flipcheck-69cfdfb1-607d-47a9-bbf3-4d0ca82ddd4a.json");lugia=load("upload/flipcheck-1604bbdc-9343-4eda-8fcd-77703e7b8247.json");
  bulba=load("upload/flipcheck-56ebc7cd-1bc4-4b19-9ff0-246719d30023.json");oldLugia=load("low-build/regression-tests/output/exact-lugia.json");
  probable();exact();priceGuards();primaryModelEstimate();quickPolicy();oldRawProof();ok(network==0,"No external request attempted");
  JSONObject report=new JSONObject().put("status","PASS").put("assertions",checks).put("actual_final_dex_guards_exercised",finalDex).put("live_api_calls",0).put("network_attempts",network).put("new_phone_scans",0).put("cases",cases);
  Files.write(Paths.get(args[0]),report.toString(2).getBytes(StandardCharsets.UTF_8));System.out.println("PASS "+checks+" integration assertions; Zoro EUR52.62, Trade EUR282.75; exact quotes unchanged; no APIs");
 }
}
