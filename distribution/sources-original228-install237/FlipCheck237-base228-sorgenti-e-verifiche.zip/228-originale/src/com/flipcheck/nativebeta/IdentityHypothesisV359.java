package com.flipcheck.nativebeta;

import java.util.*;
import org.json.*;

/** Chooses the best current-scan hypothesis. This is deliberately separate
 * from exact-printing membership and never creates a controller seal. */
final class IdentityHypothesisV359 {
 static JSONObject o(JSONObject r,String k){return CatalogEvidenceV150.obj(r,k);}
 static JSONObject cp(JSONObject x)throws Exception{return new JSONObject(x.toString());}
 static String n(String x){return CatalogSearchV349.norm(x);}
 static String hash(JSONObject x)throws Exception{return ObservedIdentityV309.hash(x);}
 static boolean bound(JSONObject r,JSONObject evidence)throws Exception{
  return r.optString("scan_id").equals(evidence.optString("scan_id"))
   &&hash(ControllerV348.original(r)).equals(evidence.optString("original_sha256"));
 }
 static String first(JSONObject value,String... keys){
  for(String key:keys){String found=value.isNull(key)?"":value.optString(key);if(!found.trim().isEmpty())return found;}
  return "";
 }
 static JSONObject modelIdentity(JSONObject raw)throws Exception{
  JSONObject id=ObservationGraphV348.id(raw),target=cp(id);
  target.put("subject",first(id,"subject","subject_name","display_subject"))
   .put("set",first(id,"set","set_name","display_set"))
   .put("variant",first(id,"variant","variant_or_parallel","display_variant"))
   .put("year",first(id,"year","release_year"))
   .put("card_number",first(id,"card_number","collector_number"));
  for(String key:new String[]{"language","state","grader","grade","grade_qualifier","game","printed_subject","set_code","serial_number"}){
   String value=first(id,key);if(value.isEmpty())value=first(raw,key);
   if(key.equals("language")&&value.isEmpty())value=first(raw,"card_language");
   target.put(key,value);
  }
  String category=first(id,"category");if(category.isEmpty())category=first(o(raw,"analysis"),"category");if(category.isEmpty())category=first(raw,"category");
  target.put("category",category).put("display_subject",target.optString("subject"));
  return target;
 }
 static JSONObject initial(JSONObject r)throws Exception{
  JSONObject raw=ControllerV348.original(r),target=modelIdentity(raw);
  JSONObject completion=o(o(r,ControllerCompletionV358.KEY),"decision");
  if(bound(r,completion)&&o(completion,"initial_hypothesis").length()>0)target=cp(o(completion,"initial_hypothesis"));
  JSONObject algorithm=o(r,ControllerAlgorithmsV355.KEY);
  if(bound(r,algorithm)&&o(algorithm,"source_target").length()>0)target=cp(o(algorithm,"source_target"));
  JSONObject visible=ControllerCompletionV358.observedIdentity(r);
  for(String k:new String[]{"category","state","subject","display_subject","printed_subject","language","game","grader","grade","serial_number","card_format"})
   if(!visible.optString(k).isEmpty())target.put(k,visible.optString(k));
  // Preserve absence as an observation. Never restore a remembered number.
  JSONObject number=ObservationGraphV348.number(raw);
  if(number.optBoolean("region_visible"))target.put("card_number",visible.optString("card_number"));
  if(!visible.optString("variant").isEmpty())target.put("variant",visible.optString("variant"));
  target.put("display_set",target.optString("set")).put("display_variant",target.optString("variant"))
   .put("printing_review_required",false).put("metadata_is_provisional",true);
  return target;
 }
 static void add(Map<String,JSONObject> rows,JSONObject row)throws Exception{
  if(row==null||row.optString("id").isEmpty())return;
  if(!rows.containsKey(row.optString("id")))rows.put(row.optString("id"),cp(row));
 }
 static JSONArray pool(JSONObject r)throws Exception{
  Map<String,JSONObject> rows=new LinkedHashMap<String,JSONObject>();
  JSONObject a=o(r,ControllerAlgorithmsV355.KEY);
  if(bound(r,a)){
   JSONArray arr=a.optJSONArray("candidates");for(int i=0;arr!=null&&i<arr.length();i++)add(rows,arr.optJSONObject(i));
  }
  // These are responses retained within this scan, not an identity cache.
  JSONObject snapshots=o(r,"catalog_snapshot_products_v284");Iterator<String> it=snapshots.keys();
  while(it.hasNext())add(rows,snapshots.optJSONObject(it.next()));
  for(String key:new String[]{"charting_selection","charting_result"}){
   JSONObject stage=o(r,key);for(String field:new String[]{"candidate_products","products","candidates"}){
    JSONArray arr=stage.optJSONArray(field);for(int i=0;arr!=null&&i<arr.length();i++)add(rows,arr.optJSONObject(i));
   }
  }
  JSONArray out=new JSONArray();for(JSONObject row:rows.values())out.put(row);return out;
 }
 static boolean explicitNumberConflict(JSONObject raw,JSONObject target,JSONObject row){
  String observed=target.optString("card_number"),catalog=CatalogEvidenceV150.productNumber(row);
  if(CandidateAlgorithmsV355.numberless(raw)&&!catalog.isEmpty()){
   String species=ObservationGraphV348.species(raw);
   return species.isEmpty()||!CatalogRegistryV306.exactNumber(species,catalog);
  }
  if(!observed.isEmpty()&&!catalog.isEmpty()){
   if(!CatalogRegistryV306.exactNumber(observed,catalog))return true;
   JSONObject parsed=CatalogDecisionV345.num(catalog);
   return parsed.optBoolean("complete_fraction")&&!CatalogDecisionV345.sameComplete(observed,catalog);
  }
  return false;
 }
 static boolean softConflict(String conflict){
  // Only claims explicitly recorded as model/inferred release metadata are
  // allowed to disagree. Unknown hard conflicts remain hard by default.
  return Arrays.asList("INFERRED_YEAR_MISMATCH","MODEL_YEAR_MISMATCH","INFERRED_YEAR_IS_NOT_A_VETO",
   "INFERRED_SET_MISMATCH","MODEL_SET_MISMATCH","INFERRED_RELEASE_MISMATCH","MODEL_RELEASE_MISMATCH").contains(conflict);
 }
 static boolean hardRecorded(JSONObject evidence){
  JSONArray conflicts=evidence.optJSONArray("hard_conflicts");
  for(int i=0;conflicts!=null&&i<conflicts.length();i++)if(!softConflict(conflicts.optString(i)))return true;
  return false;
 }
 static boolean physicalVisible(JSONObject raw,String field){
  JSONObject printing=o(raw,"printing_evidence"),finish=o(printing,"finish_observation"),variant=o(raw,"variant_check");
  if(field.equals("finish"))return PhysicalFacetsV346.visible(finish)&&!finish.optString("evidence").isEmpty();
  if(field.equals("artwork"))return PhysicalFacetsV346.visible(finish)||PhysicalFacetsV346.visible(variant);
  if(field.equals("event"))return o(variant,"event_logo").optBoolean("visible")||PhysicalFacetsV346.visible(o(printing,"event_observation"));
  if(field.equals("prize"))return PhysicalFacetsV346.visible(o(variant,"prize_mark"));
  if(field.equals("edition")||field.equals("shadowless"))return PhysicalFacetsV346.visible(o(printing,field+"_observation"))
   ||PhysicalFacetsV346.visible(finish)||PhysicalFacetsV346.visible(variant);
  return false;
 }
 static JSONObject physical(JSONObject raw)throws Exception{
  JSONObject photo=PhysicalFacetsV346.observed(raw),printing=o(raw,"printing_evidence"),variant=o(raw,"variant_check");
  JSONObject logo=o(variant,"event_logo");String event=EventReadingV358.read(logo.optString("text"));
  if(logo.optBoolean("visible")&&!event.isEmpty())photo.put("event",event);
  if(physicalVisible(raw,"edition")&&printing.has("first_edition")){
   if(Boolean.FALSE.equals(printing.opt("first_edition")))photo.put("edition","absent");
   else if(Boolean.TRUE.equals(printing.opt("first_edition")))photo.put("edition","first");
  }
  if(physicalVisible(raw,"shadowless")&&printing.has("shadowless")&&("false".equals(printing.optString("shadowless"))||"ABSENT".equals(printing.optString("shadowless"))))photo.put("shadowless","false");
  return photo;
 }
 static JSONObject comparison(JSONObject raw,JSONObject target,JSONObject row)throws Exception{
  JSONObject evidence=CandidateAlgorithmsV355.compare(raw,target,row);
  if(hardRecorded(evidence)||hardRecorded(o(row,"controller_candidate_v355")))return new JSONObject();
  if(explicitNumberConflict(raw,target,row))return new JSONObject();
  JSONObject photo=physical(raw),facets=CandidateAlgorithmsV355.facets(row);
  if(photo.optBoolean("conflict")||facets.optBoolean("conflict"))return new JSONObject();
  // A score penalty is insufficient when the visible photo directly
  // contradicts a printing attribute stated by the candidate.
  for(String field:PhysicalFacetsV346.KEYS){
   String observed=photo.optString(field),catalogued=facets.optString(field);
   if(physicalVisible(raw,field)&&!observed.isEmpty()&&!catalogued.isEmpty()&&!observed.equals(catalogued))return new JSONObject();
  }
  JSONObject label=o(o(raw,"grading_evidence"),"label_fields");
  String labelYear=label.optString("year"),releaseYear=SubjectDiscoveryV337.releaseYear(row);
  if(o(raw,"grading_evidence").optBoolean("label_visible")&&labelYear.matches("(?:19|20)[0-9]{2}")
    &&!releaseYear.isEmpty()&&!labelYear.equals(releaseYear))return new JSONObject();
  int score=evidence.optInt("retrieval_score");
  String release=n(target.optString("set")),catalog=n(row.optString("console-name"));
  if(!release.isEmpty()&&!catalog.isEmpty()&&(catalog.equals(release)||(" "+catalog+" ").contains(" "+release+" ")))score+=15;
  String year=SubjectDiscoveryV337.releaseYear(row);
  if(!year.isEmpty()&&year.equals(target.optString("year")))score+=10;
  return evidence.put("selection_score",score).put("score_is_probability",false).put("soft_release_mismatch_allowed",true);
 }
 static JSONObject best(JSONObject r,JSONObject target)throws Exception{
  JSONObject raw=ControllerV348.original(r),best=new JSONObject();int score=Integer.MIN_VALUE;boolean tie=false;JSONArray considered=new JSONArray();
  JSONArray rows=pool(r);
  for(int i=0;i<rows.length();i++){
   JSONObject row=rows.getJSONObject(i),ev;
   try{ev=comparison(raw,target,row);}catch(Exception malformedCandidate){continue;}
   if(ev.length()==0)continue;
   // A model comparison rejecting this exact candidate is retained as a veto.
   if(ControllerCompletionV358.rejectedByReview(r,row))continue;
   int value=ev.optInt("selection_score");considered.put(new JSONObject().put("catalog_id",row.optString("id")).put("evidence",ev));
   if(value>score){score=value;best=cp(row);tie=false;}else if(value==score){
    tie=true;if(row.optString("id").compareTo(best.optString("id"))<0)best=cp(row);
   }
  }
  if(best.length()>0)best.put("hypothesis_selection_v359",new JSONObject().put("ranked_candidates",considered)
   .put("tie",tie).put("tie_break",tie?"STABLE_CATALOG_ID_NOT_ADDITIONAL_EVIDENCE":"NONE")
   .put("ranking_is_probability",false).put("exact_printing_verified",false));
  return best;
 }
 static JSONObject legacyCardTrader(JSONObject r,JSONObject target)throws Exception{
  JSONObject trace=o(r,"second_identity_call"),visual=o(r,"cardtrader_visual_v168"),check=o(visual,"comparison");
  String id=visual.optString("blueprint_id");
  if(!r.optString("scan_id").equals(trace.optString("scan_id"))||id.isEmpty()||!"RESOLVED".equals(visual.optString("status"))
    ||!"VERIFIED".equals(o(trace,"validation_v151").optString("status"))||!id.equals(trace.optString("selected_catalog_id"))
    ||!check.optBoolean("same_artwork_and_variant")||check.optBoolean("user_identity_conflict"))return new JSONObject();
  JSONArray refs=visual.optJSONArray("reference_images");JSONObject ref=null;
  for(int i=0;refs!=null&&i<refs.length();i++){
   JSONObject v=refs.optJSONObject(i);
   if(v!=null&&id.equals(v.optString("catalog_id"))&&v.optString("image_sha256").matches("[a-fA-F0-9]{64}")
     &&v.optString("image_sha256").equals(check.optString("reference_image_sha256"))
     &&v.optString("page_url").equals(check.optString("reference_url")))ref=v;
  }
  if(ref==null)return new JSONObject();
  // The legacy comparison must also be present in this scan's HTTP response;
  // a detached visual record is insufficient even for a preferred hypothesis.
  boolean requestMatches=false;JSONArray requests=r.optJSONArray("requests");
  for(int i=0;requests!=null&&i<requests.length();i++){
   JSONObject request=requests.optJSONObject(i);if(request==null||!"catalog_variant_verification".equals(request.optString("phase")))continue;
   JSONArray candidates=o(request,"gemini_response").optJSONArray("candidates");
   for(int j=0;candidates!=null&&j<candidates.length();j++){
    JSONArray parts=o(candidates.optJSONObject(j),"content").optJSONArray("parts");
    for(int k=0;parts!=null&&k<parts.length();k++)try{
     JSONObject response=new JSONObject(parts.getJSONObject(k).optString("text")),c=o(response,"selected_check");
     if(id.equals(response.optString("selected_catalog_id"))&&"RESOLVED".equals(response.optString("status"))
       &&c.optBoolean("same_artwork_and_variant")&&!c.optBoolean("user_identity_conflict")
       &&check.optString("reference_image_sha256").equals(c.optString("reference_image_sha256"))
       &&check.optString("reference_url").equals(c.optString("reference_url"))
       &&NormalizedEvidenceV344.text(check.optString("user_subject")).equals(NormalizedEvidenceV344.text(c.optString("user_subject")))
       &&NormalizedEvidenceV344.text(check.optString("reference_subject")).equals(NormalizedEvidenceV344.text(c.optString("reference_subject"))))requestMatches=true;
    }catch(Exception ignored){}
   }
  }
  if(!requestMatches)return new JSONObject();
  JSONObject raw=ControllerV348.original(r);
  // Every side must be the complete observed name, its complete known
  // translation, or the two together. Prefixes, suffixes and omitted user
  // names cannot make a different subject the preferred reference.
  if(!ReviewEvidenceV356.subject(raw,target,check.optString("user_subject"))
    ||!ReviewEvidenceV356.subject(raw,target,check.optString("reference_subject")))return new JSONObject();
  String language=LanguageV100.normalize(check.optString("reference_language")),wanted=LanguageV100.normalize(target.optString("language"));
  if(!language.isEmpty()&&!wanted.isEmpty()&&!language.equals(wanted))return new JSONObject();
  String observed=target.optString("card_number"),number=check.optString("reference_collector_number");
  if(!observed.isEmpty()&&!CatalogRegistryV306.exactNumber(observed,number))return new JSONObject();
  if(CandidateAlgorithmsV355.numberless(ControllerV348.original(r))&&!number.isEmpty())return new JSONObject();
  return new JSONObject().put("id",id).put("title",ref.optString("title")).put("product-name",ref.optString("title"))
   .put("console-name",target.optString("set")).put("url",ref.optString("page_url")).put("provider","cardtrader")
   .put("reference_image_sha256",ref.optString("image_sha256")).put("comparison",cp(check));
 }
 static JSONObject hypothesis(JSONObject r)throws Exception{
  JSONObject target=initial(r),pc=best(r,target),ct=legacyCardTrader(r,target),row=ct.length()>0?ct:pc;
  String provider=ct.length()>0?"cardtrader":pc.length()>0?"pricecharting":"model";
  if(row.length()>0&&provider.equals("pricecharting")){
   String set=row.optString("console-name"),year=SubjectDiscoveryV337.releaseYear(row);
   if(!set.isEmpty())target.put("set",set).put("display_set",set);
   if(!year.isEmpty())target.put("year",year).put("year_basis","PROBABLE_CATALOG_RELEASE");
  }
  StringBuilder title=new StringBuilder();for(String k:new String[]{"subject","year","set","card_number","variant","language","grader","grade"}){
   String v=target.optString(k).trim();if(!v.isEmpty()){if(title.length()>0)title.append(' ');title.append(v);}
  }target.put("normalized_title",title.toString()).put("metadata_is_provisional",true);
  JSONObject provenance=new JSONObject().put("basis",ct.length()>0?"CURRENT_BOUND_LEGACY_COMPARISON":pc.length()>0?"BEST_CURRENT_CATALOG_HYPOTHESIS":"INITIAL_MODEL_WITH_CURRENT_OBSERVATIONS")
   .put("confidence_label",ct.length()>0?"PROBABLE_REFERENCE":pc.length()>0?"PROBABLE_CATALOG_MATCH":"MODEL_HYPOTHESIS")
   .put("exact_printing_verified",false).put("numeric_confidence_assigned",false).put("candidate_ranking_is_proof",false)
   .put("additional_api_calls",0);
  JSONObject out=new JSONObject().put("target",target).put("row",row).put("provider",provider).put("catalog_id",row.optString("id"))
   .put("scan_id",r.optString("scan_id")).put("original_sha256",hash(ControllerV348.original(r))).put("provenance",provenance);
  if(ct.length()>0&&pc.length()>0)out.put("price_reference_row",pc).put("price_reference_basis","PLAUSIBLE_SAME_SUBJECT_NUMBER_LANGUAGE_CATALOG_HYPOTHESIS");
  return out;
 }
}
