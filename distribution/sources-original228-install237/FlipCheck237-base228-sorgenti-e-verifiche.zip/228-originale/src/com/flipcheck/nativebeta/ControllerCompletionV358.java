package com.flipcheck.nativebeta;
import org.json.*;

/** A scan always has a terminal publication. Completion is not an exact-printing
 * proof: incomplete evidence cannot authorize a catalogue binding or a quote. */
final class ControllerCompletionV358 {
 static final String KEY="controller_completion_v358",NARRATIVE="identity_narrative_v358";
 static JSONObject o(JSONObject r,String k){return CatalogEvidenceV150.obj(r,k);}
 static JSONObject cp(JSONObject r)throws Exception{return new JSONObject(r.toString());}
 static String hash(JSONObject r)throws Exception{return ObservedIdentityV309.hash(r);}
 static boolean exact(JSONObject r){return ControllerTerminalV351.active(r)||ControllerV348.accepted(r);}
 static boolean terminal(JSONObject r){
  if(r==null)return false;String state=r.optString("state");return "DONE".equals(state)||"ERROR".equals(state)||"MARKET_ERROR".equals(state);
 }
 static boolean active(JSONObject r){try{
  JSONObject c=o(r,KEY),d=o(c,"decision");
  return !r.optString("scan_id").isEmpty()&&r.optString("scan_id").equals(d.optString("scan_id"))
   &&"COMPLETE".equals(d.optString("completion_status"))
   &&hash(ControllerV348.original(r)).equals(d.optString("original_sha256"))
   &&hash(d).equals(c.optString("decision_sha256"));
 }catch(Exception ignored){return false;}}
 static boolean reviewed(JSONObject r){
  JSONObject t=o(r,"second_identity_call");
  if(t.optBoolean("triggered")||t.optInt("api_calls")>0)return true;
  JSONArray qs=r.optJSONArray("requests");for(int i=0;qs!=null&&i<qs.length();i++){
   JSONObject q=qs.optJSONObject(i);if(q!=null&&"catalog_variant_verification".equals(q.optString("phase")))return true;
  }return false;
 }
 static void reviewMetrics(JSONObject r)throws Exception{
  if(!reviewed(r))return;
  JSONObject t=o(r,"second_identity_call");JSONArray qs=r.optJSONArray("requests");int calls=0;long duration=0;boolean returned=false;
  String phase=t.optString("request_phase","catalog_variant_verification");
  for(int i=0;qs!=null&&i<qs.length();i++){
   JSONObject q=qs.optJSONObject(i);if(q==null||!phase.equals(q.optString("phase")))continue;
   calls++;duration+=Math.max(0,q.optLong("duration_ms",0));returned|=q.optInt("http_status",0)>0||q.optLong("duration_ms",0)>0;
  }
  if(calls==0){calls=Math.max(t.optInt("api_calls",0),t.optInt("calls",0));duration=Math.max(0,t.optLong("request_duration_ms",0));returned=t.optBoolean("http_response_received");}
  if(calls==0)return;
  boolean done=terminal(r);
  String outcome=exact(r)?"RESOLVED":ReviewTransportV357.pending(r)?"TECHNICAL_ERROR":(returned&&!o(r,ControllerAlgorithmsV355.KEY).optBoolean("review_running")||done)?"UNVERIFIED":"RUNNING";
  t.put("triggered",true).put("calls",calls).put("duration_ms",duration).put("request_duration_ms",duration)
   .put("outcome",outcome).put("status",outcome.equals("RESOLVED")?"RESOLVED":outcome.equals("TECHNICAL_ERROR")?"FAILED":outcome.equals("RUNNING")?"RUNNING":"UNVERIFIED")
   .put("timing_basis_v358","RECORDED_REVIEW_HTTP_REQUESTS").put("review_total_ms_v358",duration+Math.max(0,t.optLong("reference_preparation_ms",0)));
  r.put("second_identity_call",t);
 }
 static void verifiedNarrative(JSONObject r)throws Exception{
  if(!exact(r)||!reviewed(r))return;
  JSONObject result=o(r,"result"),audit=o(r,NARRATIVE);
  if(!audit.has("original_object_story"))audit.put("original_object_story",result.optString("object_story")).put("original_resolution_check",cp(o(result,"resolution_check"))).put("original_published_identity",cp(o(result,"identity")));
  JSONObject target=ControllerV348.target(r),identity=o(result,"identity");
  for(String k:new String[]{"category","subject","year","set","card_number","variant","language","state","grader","grade","grade_qualifier","set_code","serial_number"})if(target.has(k))identity.put(k,target.get(k));
  identity.put("display_set",target.optString("set")).put("display_variant",FinalIdentityV319.displayVariant(target.optString("variant")));
  if(target.has("printing_evidence"))identity.put("printing_evidence",cp(o(target,"printing_evidence")));else identity.remove("printing_evidence");
  StringBuilder title=new StringBuilder();for(String k:new String[]{"subject","year","set","card_number","variant","language","grader","grade"}){String value=target.optString(k).trim();if(!value.isEmpty()){if(title.length()>0)title.append(' ');title.append(value);}}
  identity.put("normalized_title",title.toString());
  result.put("identity",identity);
  StringBuilder text=new StringBuilder("Identità confermata");
  for(String k:new String[]{"subject","card_number","set","year","variant","language"}){
   String value=target.optString(k).trim();if(!value.isEmpty())text.append(" · ").append(value);
  }
  result.put("object_story",text.toString()).put("next_photo_request","");
  JSONObject check=o(result,"resolution_check");check.put("identity_resolved",true).put("next_photo_request","")
   .put("closure_reason","Corrispondenza confermata tra la foto e il riferimento di catalogo.");check.remove("technical_error");
  result.put("resolution_check",check);r.put("result",result);
  audit.put("basis","CURRENT_CONTROLLER_VERIFIED_TARGET").put("scan_id",r.optString("scan_id")).put("original_sha256",hash(ControllerV348.original(r)));r.put(NARRATIVE,audit);
 }
 static boolean rejectedByReview(JSONObject r,JSONObject row){
  JSONObject response=o(o(r,"second_identity_call"),"response"),check=o(response,"selected_check");
  if(!row.optString("id").equals(response.optString("selected_catalog_id")))return false;
  return check.optBoolean("user_identity_conflict")||(check.has("same_artwork_and_variant")&&!check.optBoolean("same_artwork_and_variant"));
 }
 static JSONObject candidate(JSONObject r)throws Exception{
  JSONObject a=o(r,ControllerAlgorithmsV355.KEY);
  if(!ControllerAlgorithmsV355.managed(r))return new JSONObject();
  JSONArray rows=a.optJSONArray("candidates");JSONObject best=null;int score=Integer.MIN_VALUE;boolean tie=false;
  for(int i=0;rows!=null&&i<rows.length();i++){
   JSONObject p=rows.optJSONObject(i);if(p==null||p.optString("id").isEmpty())continue;
   JSONObject ev=o(p,"controller_candidate_v355");JSONArray conflicts=ev.optJSONArray("hard_conflicts");
   if(!ev.optBoolean("eligible")||(conflicts!=null&&conflicts.length()>0)||rejectedByReview(r,p))continue;
   int s=ev.optInt("retrieval_score",0);if(s>score){best=p;score=s;tie=false;}else if(s==score)tie=true;
  }
  return best==null||tie?new JSONObject():cp(best);
 }
 static JSONObject observedIdentity(JSONObject r)throws Exception{
  JSONObject initial=cp(o(o(r,"result"),"identity")),raw=ControllerV348.original(r),id=ObservationGraphV348.id(raw),number=ObservationGraphV348.number(raw);
  JSONObject out=new JSONObject();
  for(String k:new String[]{"category","state","subject","display_subject","printed_subject","language","grader","grade","serial_number","game","card_format"}){
   String v=id.optString(k,initial.optString(k));if(!v.isEmpty())out.put(k,v);
  }
  String n=number.optBoolean("region_visible")?number.optString("value"):"";
  if(!n.isEmpty()&&!CatalogEvidenceV150.nonCollector(number.optString("number_kind",number.optString("type"))))out.put("card_number",n).put("number_basis","observed");
  else out.put("card_number","");
  JSONObject finish=o(o(raw,"printing_evidence"),"finish_observation");
  if(finish.optBoolean("region_visible")&&!finish.optString("value").isEmpty())out.put("variant",finish.optString("value"));
  out.put("set","").put("year","").put("set_code","").put("display_set","").put("display_variant",out.optString("variant"))
   .put("printing_review_required",false).put("metadata_is_provisional",true);
  return out;
 }
 static JSONObject make(JSONObject r)throws Exception{
  boolean verified=exact(r);JSONObject hypothesis=new JSONObject();String hypothesisError="";
  if(!verified)try{hypothesis=IdentityHypothesisV359.hypothesis(r);}catch(Exception malformedEvidence){
   hypothesisError=malformedEvidence.getClass().getSimpleName();hypothesis.put("target",observedIdentity(r)).put("provider","model")
    .put("scan_id",r.optString("scan_id")).put("original_sha256",hash(ControllerV348.original(r)))
    .put("provenance",new JSONObject().put("basis","CURRENT_OBSERVATIONS_AFTER_HYPOTHESIS_ERROR").put("exact_printing_verified",false));
  }
  JSONObject target=verified?cp(ControllerV348.target(r)):cp(o(hypothesis,"target")),row=verified?new JSONObject():o(hypothesis,"row");
  String outcome=verified?"VERIFIED_EXACT":!target.optString("subject").isEmpty()||!target.optString("card_number").isEmpty()?"PROVISIONAL":"NOT_IDENTIFIED";
  String channel=verified?o(r,FinalIdentityV319.KEY).optString("provider","CURRENT_PHOTO_PROOF"):!outcome.equals("NOT_IDENTIFIED")?hypothesis.optString("provider","model").toUpperCase(java.util.Locale.ROOT)+"_HYPOTHESIS":"NONE";
  JSONObject d=new JSONObject().put("completion_status","COMPLETE").put("outcome",outcome).put("channel",channel)
   .put("policy_revision",359)
   .put("scan_id",r.optString("scan_id")).put("original_sha256",hash(ControllerV348.original(r)))
   .put("identity_verified",verified).put("exact_printing_verified",verified).put("target",target)
   .put("same_evidence_retry_allowed",false).put("extra_api_calls",0).put("candidate_ranking_is_proof",false)
   .put("identity_reassessment_pending",false).put("initial_hypothesis",cp(o(o(r,"result"),"identity")));
  if(!hypothesisError.isEmpty())d.put("hypothesis_error",hypothesisError);
  // Preserve the 227 model snapshot before replacing its stripped visible
  // identity. A policy migration may enrich it from current-scan evidence only.
  JSONObject old=o(o(r,KEY),"decision");if(active(r)&&o(old,"initial_hypothesis").length()>0)d.put("initial_hypothesis",cp(o(old,"initial_hypothesis")));
  if(!verified)d.put("hypothesis",cp(hypothesis)).put("provenance",cp(o(hypothesis,"provenance")));
  if(row.length()>0)d.put("reference_candidate",new JSONObject().put("provider",hypothesis.optString("provider")).put("catalog_id",row.optString("id"))
   .put("title",row.optString("product-name",row.optString("title"))).put("set",row.optString("console-name",target.optString("set"))).put("release_date",row.optString("release-date",target.optString("year")))
   .put("url",row.optString("url","https://www.pricecharting.com/game/"+row.optString("id"))).put("provenance",cp(o(hypothesis,"provenance")))
   .put("reference_only",true).put("exact_catalog_binding",false));
  return d;
 }
 static void project(JSONObject r)throws Exception{
  JSONObject d=o(o(r,KEY),"decision");String outcome=d.optString("outcome");
  r.put("identity_completion_status","COMPLETE").put("identity_processing_complete",true);
  if("VERIFIED_EXACT".equals(outcome)){
   // These are authoritative projections of an existing exact seal. Price,
   // target, physical marks and original evidence remain untouched.
   r.put("identity_recognized",true).put("catalog_resolution_required",false);
   JSONObject alignment=o(r,"identity_status_alignment_v242");if(alignment.length()>0)alignment.put("identity_resolved",true);
   JSONObject policy=o(r,"presentation_policy");if(policy.length()>0)policy.put("identity_review_required",false);
   JSONObject identity=o(o(r,"result"),"identity");if(identity.optBoolean("printing_review_required"))identity.put("printing_review_required",false);
   return;
  }
  JSONObject result=o(r,"result"),check=o(result,"resolution_check"),verification=o(r,"verification");
  // A stale amount or link is never transformed into an exact quote by terminal
  // publication. Retain it for diagnosis and remove it from active consumers.
  JSONObject completion=o(r,KEY),archive=o(completion,"unverified_market_audit"),market=o(result,"market"),match=o(r,"catalog_match"),presentation=o(r,"market_presentation"),quote=o(presentation,"current");
  if(match.length()>0&&!archive.has("catalog_match"))archive.put("catalog_match",cp(match));
  if(quote.length()>0&&!archive.has("current_quote"))archive.put("current_quote",cp(quote));
  if((market.has("current_estimate")&&!market.isNull("current_estimate")||o(market,"source").length()>0)&&!archive.has("result_market"))archive.put("result_market",cp(market));
  if(r.has(FinalIdentityV319.KEY)&&!archive.has("invalid_exact_seal"))archive.put("invalid_exact_seal",cp(o(r,FinalIdentityV319.KEY)));
  for(String k:new String[]{"market_metrics_reference_v279","catalog_language_reserve","catalog_page","price_history","ebay_active","cardtrader_active","market_cross_check","slab_market_choice_v245"}){
   JSONObject value=o(r,k);if(value.length()>0&&!value.optBoolean("terminal_identity")&&!archive.has(k))archive.put(k,cp(value));r.remove(k);
  }
  if(archive.length()>0)completion.put("unverified_market_audit",archive);
  r.remove("catalog_match");r.remove(FinalIdentityV319.KEY);
  r.remove(PriceHypothesisV359.KEY);
  if(presentation.length()>0)presentation.put("current",JSONObject.NULL);
  market.put("current_estimate",JSONObject.NULL).put("source",JSONObject.NULL).put("valuation_type","UNAVAILABLE_IDENTITY_PROVISIONAL").put("exact_comps",new JSONArray());
  market.remove("low");market.remove("high");result.put("market",market);
  // The neutral page blocks legacy auto-preview requests. It supplies neither
  // a catalogue anchor nor history/volume, and late pages are ignored by UI.
  r.put("catalog_page",new JSONObject().put("scan_id",r.optString("scan_id")).put("status","UNAVAILABLE_IDENTITY_PROVISIONAL")
   .put("error","IDENTITY_PROVISIONAL").put("series",new JSONObject()).put("volume",new JSONObject()).put("terminal_identity",true));
  String notice=outcome.equals("PROVISIONAL")?"Identificazione conclusa con l'identità più probabile. Edizione, variante e prezzo sono stime quando la stampa esatta non è confermata.":"Analisi conclusa: la carta non è identificabile con gli elementi disponibili.";
  result.put("identity",cp(o(d,"target"))).put("status",outcome).put("identity_status",outcome).put("identity_verified",false)
   .put("identity_completion_status","COMPLETE").put("next_photo_request","").put("object_story",notice);
  check.put("identity_resolved",false).put("identity_processing_complete",true).put("closure_reason",notice).put("next_photo_request","");check.remove("photo_request");result.put("resolution_check",check);
  verification.put("status",outcome).put("identity_status",outcome).put("identity_catalog_verified",false);
  r.put("result",result).put("verification",verification).put("identity_status",outcome).put("identity_model_confirmed",false)
   .put("identity_recognized",false).put("catalog_resolution_required",false).put("identity_closure_basis","TERMINAL_CURRENT_SCAN_PUBLICATION");
  JSONObject controller=o(r,ControllerV348.KEY);controller.put("state","COMPLETED").put("next_action","NONE").put("review_running",false);controller.remove("question");
  if(controller.optString("scan_id").isEmpty())controller.put("scan_id",d.optString("scan_id"));
  if(controller.optString("original_sha256").isEmpty())controller.put("original_sha256",d.optString("original_sha256"));
  r.put(ControllerV348.KEY,controller);
  r.remove(ControllerRuntimeV353.WAIT);
  JSONObject algorithms=o(r,ControllerAlgorithmsV355.KEY);if(algorithms.length()>0)algorithms.put("decision","COMPLETED_"+outcome).put("next_action","NONE");
  JSONObject reviewer=o(r,ReviewerV354.KEY);reviewer.put("identity","COMPLETED_"+outcome).put("catalogue",d.has("reference_candidate")?"REFERENCE_ONLY":"NOT_LINKED").put("quote","UNAVAILABLE_IDENTITY_PROVISIONAL").put("identity_processing_complete",true);
  r.put(ReviewerV354.KEY,reviewer);
  JSONObject corrections=o(r,ControllerCorrectionsV352.KEY);corrections.put("final_outcome","COMPLETED_"+outcome);corrections.remove("unresolved_question");r.put(ControllerCorrectionsV352.KEY,corrections);
  JSONObject common=o(r,CommonDecisionV346.KEY);if(common.length()>0)common.put("review_required",false).put("targeted_review",false);
  if("PROVISIONAL".equals(outcome))try{
   JSONObject hypothesis=o(d,"hypothesis");
   boolean available=PriceHypothesisV359.publish(r,hypothesis);
   completion.put("price_publication_available",available).put("price_policy_revision",359);
  }catch(Exception error){
   completion.put("price_publication_available",false).put("price_publication_error",error.getClass().getSimpleName()).put("price_policy_revision",359);
  }
 }
 static void publish(JSONObject r)throws Exception{
  reviewMetrics(r);verifiedNarrative(r);
  if(!terminal(r)||r.optString("scan_id").isEmpty())return;
  JSONObject old=o(r,KEY),prior=o(old,"decision");boolean migration=active(r)&&!exact(r)&&prior.optInt("policy_revision",358)<359;
  if(!active(r)||exact(r)&&!"VERIFIED_EXACT".equals(prior.optString("outcome"))||migration){
   JSONObject d=make(r),replacement=new JSONObject().put("decision",d).put("decision_sha256",hash(d));
   if(migration)replacement.put("previous_policy_decision",cp(prior)).put("policy_migration",new JSONObject().put("from",prior.optInt("policy_revision",358)).put("to",359).put("additional_api_calls",0));
   if(o(old,"unverified_market_audit").length()>0)replacement.put("unverified_market_audit",cp(o(old,"unverified_market_audit")));
   r.put(KEY,replacement);
  }
  project(r);
 }
 /** Prefix guard for native sync/read/finish entry points. It has no authority
  * during an active scan and never substitutes for an exact proof. */
 static boolean retain(JSONObject r)throws Exception{
  if(!terminal(r)||!active(r)||exact(r))return false;
  if(o(o(r,KEY),"decision").optInt("policy_revision",358)<359){publish(r);return true;}
  project(r);reviewMetrics(r);return true;
 }
 static boolean blocksIdentityReview(JSONObject r){
  return terminal(r)&&active(r);
 }
 static boolean blocksRequest(JSONObject r,String phase){
  return blocksIdentityReview(r)&&("identity".equals(phase)||ControllerAuthorityV350.reviewPhase(phase));
 }
 /** Invoked after the existing finish logic and just before atomic persistence. */
 static void finalSave(JSONObject r)throws Exception{if(terminal(r))publish(r);}
}
