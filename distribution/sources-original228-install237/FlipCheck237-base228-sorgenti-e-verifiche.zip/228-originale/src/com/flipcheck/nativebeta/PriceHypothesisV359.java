package com.flipcheck.nativebeta;
import org.json.*;

/** A sourced estimate for the selected probable identity. This never creates
 * an exact-printing proof and never authorizes an identity/catalogue seal. */
final class PriceHypothesisV359 {
 static final String KEY="price_hypothesis_v359";
 static JSONObject o(JSONObject r,String k){return CatalogEvidenceV150.obj(r,k);}
 static JSONObject cp(JSONObject r)throws Exception{return new JSONObject(r.toString());}
 static String hash(JSONObject r)throws Exception{return ObservedIdentityV309.hash(r);}
 static boolean positive(double value){return value>0&&!Double.isInfinite(value)&&!Double.isNaN(value);}
 static double rounded(double value){return Math.round(value*100.0)/100.0;}
 static boolean bound(JSONObject r,JSONObject h){try{
  return !r.optString("scan_id").isEmpty()&&r.optString("scan_id").equals(h.optString("scan_id"))
   &&hash(ControllerV348.original(r)).equals(h.optString("original_sha256"));
 }catch(Exception ignored){return false;}}
 static String language(JSONObject row){
  String v=LanguageV100.normalize(row.optString("page_language",row.optString("language")));
  if(!v.isEmpty()&&!v.equals("UNK")&&!v.equals("UNKNOWN"))return v;
  v=CatalogEvidenceV150.productLanguage(row);
  if(!v.isEmpty()&&!v.equals("UNK")&&!v.equals("UNKNOWN"))return v;
  String console=row.optString("console-name").toLowerCase(java.util.Locale.ROOT);
  if(console.contains("japanese"))return "JPN";
  if(console.contains("italian"))return "ITA";
  if(console.contains("french"))return "FRA";
  if(console.contains("german"))return "GER";
  return "";
 }
 static JSONObject field(JSONObject target,JSONObject row)throws Exception{
  if(!"SLAB".equalsIgnoreCase(target.optString("state","RAW"))){
   return positive(row.optDouble("loose-price",0))||positive(o(row,"prices_eur").optDouble("loose-price",0))?CatalogQuotesV86.field("loose-price"):new JSONObject();
  }
  JSONObject indicative=new JSONObject();
  for(String[] f:ChartingV54.FIELDS){
   if(f[1].isEmpty()||!positive(row.optDouble(f[0],0))&&!positive(o(row,"prices_eur").optDouble(f[0],0)))continue;
   JSONObject d=CatalogQuotesV86.field(f[0]);d.put("field",f[0]);
   if(ChartingV54.gradeMatches(target,f[1],f[2]))return d;
   // Preserve the existing grade/qualifier policy. A same-numeric-grade
   // reference from another grader is an explicit indicative comparison.
   if(indicative.length()==0&&TcgOffersV111.indicativeGrade(target,f[1],f[2]))indicative=d;
  }
  return indicative;
 }
 static JSONObject catalogQuote(JSONObject r,JSONObject h,JSONObject row)throws Exception{
  if(row.optString("id").isEmpty())return new JSONObject();
  String provider=row.optString("provider"),source=row.optString("catalog_source"),sourceKey=row.optString("source_key");
  if(!provider.isEmpty()&&!provider.equals("pricecharting")&&!provider.equals("charting"))return new JSONObject();
  if(!source.startsWith("PRICECHARTING")&&!sourceKey.startsWith("pc:")&&!"pricecharting".equals(provider)&&!"pricecharting".equals(h.optString("provider")))return new JSONObject();
  JSONObject target=o(h,"target"),descriptor=field(target,row);
  if(descriptor.length()==0)return new JSONObject();
  String field=descriptor.optString("field","loose-price"),sourceId=row.optString("id");
  double eur=o(row,"prices_eur").optDouble(field,0),usd=row.optDouble(field,0)/100.0;
  boolean directEur=positive(eur);if(!directEur&&!positive(usd))return new JSONObject();
  JSONObject fx=o(r,"market_fx");double rate=fx.optDouble("rate_to_eur",0);
  // A missing FX rate does not become an invented euro amount.
  String currency=directEur||positive(rate)?"EUR":"USD";
  double amount=directEur?eur:positive(rate)?usd*rate:usd;
  String state=descriptor.optString("reference_state","RAW"),grader=descriptor.optString("grader"),grade=descriptor.optString("grade");
  boolean exactGrade=state.equals("RAW")||ChartingV54.gradeMatches(target,grader,grade);
  String date=row.optString("catalog_snapshot_date",o(r,"charting_result").optString("catalog_snapshot_date"));
  String title=row.optString("console-name")+" · "+row.optString("product-name");
  JSONObject q=new JSONObject().put("title",title).put("amount",rounded(amount)).put("currency",currency)
   .put("state",state).put("grader",grader).put("grade",grade).put("kind","probable_identity_estimate")
   .put("url","https://www.pricecharting.com/game/"+sourceId).put("catalog_id",sourceId)
   .put("catalog_source",row.optString("catalog_source","PRICECHARTING_CSV"))
   .put("catalog_snapshot_date",date).put("prices_are_live",false)
   .put("catalog_price_field",field).put("source_bound",true).put("exact_grade",exactGrade)
   .put("indicative_grade",!exactGrade).put("provisional_variant",true)
   .put("condition_scope",state.equals("RAW")?"RAW_UNSPECIFIED":"CATALOG_GRADE_REFERENCE")
   .put("retrieved_at",System.currentTimeMillis()).put("date","")
   .put("evidence","PriceCharting CSV "+date+", prodotto "+sourceId+", campo "+field+(directEur?" in EUR.":" in centesimi USD."));
  if(!directEur){q.put("original_amount",usd).put("original_currency","USD");if(positive(rate))q.put("fx",cp(fx));}
  String cardLanguage=LanguageV100.normalize(target.optString("language")),referenceLanguage=language(row);
  q.put("card_language",cardLanguage).put("reference_language",referenceLanguage)
   .put("catalog_language_evidence",new JSONObject().put("language",referenceLanguage).put("catalog_id",sourceId).put("console_name",row.optString("console-name")));
  String qualification="Stima per l'identità più probabile; stampa esatta non confermata. PriceCharting CSV"+(date.isEmpty()?"":" del "+date)+"; "+descriptor.optString("label")+".";
  if(!referenceLanguage.isEmpty()&&!cardLanguage.isEmpty()&&!referenceLanguage.equals(cardLanguage)){
   q.put("language_reference_only",true);
   if(referenceLanguage.equals("ENG")&&!cardLanguage.equals("ENG")){
    int discount=cardLanguage.equals("JPN")?18:25;
    q.put("language_reference_price",cp(q)).put("language_discount_percent",discount).put("language_factor",1-discount/100.0)
     .put("language_adjustment_applied",true).put("language_adjustment_basis","USER_LANGUAGE_ESTIMATE_POLICY")
     .put("amount",rounded(amount*(1-discount/100.0)));
    qualification+=" Riferimento ENG con coefficiente indicativo -"+discount+"% per "+cardLanguage+".";
   }else qualification+=" Riferimento in lingua "+referenceLanguage+", diverso dalla carta "+cardLanguage+".";
  }
  if(state.equals("SLAB")&&!exactGrade)qualification+=" Riferimento di grado indicativo, non vendita dello stesso grader e grado.";
  q.put("qualification",qualification);
  return q;
 }
 static boolean quoteScope(JSONObject q,JSONObject target){
  if(!positive(q.optDouble("amount",0))||!q.optString("currency").matches("[A-Z]{3}"))return false;
  String state=q.optString("state");if(!state.equalsIgnoreCase(target.optString("state","RAW")))return false;
  if(state.equalsIgnoreCase("SLAB"))return ChartingV54.gradeMatches(target,q.optString("grader"),q.optString("grade"))
   ||q.optBoolean("indicative_grade")&&TcgOffersV111.indicativeGrade(target,q.optString("grader"),q.optString("grade"));
  return true;
 }
 static boolean sameScope(JSONObject snapshot,JSONObject target){
  if(snapshot.optString("subject").isEmpty()||target.optString("subject").isEmpty())return false;
  for(String k:new String[]{"subject","year","set","state","grader","grade","grade_qualifier"})
   if(!CatalogSearchV349.norm(snapshot.optString(k)).equals(CatalogSearchV349.norm(target.optString(k))))return false;
  if(!sameNumber(snapshot.optString("card_number"),target.optString("card_number")))return false;
  if(!variantCompatible(target.optString("game",snapshot.optString("game")),snapshot.optString("variant"),target.optString("variant")))return false;
  String a=LanguageV100.normalize(snapshot.optString("language")),b=LanguageV100.normalize(target.optString("language"));
  return !a.equals("UNK")&&!a.equals("UNKNOWN")&&a.equals(b);
 }
 static boolean sameNumber(String a,String b){try{
  if(a.trim().isEmpty()||b.trim().isEmpty())return a.trim().isEmpty()&&b.trim().isEmpty();
  if(!CatalogRegistryV306.exactNumber(a,b))return false;
  if(CatalogDecisionV345.num(a).optBoolean("complete_fraction")||CatalogDecisionV345.num(b).optBoolean("complete_fraction"))return CatalogDecisionV345.sameComplete(a,b);
  return true;
 }catch(Exception ignored){return false;}}
 static boolean variantCompatible(String game,String a,String b){try{
  JSONObject left=NormalizedEvidenceV344.variant(game,a),right=NormalizedEvidenceV344.variant(game,b);
  for(JSONObject v:new JSONObject[]{left,right}){
   if(v.optBoolean("uncertain")||"CONFLICT".equals(v.optString("status")))return false;
   JSONArray forbidden=v.optJSONArray("forbidden");if(forbidden!=null&&forbidden.length()>0)return false;
  }
  if(CatalogSearchV349.norm(a).equals(CatalogSearchV349.norm(b)))return true;
  if(a.trim().isEmpty()||b.trim().isEmpty())return false;
  boolean anchor=false;
  for(String key:new String[]{"finish","pattern","artwork","edition","shadowless","stamp","parallel","color","rarity"}){
   String x=left.optString(key),y=right.optString(key);
   if(!x.isEmpty()&&!y.isEmpty()&&!x.equals(y))return false;
   if(!key.equals("finish")&&!key.equals("rarity")&&!x.equals(y))return false;
   if((key.equals("artwork")||key.equals("finish"))&&!x.isEmpty()&&x.equals(y))anchor=true;
  }
  String eventA=EventReadingV358.read(a),eventB=EventReadingV358.read(b);
  if(!eventA.equals(eventB))return false;
  for(JSONObject v:new JSONObject[]{left,right}){
   String rest=v.optString("unparsed").replaceAll("\\b(?:textured|texture|regular|standard)\\b","").replaceAll("[\\s/\\-]","");
   if(!rest.isEmpty())return false;
  }
  // This permits an additional observed foil/texture description on the same
  // artwork. It grants estimate scope only and never establishes exact print.
  return anchor;
 }catch(Exception ignored){return false;}}
 static boolean currentQuote(JSONObject r,JSONObject h,JSONObject q){
  return r.optString("scan_id").equals(q.optString("scan_id"))&&h.optString("original_sha256").equals(q.optString("original_sha256"))
   &&sameScope(o(q,"identity_snapshot"),o(h,"target"));
 }
 static JSONObject existingQuote(JSONObject r,JSONObject h)throws Exception{
  JSONObject target=o(h,"target"),row=o(h,"row"),reference=o(h,"price_reference_row");
  JSONObject audit=o(o(r,ControllerCompletionV358.KEY),"unverified_market_audit");
  for(JSONObject q:new JSONObject[]{o(o(r,"market_presentation"),"current"),o(audit,"current_quote"),o(o(r,"result"),"market").optJSONObject("source")}){
   if(q==null||!quoteScope(q,target))continue;
   if(!currentQuote(r,h,q))continue;
   String id=q.optString("catalog_id",q.optString("blueprint_id"));
   if(id.isEmpty()||!id.equals(row.optString("id",h.optString("catalog_id")))&&!id.equals(reference.optString("id")))continue;
   return cp(q);
  }
  // A previously obtained AI amount may be shown as an explicit model estimate,
  // only when its own identity snapshot is the selected probable identity.
  JSONObject ai=o(r,"ai_estimate"),snapshot=o(ai,"identity");
  if(snapshot.length()==0)snapshot=o(ai,"identity_snapshot");
  if(!ai.optString("status").matches("DISABLED|ERROR|FAILED|SKIPPED")&&quoteScope(ai,target)&&currentQuote(r,h,ai)&&sameScope(snapshot,target))return cp(ai).put("model_only_estimate",true).put("source_bound",false).put("kind","ai_deduced");
  return new JSONObject();
 }
 static JSONObject primaryEstimate(JSONObject r,JSONObject h)throws Exception{
  JSONObject raw=ControllerV348.original(r),primary=o(r,"identity_response_before_release_check"),estimate=o(primary,"market_estimate");
  if(estimate.length()==0){primary=raw;estimate=o(raw,"market_estimate");}
  if(estimate.length()==0||!"MODEL_ESTIMATE".equals(estimate.optString("basis"))||!"EUR".equals(estimate.optString("currency")))return new JSONObject();
  JSONObject identity=primaryIdentity(primary),target=o(h,"target");
  if(!sameScope(identity,target)||!sameScope(primaryIdentity(raw),identity))return new JSONObject();
  double low=estimate.optDouble("low",0),high=estimate.optDouble("high",0);
  if(!positive(low)||!positive(high)||low>high||!estimate.optString("state").equalsIgnoreCase(target.optString("state"))
   ||!estimate.optString("grader").equalsIgnoreCase(target.optString("grader"))||!estimate.optString("grade").equalsIgnoreCase(target.optString("grade")))return new JSONObject();
  return new JSONObject().put("amount",rounded(low+(high-low)/2)).put("currency","EUR").put("low",low).put("high",high)
   .put("state",estimate.optString("state")).put("grader",estimate.optString("grader")).put("grade",estimate.optString("grade"))
   .put("kind","ai_deduced").put("model_only_estimate",true).put("source_bound",false).put("prices_are_live",false)
   .put("basis","CURRENT_PRIMARY_MODEL_ESTIMATE").put("identity_snapshot",cp(target)).put("url","")
   .put("qualification","Stima AI per l'identità più probabile, non quotazione osservata sul mercato; intervallo "+low+"–"+high+" EUR.");
 }
 static JSONObject primaryIdentity(JSONObject raw)throws Exception{
  JSONObject id=ObservationGraphV348.id(raw);
  return new JSONObject().put("subject",id.optString("subject",id.optString("subject_name"))).put("year",id.optString("year"))
   .put("set",id.optString("set",id.optString("set_name"))).put("card_number",id.optString("card_number"))
   .put("variant",id.optString("variant",id.optString("variant_or_parallel")))
   .put("game",raw.optString("game"))
   .put("language",raw.optString("language",raw.optString("card_language"))).put("state",raw.optString("state","RAW"))
   .put("grader",raw.optString("grader")).put("grade",raw.optString("grade")).put("grade_qualifier",raw.optString("grade_qualifier"));
 }
 static JSONObject quote(JSONObject r,JSONObject h)throws Exception{
  if(!bound(r,h))return new JSONObject();
  JSONObject q=catalogQuote(r,h,o(h,"row"));
  if(q.length()==0)q=catalogQuote(r,h,o(h,"price_reference_row"));
  if(q.length()==0)q=existingQuote(r,h);
  if(q.length()==0)q=primaryEstimate(r,h);
  if(q.length()==0)return q;
  q.put("identity_status","PROVISIONAL").put("provisional_identity",true).put("exact_identity_bound",false)
   .put("probable_identity_catalog_id",h.optString("catalog_id")).put("probable_identity_provider",h.optString("provider"))
   .put("confidence","LOW").put("scan_id",r.optString("scan_id")).put("original_sha256",h.optString("original_sha256"))
   .put("identity_snapshot",cp(o(h,"target")));
  if(!q.optBoolean("model_only_estimate")&&(!q.optString("catalog_id").equals(h.optString("catalog_id"))||!"pricecharting".equals(h.optString("provider")))){
   q.put("price_reference_only",true).put("price_reference_basis",h.optString("price_reference_basis","CURRENT_SELECTED_PROBABLE_REFERENCE"));
   q.put("qualification",q.optString("qualification")+" Prezzo riferito alla scheda di catalogo probabile, senza equivalenza esatta certificata tra i cataloghi.");
  }
  if(!q.optString("qualification").contains("identità più probabile"))q.put("qualification",q.optString("qualification")+" Stima per l'identità più probabile; stampa esatta non confermata.");
  return q;
 }
 static boolean publish(JSONObject r,JSONObject h)throws Exception{
  JSONObject q=quote(r,h);if(q.length()==0)return false;
  JSONObject decision=new JSONObject().put("scan_id",r.optString("scan_id")).put("original_sha256",h.optString("original_sha256"))
   .put("hypothesis_catalog_id",h.optString("catalog_id")).put("hypothesis_provider",h.optString("provider"))
   .put("target",cp(o(h,"target"))).put("quote",cp(q)).put("exact_identity_bound",false).put("extra_api_calls",0);
  r.put(KEY,new JSONObject().put("decision",decision).put("decision_sha256",hash(decision)));
  JSONObject presentation=o(r,"market_presentation"),result=o(r,"result"),market=o(result,"market");
  presentation.put("current",q);r.put("market_presentation",presentation);
  market.put("currency",q.optString("currency")).put("current_estimate",q.optDouble("amount"))
   .put("valuation_type",q.optString("kind","probable_identity_estimate")).put("source",q).put("exact_comps",new JSONArray());
  result.put("market",market);r.put("result",result);
  JSONArray sources=result.optJSONArray("sources");if(sources==null)sources=new JSONArray();
  String url=q.optString("url");
  // Keep an explicit source link; this is an estimate reference, not a seal.
  if(!url.isEmpty()){sources=new JSONArray();sources.put(new JSONObject().put("id","probable-price-"+q.optString("catalog_id")).put("title","Prezzo di riferimento · identità probabile").put("url",url));}
  result.put("sources",sources);
  JSONObject reviewer=o(r,ReviewerV354.KEY);reviewer.put("quote","AVAILABLE_PROVISIONAL");r.put(ReviewerV354.KEY,reviewer);
  return true;
 }
}
