package com.flipcheck.nativebeta;
import org.json.*;import java.nio.file.*;
public class HypothesisAuditProbe {
 public static void main(String[] args)throws Exception{
  JSONObject r=new JSONObject(new String(Files.readAllBytes(Paths.get(args[0])),"UTF-8")),h=IdentityHypothesisV359.hypothesis(r),row=h.getJSONObject("row"),target=h.getJSONObject("target"),raw=ControllerV348.original(r);
  for(String[] nums:new String[][]{{"1/23","12/3"},{"1/23","1"},{"GG35","35"},{"TG01/TG30","01/30"},{"033/L-P","033"},{"OP01-025","OP02-025"},{"SWSH020","020"}}){JSONObject t=new JSONObject(target.toString()).put("card_number",nums[0]),p=new JSONObject(row.toString()).put("product-name",target.optString("subject")+" #"+nums[1]);System.out.println(nums[0]+" vs "+nums[1]+" conflict="+IdentityHypothesisV359.explicitNumberConflict(raw,t,p));}
  JSONObject q=PriceHypothesisV359.quote(r,h);System.out.println("RAW gradeflags "+new JSONObject().put("state",q.opt("state")).put("exact_grade",q.opt("exact_grade")).put("indicative_grade",q.opt("indicative_grade")).put("qualification",q.opt("qualification")));
  JSONObject e=new JSONObject(row.toString()).put("console-name","One Piece Romance Dawn");e.remove("language");e.remove("page_language");System.out.println("Englishnormal language new='"+PriceHypothesisV359.language(e)+"' existing='"+CatalogEvidenceV150.productLanguage(e)+"'");
 }
}
