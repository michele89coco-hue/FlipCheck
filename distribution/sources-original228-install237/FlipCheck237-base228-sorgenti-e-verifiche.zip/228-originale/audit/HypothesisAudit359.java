package com.flipcheck.nativebeta;
import org.json.*;
import java.nio.file.*;
public class HypothesisAudit359 {
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static JSONObject cp(JSONObject j)throws Exception{return new JSONObject(j.toString());}
 static JSONObject o(JSONObject j,String k){return CatalogEvidenceV150.obj(j,k);}
 static JSONObject load(String file)throws Exception{return new JSONObject(new String(Files.readAllBytes(Paths.get(file)),"UTF-8"));}
 public static void main(String[] args)throws Exception{
  JSONObject z=load("upload/flipcheck-05ca52dc-7db1-4ba1-9f2d-984e09783c3c.json");
  JSONObject trade=load("upload/flipcheck-69cfdfb1-607d-47a9-bbf3-4d0ca82ddd4a.json");
  JSONObject h=IdentityHypothesisV359.hypothesis(z),q=PriceHypothesisV359.quote(z,h);
  check(q.optDouble("amount")==52.62&&q.optString("currency").equals("EUR"),"Actual Zoro correctly priced");
  check(q.optString("reference_language").equals("JPN"),"Actual Zoro JPN reference");
  JSONObject th=IdentityHypothesisV359.hypothesis(trade),tq=PriceHypothesisV359.quote(trade,th);
  check(tq.optString("catalog_id").equals("5154287")&&tq.optDouble("amount")==282.75,"Actual Trade probable PC reference quote");
  check(th.optString("catalog_id").equals("202942")&&tq.optBoolean("price_reference_only"),"Separate CT identity and PC reference visibly approximate");
  trade.remove("market_fx");tq=PriceHypothesisV359.quote(trade,th);
  check(tq.optString("currency").equals("USD")&&tq.optDouble("amount")==316.79,"Actual no-FX USD stays USD");
  JSONObject row=cp(o(h,"row")).put("console-name","One Piece Romance Dawn");row.remove("language");row.remove("page_language");
  check(PriceHypothesisV359.language(row).equals("ENG"),"Established inferred ENG language is used after UNK");
  row.put("page_language","UNK");check(PriceHypothesisV359.language(row).equals("ENG"),"Explicit UNK does not stop fallback");
  JSONObject target=o(h,"target");check(q.optBoolean("exact_grade")&&!q.optBoolean("indicative_grade"),"RAW quote is not mislabeled grade indicative");
  JSONObject ctrow=cp(o(h,"row")).put("provider","cardtrader").put("catalog_source","CARDTRADER").put("source_key","ct:8508433");
  check(PriceHypothesisV359.catalogQuote(z,h,ctrow).length()==0,"CT cents not interpreted as PC row");
  JSONObject stored=cp(z);stored.put("market_presentation",new JSONObject().put("current",cp(q)));
  check(PriceHypothesisV359.existingQuote(stored,h).length()>0,"Full bound selected-identity stored quote admitted");
  for(String field:new String[]{"scan_id","original_sha256","identity_snapshot"}){
   JSONObject bad=cp(stored);o(o(bad,"market_presentation"),"current").remove(field);
   check(PriceHypothesisV359.existingQuote(bad,h).length()==0,"Missing "+field+" rejects old quote");
  }
  for(String field:new String[]{"scan_id","original_sha256"}){
   JSONObject bad=cp(stored);o(o(bad,"market_presentation"),"current").put(field,"foreign");
   check(PriceHypothesisV359.existingQuote(bad,h).length()==0,"Foreign "+field+" rejects old quote");
  }
  for(String field:new String[]{"subject","card_number","variant","year","set","language","state","grader","grade","grade_qualifier"}){
   JSONObject bad=cp(stored);o(o(o(bad,"market_presentation"),"current"),"identity_snapshot").put(field,"foreign");
   check(PriceHypothesisV359.existingQuote(bad,h).length()==0,"Different "+field+" rejects stored quote");
  }
  JSONObject bad=cp(stored);o(o(bad,"market_presentation"),"current").put("currency","");
  check(PriceHypothesisV359.existingQuote(bad,h).length()==0,"Currencyless quote rejected");
  for(String[] pair:new String[][]{{"1/23","12/3"},{"GG35","35"},{"TG01/TG30","01/30"},{"033/L-P","033"},{"OP01-025","OP02-025"},{"SWSH020","020"}}){
   JSONObject id=cp(target).put("card_number",pair[0]),candidate=cp(o(h,"row")).put("product-name",target.optString("subject")+" #"+pair[1]);
   check(IdentityHypothesisV359.explicitNumberConflict(ControllerV348.original(z),id,candidate),"Full printed number conflict "+pair[0]+" vs "+pair[1]);
  }
  for(String[] pair:new String[][]{{"1/23","12/3"},{"1/23","1"},{"GG35","35"},{"TG01/TG30","01/30"},{"033/L-P","033"},{"OP01-025","OP02-025"},{"SWSH020","020"}}){
   JSONObject selected=cp(target).put("card_number",pair[0]),snapshot=cp(selected).put("card_number",pair[1]);
   check(!PriceHypothesisV359.sameScope(snapshot,selected),"Stored/primary scope preserves complete number "+pair[0]+" vs "+pair[1]);
  }
  System.out.println(new JSONObject().put("status","PASS_INDEPENDENT_PRICE_SCOPE_AUDIT").put("assertions",checks).put("live_api_calls",0).put("new_phone_scans",0).toString(2));
 }
}
