import java.io.File;
import java.util.*;
import org.jf.dexlib2.*;
import org.jf.dexlib2.dexbacked.DexBackedDexFile;
import org.jf.dexlib2.iface.ClassDef;
import org.jf.dexlib2.immutable.ImmutableDexFile;
import org.jf.dexlib2.writer.pool.DexPool;

/** Export the actual compiled APK classes, without rewriting them. */
public final class Export359 {
 public static void main(String[] args)throws Exception {
  Set<String> wanted=new HashSet<>(Arrays.asList("ControllerCompletionV358","ReviewerV354",
   "IdentityHypothesisV359","PriceHypothesisV359","QuickIdentityV359",
   "ControllerAuthorityV350","IdentityRequestV309"));
  DexBackedDexFile dex=DexFileFactory.loadDexFile(new File(args[0]),Opcodes.getDefault());
  List<ClassDef> selected=new ArrayList<>();
  for(ClassDef c:dex.getClasses())for(String name:wanted)
   if(c.getType().equals("Lcom/flipcheck/nativebeta/"+name+";"))selected.add(c);
  if(selected.size()!=wanted.size())throw new AssertionError("Missing final DEX classes");
  DexPool.writeTo(args[1],new ImmutableDexFile(dex.getOpcodes(),selected));
  System.out.println("Exported "+selected.size()+" actual final DEX classes without edits");
 }
}
