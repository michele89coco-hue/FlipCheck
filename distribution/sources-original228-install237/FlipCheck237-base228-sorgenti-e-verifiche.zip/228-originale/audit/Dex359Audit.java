import java.io.*;import java.nio.file.*;import java.security.*;import java.util.*;
import org.json.*;import org.jf.dexlib2.*;import org.jf.dexlib2.dexbacked.*;import org.jf.dexlib2.iface.*;
import org.jf.dexlib2.iface.instruction.*;import org.jf.dexlib2.iface.reference.*;import org.jf.dexlib2.iface.value.*;
/** Independent semantic scope audit; never rewrites a DEX. */
public final class Dex359Audit {
 static int checks,methodCount,instructionCount;static void ok(boolean v,String why){checks++;if(!v)throw new AssertionError(why);}
 static final String P="Lcom/flipcheck/nativebeta/",REVIEW=P+"ReviewEvidenceV356;",REVIEWER=P+"ReviewerV354;",COMP=P+"ControllerCompletionV358;",EVENT=P+"EventReadingV358;",BUILD=P+"BuildConfig;",ACT=P+"MainActivityV16;";
 static final String ID=P+"IdentityHypothesisV359;",PRICE=P+"PriceHypothesisV359;",QUICK=P+"QuickIdentityV359;";
 static final Set<String> OVERLAY=new HashSet<>(Arrays.asList(COMP)),ADDED=new HashSet<>(Arrays.asList(ID,PRICE,QUICK));
 static final String CONFIG=P+"IdentityRequestV309;->configure(Lorg/json/JSONObject;Ljava/lang/String;Lorg/json/JSONObject;)V";
 static final String APPLY=QUICK+"->apply(Lorg/json/JSONObject;Ljava/lang/String;Lorg/json/JSONObject;)V";
 static final String AUTH=P+"ControllerAuthorityV350;",ALLOW=AUTH+"->allow(Lorg/json/JSONObject;Ljava/lang/String;)Z",AUTHORIZE=AUTH+"->authorizeRequest(Lorg/json/JSONObject;Ljava/lang/String;)Z";
 static final String READ=P+"ControllerV348;->read(Landroid/content/Context;Ljava/lang/String;)Lorg/json/JSONObject;";
 static final String RUNTIME=P+"ControllerRuntimeV353;->save(Landroid/content/Context;Lorg/json/JSONObject;)V";
 static final String BODY=REVIEW+"->body(Lorg/json/JSONObject;Lorg/json/JSONArray;)Lorg/json/JSONObject;",REMOVAL=P+"CommonDecisionV346;->candidates(Lorg/json/JSONObject;)Lorg/json/JSONArray;";
 static final Map<String,String> GUARDS=new TreeMap<>();static{GUARDS.put(P+"ControllerV348;->sync(Lorg/json/JSONObject;Ljava/lang/String;)V","retain(Lorg/json/JSONObject;)Z");GUARDS.put(P+"ControllerV348;->finish(Lorg/json/JSONObject;)V","retain(Lorg/json/JSONObject;)Z");GUARDS.put(P+"ControllerAuthorityV350;->allow(Lorg/json/JSONObject;Ljava/lang/String;)Z","blocksIdentityReview(Lorg/json/JSONObject;)Z");GUARDS.put(P+"ControllerAuthorityV350;->authorizeRequest(Lorg/json/JSONObject;Ljava/lang/String;)Z","blocksRequest(Lorg/json/JSONObject;Ljava/lang/String;)Z");}
 static String key(Method m){StringBuilder b=new StringBuilder(m.getDefiningClass()+"->"+m.getName()+"(");for(CharSequence p:m.getParameterTypes())b.append(p);return b.append(")").append(m.getReturnType()).toString();}
 static String fieldKey(Field f){return f.getDefiningClass()+"->"+f.getName()+":"+f.getType();}
 static SortedMap<String,ClassDef> classes(DexBackedDexFile d){SortedMap<String,ClassDef> result=new TreeMap<>();for(ClassDef c:d.getClasses())result.put(c.getType(),c);return result;}
 static SortedMap<String,Method> methods(ClassDef c){SortedMap<String,Method> result=new TreeMap<>();for(Method m:c.getMethods())result.put(key(m),m);return result;}
 static SortedMap<String,Field> fields(ClassDef c){SortedMap<String,Field> result=new TreeMap<>();for(Field f:c.getFields())result.put(fieldKey(f),f);return result;}
 static List<Instruction> list(Method m){List<Instruction> result=new ArrayList<>();if(m.getImplementation()!=null)for(Instruction i:m.getImplementation().getInstructions())result.add(i);return result;}
 static final Set<String> GETTERS=new HashSet<>(Arrays.asList("getOpcode","getCodeUnits","getRegisterA","getRegisterB","getRegisterC","getRegisterD","getRegisterE","getRegisterF","getRegisterG","getRegisterCount","getStartRegister","getCodeOffset","getNarrowLiteral","getWideLiteral","getReference","getReference2","getReferenceType","getReferenceType2","getVerificationError","getElementWidth","getArrayElements","getSwitchElements"));
 static String canonical(Object value)throws Exception{
  if(value==null)return "null";
  if(value instanceof EncodedValue){EncodedValue v=(EncodedValue)value;if(v instanceof NullEncodedValue)return "encoded:null";if(v instanceof AnnotationEncodedValue){AnnotationEncodedValue a=(AnnotationEncodedValue)v;return "annotation:"+a.getType()+elements(a.getElements());}return "encoded:"+v.getValueType()+":"+canonical(v.getClass().getMethod("getValue").invoke(v));}
  if(value instanceof SwitchElement){SwitchElement s=(SwitchElement)value;return s.getKey()+":"+s.getOffset();}
  if(value instanceof Iterable){List<String> values=new ArrayList<>();for(Object x:(Iterable<?>)value)values.add(canonical(x));return values.toString();}
  return value.toString();
 }
 static String elements(Set<? extends AnnotationElement> elements)throws Exception{SortedMap<String,String> result=new TreeMap<>();for(AnnotationElement e:elements)result.put(e.getName(),canonical(e.getValue()));return result.toString();}
 static String annotations(Set<? extends Annotation> a)throws Exception{List<String> result=new ArrayList<>();for(Annotation x:a)result.add(x.getVisibility()+":"+x.getType()+":"+elements(x.getElements()));Collections.sort(result);return result.toString();}
 static String instruction(Instruction i,boolean ignoreOffset)throws Exception{SortedMap<String,String> values=new TreeMap<>();for(java.lang.reflect.Method m:i.getClass().getMethods())if(m.getParameterCount()==0&&GETTERS.contains(m.getName())&&(!ignoreOffset||!m.getName().equals("getCodeOffset")))values.put(m.getName(),canonical(m.invoke(i)));return values.toString();}
 static String params(Method m)throws Exception{List<String> result=new ArrayList<>();for(MethodParameter p:m.getParameters())result.add(p.getType()+":"+p.getName()+":"+p.getSignature()+":"+annotations(p.getAnnotations()));return result.toString();}
 static String strings(List<Instruction> list){List<String> values=new ArrayList<>();for(Instruction i:list)if(i instanceof ReferenceInstruction&&((ReferenceInstruction)i).getReference() instanceof StringReference)values.add(((StringReference)((ReferenceInstruction)i).getReference()).getString());return values.toString();}
 static int references(List<Instruction> list,String wanted){int count=0;for(Instruction i:list)if(i instanceof ReferenceInstruction&&((ReferenceInstruction)i).getReference() instanceof StringReference&&((StringReference)((ReferenceInstruction)i).getReference()).getString().equals(wanted))count++;return count;}
 static int literals(List<Instruction> list,int wanted){int count=0;for(Instruction i:list)if(i instanceof NarrowLiteralInstruction&&((NarrowLiteralInstruction)i).getNarrowLiteral()==wanted)count++;return count;}
 static String reference(Instruction i){return i instanceof ReferenceInstruction?((ReferenceInstruction)i).getReference().toString():"";}
 static void reg(Instruction i,int r,String why){ok(i instanceof OneRegisterInstruction&&((OneRegisterInstruction)i).getRegisterA()==r,why);}
 static void invocation(Instruction i,Opcode op,String ref,int... args){
  ok(i.getOpcode()==op&&reference(i).equals(ref),"Exact approved invocation "+ref);
  ok(i instanceof FiveRegisterInstruction,"Expected compact invocation");FiveRegisterInstruction f=(FiveRegisterInstruction)i;
  ok(f.getRegisterCount()==args.length,"Exact invocation argument count");int[] registers={f.getRegisterC(),f.getRegisterD(),f.getRegisterE(),f.getRegisterF(),f.getRegisterG()};
  for(int z=0;z<args.length;z++)ok(registers[z]==args[z],"Exact invocation argument register #"+z);
 }
 static int prefix(String method,Method old,List<Instruction> b)throws Exception{
  int p0=old.getImplementation().getRegisterCount()-2,p1=p0+1,count=method.equals(ALLOW)?5:8;ok(p0>0,"Spare v0 does not alias p0");
  ok(b.size()>count,"Quick guard preserves original suffix");int fast=method.equals(ALLOW)?0:3;
  if(method.equals(ALLOW))invocation(b.get(0),Opcode.INVOKE_STATIC,QUICK+"->skipReview(Lorg/json/JSONObject;Ljava/lang/String;)Z",p0,p1);
  else{
   invocation(b.get(0),Opcode.INVOKE_STATIC,AUTH+"->reviewPhase(Ljava/lang/String;)Z",p1);
   ok(b.get(1).getOpcode()==Opcode.MOVE_RESULT,"Phase comparison result");reg(b.get(1),0,"Phase result in v0");
   invocation(b.get(fast),Opcode.INVOKE_STATIC,QUICK+"->fastReviewPolicy(Lorg/json/JSONObject;)Z",p0);
  }
  ok(b.get(fast+1).getOpcode()==Opcode.MOVE_RESULT,"Policy result");reg(b.get(fast+1),0,"Policy result in v0");
  int[] addr=addresses(b);int[] branches=method.equals(ALLOW)?new int[]{2}:new int[]{2,5};for(int i:branches){
   ok(b.get(i).getOpcode()==Opcode.IF_EQZ,"Nonreview/false policy resumes baseline");reg(b.get(i),0,"Guard condition is v0");
   ok(addr[i]+((OffsetInstruction)b.get(i)).getCodeOffset()==addr[count],"Guard false branch lands exactly at baseline first instruction");
  }
  ok(b.get(count-2).getOpcode()==Opcode.CONST_4&&((NarrowLiteralInstruction)b.get(count-2)).getNarrowLiteral()==0,"Skipped secondary review returns false");reg(b.get(count-2),0,"Skip zero in v0");
  ok(b.get(count-1).getOpcode()==Opcode.RETURN,"Skip returns v0");reg(b.get(count-1),0,"Skip return value v0");return count;
 }
 static int[] addresses(List<Instruction> list){int[] result=new int[list.size()+1];for(int i=0;i<list.size();i++)result[i+1]=result[i]+list.get(i).getCodeUnits();return result;}
 static int adjustedOld(int address,int removeAddress,int removeUnits){return removeUnits==0||address<=removeAddress?address:Math.max(removeAddress,address-removeUnits);}
 static int adjustedNew(int address,int prefixUnits){return Math.max(0,address-prefixUnits);}
 static String tries(Method m,int prefixUnits,int removeAddress,int removeUnits)throws Exception{
  if(m.getImplementation()==null)return "none";List<String> result=new ArrayList<>();for(TryBlock<? extends ExceptionHandler> t:m.getImplementation().getTryBlocks()){
   int start=t.getStartCodeAddress(),end=start+t.getCodeUnitCount();start=adjustedOld(adjustedNew(start,prefixUnits),removeAddress,removeUnits);end=adjustedOld(adjustedNew(end,prefixUnits),removeAddress,removeUnits);
   List<String> handlers=new ArrayList<>();for(ExceptionHandler h:t.getExceptionHandlers())handlers.add(h.getExceptionType()+":"+adjustedOld(adjustedNew(h.getHandlerCodeAddress(),prefixUnits),removeAddress,removeUnits));result.add(start+":"+(end-start)+":"+handlers);
  }return result.toString();
 }
 static String sha(Path p)throws Exception{byte[] d=MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(p));StringBuilder b=new StringBuilder();for(byte n:d)b.append(String.format("%02x",n&255));return b.toString();}
 static void header(Path p)throws Exception{byte[] d=Files.readAllBytes(p);ok(Arrays.equals(Arrays.copyOfRange(d,12,32),MessageDigest.getInstance("SHA-1").digest(Arrays.copyOfRange(d,32,d.length))),"DEX signature checksum correct");java.util.zip.Adler32 adler=new java.util.zip.Adler32();adler.update(d,12,d.length-12);long checksum=java.nio.ByteBuffer.wrap(d,8,4).order(java.nio.ByteOrder.LITTLE_ENDIAN).getInt()&0xffffffffL;ok(checksum==adler.getValue(),"DEX Adler32 checksum correct");}
 public static void main(String[] args)throws Exception{
  Path input=Paths.get(args[0]),output=Paths.get(args[1]);ok(sha(input).equals("3350cd65e3d41eb8c73e92e928cb611ba180670861e25ad537e5bfe99c0c4dde"),"Exact signed227 baseline DEX");
  header(input);header(output);if(args.length>3)ok(sha(output).equals(args[3]),"Exact frozen final359 DEX");
  DexBackedDexFile d0=DexFileFactory.loadDexFile(input.toFile(),Opcodes.getDefault()),d1=DexFileFactory.loadDexFile(output.toFile(),Opcodes.getDefault());SortedMap<String,ClassDef> old=classes(d0),next=classes(d1);
  ok(next.keySet().containsAll(old.keySet()),"No deleted classes");Set<String> added=new TreeSet<>(next.keySet());added.removeAll(old.keySet());ok(added.equals(ADDED),"Only three approved helper classes added");
  JSONArray changed=new JSONArray(),primaryLow=new JSONArray(),retained=new JSONArray();int guardCount=0,configHooks=0;boolean lowBody=false,quickLow=false;
  for(String type:next.keySet()){
   ClassDef b=next.get(type);SortedMap<String,Method> mb=methods(b);methodCount+=mb.size();for(Method m:mb.values())instructionCount+=list(m).size();
   if(type.equals(QUICK)){
    Method apply=mb.get(APPLY);ok(apply!=null,"Final compiled quick request adapter exists");List<Instruction> body=list(apply);
    ok(references(body,"low")==1&&references(body,"medium")==0&&literals(body,8192)==1,"Final quick request adapter LOW/8192");quickLow=true;
    ok(references(body,"identity")==1&&references(body,"tools")==1,"Quick adapter guarded to primary photographic identity/no tools");
    Method skip=mb.get(QUICK+"->skipReview(Lorg/json/JSONObject;Ljava/lang/String;)Z");ok(skip!=null,"Final action-whitelist wrapper exists");List<Instruction> whitelist=list(skip);
    List<String> actualActions=new ArrayList<>();for(Instruction i:whitelist)if(i instanceof ReferenceInstruction&&((ReferenceInstruction)i).getReference() instanceof StringReference)actualActions.add(((StringReference)((ReferenceInstruction)i).getReference()).getString());
    Set<String> wantedActions=new TreeSet<>(Arrays.asList("CONTROLLER_ALGORITHM_REVIEW","CARDTRADER_REVIEW","CATALOG_CHOICE","OCR_REVIEW","VARIANT_CHECK","REFERENCE_PREPARATION"));
    ok(actualActions.size()==6&&new TreeSet<>(actualActions).equals(wantedActions),"Only six approved secondary identity actions whitelisted");int policyCalls=0;for(Instruction i:whitelist)if(reference(i).equals(QUICK+"->fastReviewPolicy(Lorg/json/JSONObject;)Z"))policyCalls++;
    ok(policyCalls==1,"Whitelist delegates exactly once to sourced current hypothesis policy");
   }
   if(!old.containsKey(type))continue;ClassDef a=old.get(type);boolean overlay=OVERLAY.contains(type);
   ok(a.getAccessFlags()==b.getAccessFlags(),"Class access preserved: "+type);ok(Objects.equals(a.getSuperclass(),b.getSuperclass())&&a.getInterfaces().equals(b.getInterfaces()),"Class hierarchy preserved: "+type);
   if(!overlay){ok(annotations(a.getAnnotations()).equals(annotations(b.getAnnotations())),"Class annotations preserved: "+type);ok(Objects.equals(a.getSourceFile(),b.getSourceFile()),"Source metadata preserved: "+type);}
   SortedMap<String,Field> fa=fields(a),fb=fields(b);ok(fb.keySet().containsAll(fa.keySet()),"No deleted field: "+type);if(!overlay)ok(fa.keySet().equals(fb.keySet()),"No unapproved fields: "+type);
   for(String f:fa.keySet()){
    Field x=fa.get(f),y=fb.get(f);ok(x.getAccessFlags()==y.getAccessFlags(),"Field access preserved: "+f);if(overlay)continue;
    String vx=canonical(x.getInitialValue()),vy=canonical(y.getInitialValue());
    if(f.equals(BUILD+"->VERSION_CODE:I")){ok(x.getInitialValue() instanceof IntEncodedValue&&((IntEncodedValue)x.getInitialValue()).getValue()==358&&((IntEncodedValue)y.getInitialValue()).getValue()==359,"Only version code358->359");}
    else if(f.equals(BUILD+"->VERSION_NAME:Ljava/lang/String;")){ok(x.getInitialValue() instanceof StringEncodedValue&&((StringEncodedValue)x.getInitialValue()).getValue().equals("2.31-test227")&&((StringEncodedValue)y.getInitialValue()).getValue().equals("2.31-test228"),"Only version227->228");}
    else ok(vx.equals(vy),"Field initial value unchanged: "+f);
    ok(annotations(x.getAnnotations()).equals(annotations(y.getAnnotations())),"Field annotations unchanged: "+f);
   }
   SortedMap<String,Method> ma=methods(a);ok(mb.keySet().containsAll(ma.keySet()),"No deleted methods: "+type);if(!overlay)ok(ma.keySet().equals(mb.keySet()),"No unapproved methods: "+type);
   for(String k:ma.keySet()){
    Method x=ma.get(k),y=mb.get(k);ok(x.getAccessFlags()==y.getAccessFlags(),"Method access preserved: "+k);ok((x.getImplementation()==null)==(y.getImplementation()==null),"Method implementation preserved: "+k);
    List<Instruction> aa=list(x),bb=list(y);
    if(k.equals(BODY)){ok(references(bb,"low")==1&&references(bb,"medium")==0&&literals(bb,8192)==1,"Actual review LOW/8192 remains unchanged");lowBody=true;}
    if(type.startsWith(P)&&!OVERLAY.contains(type)&&references(aa,"thinkingLevel")>0&&references(aa,"low")>0){ok(strings(aa).equals(strings(bb)),"Primary LOW configuration unchanged: "+k);primaryLow.put(k);}
    if(overlay){changed.put(k);continue;}
    ok(annotations(x.getAnnotations()).equals(annotations(y.getAnnotations()))&&params(x).equals(params(y)),"Method signature/parameter metadata unchanged: "+k);
    if(x.getImplementation()!=null)ok(x.getImplementation().getRegisterCount()==y.getImplementation().getRegisterCount(),"Registers unchanged: "+k);
    int trim=0,prefixUnits=0,insertIndex=-1,insertAddress=0,insertUnits=0;int[] oldAddress=addresses(aa),newAddress=addresses(bb);
    if(k.equals(ALLOW)||k.equals(AUTHORIZE)){trim=prefix(k,x,bb);prefixUnits=newAddress[trim];guardCount++;changed.put(k);}
    if(k.equals(CONFIG)){
     for(int i=0;i<bb.size();i++)if(reference(bb.get(i)).equals(APPLY)){ok(insertIndex==-1,"Exactly one final quick apply invocation");insertIndex=i;}
     ok(insertIndex>0,"Quick apply insertion exists");int p0=x.getImplementation().getRegisterCount()-3;
     invocation(bb.get(insertIndex),Opcode.INVOKE_STATIC,APPLY,p0,p0+1,p0+2);
     invocation(bb.get(insertIndex-1),Opcode.INVOKE_STATIC,P+"IdentityPromptV340;->configure(Lorg/json/JSONObject;Ljava/lang/String;Lorg/json/JSONObject;)V",p0,p0+1,p0+2);
     insertAddress=newAddress[insertIndex];insertUnits=bb.get(insertIndex).getCodeUnits();configHooks++;changed.put(k);
    }
    ok(aa.size()==bb.size()-trim-(insertIndex<0?0:1),"Exactly approved insertion/prefix shape: "+k);
    int j=trim;for(int i=0;i<aa.size();i++){
     if(j==insertIndex)j++;Instruction u=aa.get(i),v=bb.get(j);String before=instruction(u,trim>0||insertIndex>=0),after=instruction(v,trim>0||insertIndex>=0);
     if(type.equals(ACT))after=after.replace("2.31-test228","2.31-test227");
     ok(before.equals(after),"Unapproved instruction change: "+k+" #"+i);
     if((trim>0||insertIndex>=0)&&u instanceof OffsetInstruction){ok(v instanceof OffsetInstruction,"Branch remains branch");int od=oldAddress[i]+((OffsetInstruction)u).getCodeOffset(),nd=newAddress[j]+((OffsetInstruction)v).getCodeOffset();ok(od==adjustedOld(adjustedNew(nd,prefixUnits),insertAddress,insertUnits),"Baseline branch target retained: "+k);}
     j++;
    }
    ok(tries(x,0,0,0).equals(tries(y,prefixUnits,insertAddress,insertUnits)),"Exception regions/handlers retained: "+k);
    if(GUARDS.containsKey(k)||k.equals(READ)||k.equals(RUNTIME)){
     String ref=GUARDS.containsKey(k)?COMP+"->"+GUARDS.get(k):COMP+"->finalSave(Lorg/json/JSONObject;)V";
     int oldCount=0,newCount=0;for(Instruction i:aa)if(reference(i).equals(ref))oldCount++;for(Instruction i:bb)if(reference(i).equals(ref))newCount++;
     ok(oldCount==1&&newCount==1,"Exactly one retained227 helper invocation: "+k);retained.put(k);
    }
   }
  }
  ok(guardCount==2,"Exactly two guarded secondary-review quick prefixes");ok(configHooks==1,"Exactly one photographic adapter insertion");ok(retained.length()==6,"All six227 hooks retained semantically");ok(lowBody&&quickLow,"Both actual request LOW8192 bodies inspected");ok(primaryLow.length()>0,"Existing primary LOW routes inspected");
  JSONObject report=new JSONObject().put("status","PASS_INDEPENDENT_DEX359_SCOPE_AUDIT").put("assertions",checks).put("base_dex_sha256",sha(input)).put("final_dex_sha256",sha(output)).put("base_classes",old.size()).put("final_classes",next.size()).put("final_methods",methodCount).put("final_instructions",instructionCount).put("added_classes",new JSONArray(added)).put("approved_method_overlays",changed).put("guarded_secondary_review_prefixes",guardCount).put("photographic_adapter_insertions",configHooks).put("base227_hooks_retained",retained).put("review_thinking_level","low").put("review_max_output_tokens",8192).put("quick_identity_thinking_level","low").put("primary_low_configuration_unchanged",primaryLow).put("other_method_semantics_identical",true).put("other_field_metadata_identical",true).put("deleted_classes_or_methods",0).put("live_api_calls",0).put("new_phone_scans",0);
  if(args.length>2)Files.write(Paths.get(args[2]),report.toString(2).getBytes("UTF-8"));System.out.println(report.toString(2));
 }
}
