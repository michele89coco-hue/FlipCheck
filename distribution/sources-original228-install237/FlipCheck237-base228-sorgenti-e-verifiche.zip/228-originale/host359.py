from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent
tools=root.parent/'low-build/toolchain/work207/tools219'
classes=root/'audit/classes';classes.mkdir(parents=True,exist_ok=True)
stage=root/'stage'
def run(args):subprocess.run([str(x) for x in args],check=True)
run(['java','-XX:-UsePerfData','com.sun.tools.javac.Main','--release','8',
 '-cp',':'.join(str(p) for p in tools.glob('*.jar')),'-d',classes,root/'audit/Export359.java'])
run(['java','-XX:-UsePerfData','-cp',str(classes)+':'+str(tools/'*'),
 'Export359',stage/'patched.dex',stage/'tested-helpers.dex'])
run(['java','-XX:-UsePerfData','-Xmx2g','-cp',str(root.parent/'low-build/toolchain/work207/build218/tools/*'),
 'com.googlecode.dex2jar.tools.Dex2jarCmd','--force','--output',stage/'tested-helpers-host.jar',stage/'tested-helpers.dex'])
