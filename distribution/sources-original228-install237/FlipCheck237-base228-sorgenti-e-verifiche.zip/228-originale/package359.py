from pathlib import Path
import struct,zipfile,json,hashlib,subprocess,copy
root=Path(__file__).resolve().parent
base=root.parent/'low-build/deliverables/FlipCheck227.apk'
out=root/'out';out.mkdir(exist_ok=True)
def u16(b,p):return struct.unpack_from('<H',b,p)[0]
def u32(b,p):return struct.unpack_from('<I',b,p)[0]
def strings(b,p):
 count=u32(b,p+8);start=p+u32(b,p+20);flags=u32(b,p+16);header=u16(b,p+2);result=[]
 for i in range(count):
  at=start+u32(b,p+header+4*i)
  if flags&256:
   def length(pos):
    v=b[pos];return (((v&127)<<8)|b[pos+1],pos+2) if v&128 else (v,pos+1)
   _,at=length(at);n,at=length(at);result.append((b[at:at+n].decode('utf-8'),at,n,'utf-8'))
  else:
   n=u16(b,at);at+=2
   if n&32768:n=((n&32767)<<16)|u16(b,at);at+=2
   result.append((b[at:at+2*n].decode('utf-16le'),at,2*n,'utf-16le'))
 return result
with zipfile.ZipFile(base) as z:
 original=z.read('AndroidManifest.xml');b=bytearray(original);p=8;table=None;attr_changes=0
 while p<len(b):
  kind=u16(b,p);size=u32(b,p+4);assert size>=8
  if kind==1:table=strings(b,p)
  if kind==258:
   assert table is not None
   node=table[u32(b,p+20)][0]
   attrs=p+16+u16(b,p+24);width=u16(b,p+26);count=u16(b,p+28)
   if node=='manifest':
    for i in range(count):
     at=attrs+i*width;name=table[u32(b,at+4)][0]
     if name=='versionCode':
      assert b[at+15]==16 and u32(b,at+16)==358
      struct.pack_into('<I',b,at+16,359);attr_changes+=1
     if name=='versionName':assert table[u32(b,at+16)][0]=='2.31-test227'
  p+=size
 assert attr_changes==1
 versions=[x for x in table if x[0]=='2.31-test227'];assert len(versions)==1
 text,at,size,encoding=versions[0];new='2.31-test228'.encode(encoding);assert len(new)==size;b[at:at+size]=new
 (out/'AndroidManifest.xml').write_bytes(b)
 dex=(root/'stage/patched.dex').read_bytes()
 overlay=json.loads((root/'stage/overlay-audit.json').read_text())
 assert overlay['status']=='PASS' and hashlib.sha256(dex).hexdigest()==overlay['dex_sha256']
 changed=[]
 with zipfile.ZipFile(out/'unsigned.apk','w') as dst:
  for entry in z.infolist():
   name=entry.filename
   if name.startswith('META-INF/') and name.endswith(('.SF','.RSA','.DSA','.EC','.MF')):continue
   data=z.read(name)
   if name=='classes.dex':data=dex
   elif name=='AndroidManifest.xml':data=bytes(b)
   elif name=='assets/index.html':
    assert data.count(b'TEST 2.31 test227')==1
    data=data.replace(b'TEST 2.31 test227',b'TEST 2.31 test228')
   elif name=='assets/fixes280.js':data=(root/'assets/fixes280.js').read_bytes()
   if data!=z.read(name):changed.append(name)
   # ZipFile.writestr mutates ZipInfo offsets; keep the source archive intact.
   dst.writestr(copy.copy(entry),data)
 assert sorted(changed)==['AndroidManifest.xml','assets/fixes280.js','assets/index.html','classes.dex']
 with zipfile.ZipFile(out/'unsigned.apk') as dest:
  assert dest.testzip() is None
  assert dest.read('classes2.dex')==z.read('classes2.dex')
  for n in dest.namelist():
   if n not in changed:assert dest.read(n)==z.read(n),n
 tool=root.parent/'low-build/toolchain/work207/tools219/android-15'
 subprocess.run([str(tool/'zipalign'),'-P','16','-f','4',str(out/'unsigned.apk'),str(out/'aligned.apk')],check=True)
 badging=subprocess.run([str(tool/'aapt'),'dump','badging',str(out/'aligned.apk')],check=True,capture_output=True,text=True).stdout.splitlines()[0]
 assert "versionCode='359'" in badging and "versionName='2.31-test228'" in badging
 audit={'status':'PASS','base':'2.31-test227','version':'2.31-test228','version_code':359,'allowed_changed_entries':changed,'all_other_entries_identical':True,'classes2_identical':True,'package':badging,'dex_sha256':hashlib.sha256(dex).hexdigest(),'new_phone_scans':0,'live_api_calls':0,'parser_unchanged':False,'terminal_completion_added':True}
 (out/'package-audit.json').write_text(json.dumps(audit,indent=2))
 print(json.dumps(audit))
