from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path(__file__).resolve().parent
tools=root.parent/'low-build/toolchain/work207/tools219'
final=root/'stage/tested-helpers-host.jar'
baseline=root.parent/'low-build/stage/tested-helpers-host.jar'
old=root.parent/'build226-review/source/work207/build357/patched357-host.jar'
classes=root/'actual-test-classes'
shutil.rmtree(classes,ignore_errors=True);classes.mkdir()
sources=[]
for folder in ['tests','identity-tests','price-tests','completion-tests','regression-tests','ui-tests']:
 sources.extend(p for p in (root/folder).rglob('*.java'))
assert all(p.parent!=root/'src' for p in sources)
cp=':'.join(map(str,[classes,tools/'android-all.jar',final,baseline,old]))
subprocess.run(['java','-XX:-UsePerfData','com.sun.tools.javac.Main','--release','8',
 '-cp',cp,'-d',str(classes),*[str(p) for p in sources]],check=True)
logs=[root.parent/'upload'/('flipcheck-'+name+'.json') for name in [
 '1604bbdc-9343-4eda-8fcd-77703e7b8247','05ca52dc-7db1-4ba1-9f2d-984e09783c3c','69cfdfb1-607d-47a9-bbf3-4d0ca82ddd4a']]
runs=[('IdentityHypothesis359Test',[]),('PriceHypothesis359Test',[]),
 ('Completion359Test',[]),('QuickIdentity359Test',logs),
 ('Controller359Regression',[root/'regression-tests/controller359-final-dex-report.json','--final-dex']),
 ('Fixture359Writer',[]),('ExportUi359',[])]
results=[]
for name,args in runs:
 completed=subprocess.run(['java','-XX:-UsePerfData','-cp',cp,'com.flipcheck.nativebeta.'+name,*map(str,args)],
  check=True,capture_output=True,text=True)
 results.append({'test':name,'status':'PASS','stdout':completed.stdout.strip()})
 print(completed.stdout.strip(),flush=True)
subprocess.run(['node',str(root/'ui-tests/ui359-test.js')],check=True)
report={'status':'PASS','runtime':'Actual final APK DEX exported and converted without source recompilation',
 'dex_sha256':hashlib.sha256((root/'stage/patched.dex').read_bytes()).hexdigest(),
 'test_classes_only':True,'runs':results,'live_api_calls':0,'new_phone_scans':0,
 'device_latency_verified':False,'ui_browser_render_on_phone':False}
(root/'out').mkdir(exist_ok=True)
(root/'out/actual-dex-test-report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
