package com.flipcheck.nativebeta;
import org.json.*;import java.nio.file.*;import java.net.*;import java.io.*;
public final class Completion359Test {
 static int checks;
 static void ok(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static JSONObject o(JSONObject r,String k){return CatalogEvidenceV150.obj(r,k);}
 static JSONObject cp(JSONObject r)throws Exception{return new JSONObject(r.toString());}
 static JSONObject read(String prefix)throws Exception{try(java.util.stream.Stream<Path>s=Files.list(Paths.get("upload"))){return new JSONObject(new String(Files.readAllBytes(s.filter(p->p.getFileName().toString().startsWith("flipcheck-"+prefix)).findFirst().get()),"UTF-8"));}}
 static JSONObject d(JSONObject r){return o(o(r,ControllerCompletionV358.KEY),"decision");}
 static void estimate(JSONObject r,String identityProvider,String identityId,String priceId,double price)throws Exception{
  int requests=r.getJSONArray("requests").length();JSONObject old=d(r);boolean migration=ControllerCompletionV358.active(r)&&old.optInt("policy_revision",358)<359;
  String original=ObservedIdentityV309.hash(ControllerV348.original(r));ReviewerV354.publish(r);
  JSONObject now=d(r),h=o(now,"hypothesis"),identity=o(o(r,"result"),"identity"),q=o(o(r,"market_presentation"),"current");
  ok(ControllerCompletionV358.active(r)&&"PROVISIONAL".equals(now.optString("outcome")),"Terminal bound probable identity");
  ok(now.optInt("policy_revision")==359&&h.optString("provider").equals(identityProvider)&&h.optString("catalog_id").equals(identityId),"Current-scan hypothesis selected");
  ok(!identity.optString("set").isEmpty()&&!identity.optString("year").isEmpty(),"Probable edition and year retained");
  ok(!o(r,"result").optBoolean("identity_verified")&&!ControllerV348.accepted(r)&&!FinalIdentityV319.active(r),"Probability is never an exact-printing seal");
  ok(q.optString("catalog_id").equals(priceId)&&Math.abs(q.optDouble("amount")-price)<.001,"Proper selected source amount");
  ok(q.optBoolean("provisional_identity")&&!q.optBoolean("exact_identity_bound")&&q.optString("kind").equals("probable_identity_estimate"),"Estimate visibly classified probable");
  ok(o(o(r,"result"),"market").optDouble("current_estimate")==price&&"AVAILABLE_PROVISIONAL".equals(o(r,ReviewerV354.KEY).optString("quote")),"Probable price reaches active presentation");
  ok(r.getJSONArray("requests").length()==requests&&ObservedIdentityV309.hash(ControllerV348.original(r)).equals(original),"No API or source observation mutation");
  ok(!r.has("catalog_match"),"Probable quote does not manufacture catalogue binding");
  if(migration)ok(o(o(r,ControllerCompletionV358.KEY),"policy_migration").optInt("to")==359&&o(o(r,ControllerCompletionV358.KEY),"previous_policy_decision").length()>0,"227 decision migrates once with audit");
  String seal=now.toString(),previous=o(o(r,ControllerCompletionV358.KEY),"previous_policy_decision").toString();
  ReviewerV354.publish(r);ok(seal.equals(d(r).toString())&&previous.equals(o(o(r,ControllerCompletionV358.KEY),"previous_policy_decision").toString()),"Repeated publication keeps decision and migration unchanged");
  o(r,ControllerV348.KEY).put("state","NEEDS_EVIDENCE");ok(ControllerCompletionV358.retain(r),"Retain guards completed identity");
  ok(o(o(r,"market_presentation"),"current").optDouble("amount")==price&&"NONE".equals(o(r,ControllerV348.KEY).optString("next_action")),"Retain republishes price after clearing legacy projections");
  JSONObject wrong=cp(r).put("scan_id","different-scan");ok(!ControllerCompletionV358.active(wrong)&&!ControllerCompletionV358.retain(wrong),"Completion cannot transfer to another scan");
 }
 static void exact(String prefix,double price)throws Exception{
  JSONObject r=read(prefix),identity=cp(o(o(r,"result"),"identity")),market=cp(o(o(r,"result"),"market")),quote=cp(o(o(r,"market_presentation"),"current"));
  ok(ControllerCompletionV358.exact(r),"Recorded exact decision is valid");String original=ObservedIdentityV309.hash(ControllerV348.original(r));
  ReviewerV354.publish(r);ok("VERIFIED_EXACT".equals(d(r).optString("outcome"))&&ControllerV348.accepted(r),"Existing exact identity stays exact");
  ok(o(o(r,"result"),"market").toString().equals(market.toString())&&o(o(r,"market_presentation"),"current").toString().equals(quote.toString()),"Existing exact quote preserved byte for byte");
  ok(o(o(r,"result"),"market").optDouble("current_estimate")==price,"Exact price preserved");
  ok(o(o(r,"result"),"identity").optString("variant").equals(identity.optString("variant")),"Physical variant and stamp preserved");
  ok(ObservedIdentityV309.hash(ControllerV348.original(r)).equals(original),"Exact original observations preserved");
  ok(!r.has(PriceHypothesisV359.KEY),"Exact price never replaced by probable estimate");
 }
 public static void main(String[] args)throws Exception{
  URL.setURLStreamHandlerFactory(p->p.matches("https?")?new URLStreamHandler(){protected URLConnection openConnection(URL u)throws IOException{throw new AssertionError("Live API call");}}:null);
  estimate(read("05ca52dc"),"pricecharting","8508433","8508433",52.62);
  estimate(read("69cfdfb1"),"cardtrader","202942","5154287",282.75);
  exact("1604bbdc",169.85);exact("56ebc7cd",200.44);
  JSONObject oldLugia=read("9d8dd84e"),h=IdentityHypothesisV359.hypothesis(oldLugia);ReviewerV354.publish(oldLugia);
  ok(ControllerCompletionV358.active(oldLugia)&&"PROVISIONAL".equals(d(oldLugia).optString("outcome")),"Original unsealed Lugia remains honest probable identity");
  ok(!o(o(oldLugia,"result"),"identity").optString("set").isEmpty(),"Original model/catalogue metadata no longer blanked");
  for(String state:new String[]{"DONE","ERROR","MARKET_ERROR"}){
   JSONObject empty=new JSONObject().put("scan_id","empty-"+state).put("state",state).put("error","Technical diagnosis").put("requests",new JSONArray());ControllerCompletionV358.finalSave(empty);
   ok("NOT_IDENTIFIED".equals(d(empty).optString("outcome"))&&ControllerCompletionV358.active(empty),"No data terminal without fabricated card");
   ok(state.equals(empty.optString("state"))&&!o(empty,"result").optBoolean("identity_verified"),"Error/retry state retained");
   ok(o(empty,ControllerV348.KEY).optString("scan_id").equals(d(empty).optString("scan_id"))&&o(empty,ControllerV348.KEY).optString("original_sha256").equals(d(empty).optString("original_sha256")),"No-facts terminal controller is bound for UI");
   ok(o(o(empty,"result"),"market").isNull("current_estimate"),"No arbitrary invented amount");
  }
  JSONObject pending=read("05ca52dc");pending.put("state","IDENTITY_RUNNING");String completion=o(pending,ControllerCompletionV358.KEY).toString();ReviewerV354.publish(pending);
  ok(completion.equals(o(pending,ControllerCompletionV358.KEY).toString())&&!ControllerCompletionV358.retain(pending),"Running scan is never terminalized");
  JSONObject oldRetained=read("05ca52dc");ok(ControllerCompletionV358.active(oldRetained)&&d(oldRetained).optInt("policy_revision",358)<359,"Actual old record starts with 227 completion");
  ok(ControllerCompletionV358.retain(oldRetained)&&d(oldRetained).optInt("policy_revision")==359,"Retain directly migrates old bound policy");
  ok(o(o(oldRetained,"market_presentation"),"current").optDouble("amount")==52.62&&!o(o(oldRetained,"result"),"identity").optString("set").isEmpty(),"Retained migration restores full probable identity and price");
  System.out.println("PASS "+checks+" completion359 assertions; actual exported scan replay; 0 API calls");
 }
}
