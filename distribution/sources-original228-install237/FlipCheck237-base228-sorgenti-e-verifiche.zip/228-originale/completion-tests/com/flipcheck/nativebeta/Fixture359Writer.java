package com.flipcheck.nativebeta;
import org.json.*;import java.nio.file.*;import java.nio.charset.StandardCharsets;
public final class Fixture359Writer {
 static void write(String name,JSONObject r)throws Exception{
  ReviewerV354.publish(r);JSONObject out=new JSONObject();
  for(String k:new String[]{"scan_id","state","result","verification","controller_v348","controller_completion_v358","price_hypothesis_v359","market_presentation","identity_status","identity_recognized","identity_model_confirmed","identity_processing_complete","identity_completion_status","catalog_resolution_required","presentation_policy","identity_status_alignment_v242","controller_final_v351","identity_final_v319","catalog_page","reviewer_v354","error"})if(r.has(k))out.put(k,r.get(k));
  Path dir=Paths.get("work359/ui-fixtures");Files.createDirectories(dir);Files.write(dir.resolve(name+".json"),out.toString(2).getBytes(StandardCharsets.UTF_8));
 }
 public static void main(String[] args)throws Exception{
  write("zoro",Completion359Test.read("05ca52dc"));write("trade",Completion359Test.read("69cfdfb1"));
  write("lugia",Completion359Test.read("1604bbdc"));write("bulbasaur",Completion359Test.read("56ebc7cd"));
  for(String state:new String[]{"ERROR","MARKET_ERROR"})write(state.toLowerCase(),new JSONObject().put("scan_id","fixture-"+state).put("state",state).put("error","Technical diagnosis retained").put("requests",new JSONArray()));
  System.out.println("6 current native publication fixtures written; no API calls");
 }
}
