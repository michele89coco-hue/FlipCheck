const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'../..');let checks=0,lateCalls=0,nativeCalls=0;
function ok(x,reason){checks++;if(!x)throw Error(reason);}
function copy(x){return JSON.parse(JSON.stringify(x));}
class Element{
 constructor(text=''){this.own=text;this.children=[];this.dataset={};this.style={};this.hidden=false;this.attrs={};this.classes=new Set();this.classList={toggle:(k,v)=>v?this.classes.add(k):this.classes.delete(k)};}
 get textContent(){return this.children.length?this.children.map(x=>x.textContent).join(''):this.own;}
 set textContent(x){this.own=String(x);this.children=[];}
 append(...xs){this.children.push(...xs);}
 querySelector(s){return this.map?.[s]||null;}
 querySelectorAll(s){return this.lists?.[s]||[];}
 setAttribute(k,v){this.attrs[k]=v;}
 remove(){}
}
const strong=new Element('Da verificare'),badgeNote=new Element('Apri i dettagli'),badge=new Element(),stateNote=new Element();badge.map={strong,p:badgeNote};
const identitySpan=new Element('Identità probabile'),identityIcon=new Element(),identityButton=new Element();identityButton.append(identitySpan);identityButton.map={span:identitySpan,svg:identityIcon};
const chart=new Element(),gauge=new Element();for(const e of [chart,gauge])e.map={'.instrument-label':new Element(),'.instrument-empty':new Element(),'.instrument-caption':new Element()};
const trend=new Element();trend.map={span:new Element()};
const nodes={set:new Element(),chartPreview:chart,liquidityPreview:gauge,rarokTrend174:trend,valueLabel:new Element(),range:new Element()};
const context={console,state:{record:null},cropPreviewActive:false,
 document:{querySelector:s=>({'.rr-verified':badge,'.rr-state-note':stateNote})[s]||null,querySelectorAll:s=>s==='.rr-sources button'?[identityButton]:[]},$(){return nodes[arguments[0]]||null;},
 marketCondition:r=>r.market_presentation?.current||r.result?.identity,marketConditionLabel:r=>r?.state==='RAW'?'Raw':[r?.grader,r?.grade].filter(Boolean).join(' '),
 marketPresentation218:{labels:q=>({title:'Valore',caption:'Stima da catalogo',detail:q.qualification||''})},
 marketLiquidity:r=>{const key=context.marketInstrumentReference(r,'volume').key,v=r.catalog_page?.volume?.[key];return v?{level:1,text:v.count+' vendite',source:v}:{level:null};},
 marketReferenceLabel:()=>'',marketInstrumentReference:()=>({key:null}),showMarketLiquidity(){},
 marketAnchor:r=>r.catalog_match||r.market_presentation?.current||null,
 renderResult(){},renderMarketInstruments(){},showTab(){},el(){return new Element();},native(){nativeCalls++;},marketPageRequests:new Set(),
 window:{receiveMarketPage(page){lateCalls++;context.state.record.catalog_page=page;},addEventListener(){}},requestAnimationFrame(){}};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root,'work359/ui-baseline/instruments279.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(root,'work359/assets/fixes280.js'),'utf8'),context);
const api=context.window.fixes280;
const records=Object.fromEntries(['zoro','trade','trade-usd','lugia','bulbasaur'].map(n=>[n,JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures',n+'.json'),'utf8'))]));
for(const n of ['error','market_error'])records[n]=JSON.parse(fs.readFileSync(path.join(root,'work359/ui-fixtures',n+'.json'),'utf8'));
records['zoro-usd']=JSON.parse(fs.readFileSync(path.join(root,'work359/regression-tests/output/probable-zoro-usd-no-fx.json'),'utf8'));
records['model-estimate']=JSON.parse(fs.readFileSync(path.join(root,'work359/regression-tests/output/controlled-primary-model-estimate.json'),'utf8'));
const originalFormatter=fs.readFileSync(path.join(root,'work359/ui-baseline/rarok174.js'),'utf8').match(/function displayMoney\(value,currency='EUR',digits=2\)\{[^\n]+\}/)[0];
vm.runInContext(originalFormatter,context);
for(const [name,expected] of [['zoro',false],['trade',false],['trade-usd',false],['model-estimate',false],['lugia',true],['bulbasaur',true],['error',false],['market_error',false]]){
 const r=records[name];ok(!!api.completion(r),name+' has native terminal badge');ok(api.resolved(r)===expected,name+' truthful exact/probable state');
 context.state.record=copy(r);context.renderResult();
 const noFacts=r.controller_completion_v358.decision.outcome==='NOT_IDENTIFIED';
 ok(identitySpan.textContent===(expected?'Identificata':noFacts?'Non identificabile':'Identità probabile'),name+' stable existing probable badge can change to exact');
 ok(identityButton.hidden===false,name+' terminal badge visible');ok(badge.classes.has('is-partial')===!expected,name+' truthful color');
 if(!expected){
  if(noFacts){ok(api.probableQuote(r)===null&&context.marketAnchor(r)===null,name+' no fabricated price or catalog link');const before=lateCalls;context.window.receiveMarketPage({scan_id:r.scan_id,catalog_id:'123',url:'https://www.pricecharting.com/game/123'});ok(lateCalls===before,name+' no late arbitrary reference');continue;}
  if(name==='model-estimate'){
   const q=api.probableQuote(r);ok(!!q&&q.amount===60&&q.low===40&&q.high===80&&q.currency==='EUR','Actual native controlled model40–80 quote remains bound with midpoint60');
   ok(q.kind==='ai_deduced'&&q.model_only_estimate===true&&q.source_bound===false&&!q.url&&!q.catalog_id,'Model estimate never claims a catalog source or URL');
   ok(nodes.valueLabel.textContent==='Stima AI','Model amount labeled Stima AI');
   ok(trend.map.span.textContent.includes('40,00')&&trend.map.span.textContent.includes('80,00')&&!trend.map.span.textContent.includes('PriceCharting'),'Model actual interval visible without false PriceCharting caption');
   ok(nodes.range.textContent.includes('Fascia AI:')&&nodes.range.textContent.includes('40,00')&&nodes.range.textContent.includes('80,00'),'Model interval also retained in range detail');
   const amount=context.displayMoney(q.amount,q.currency);ok(amount.includes('60,00')&&amount.includes('€'),'Actual model midpoint60 uses euro formatter');
   ok(api.probableAnchor(r)===null&&context.marketAnchor(r)===null,'Model amount creates no chart catalog anchor');
   ok(context.marketInstrumentReference(r).key===null&&context.marketLiquidity(r).level===null,'Model amount creates no fabricated graph or liquidity');
   const sourceName=fs.readFileSync(path.join(root,'work359/ui-baseline/results204.js'),'utf8').match(/function sourceName204\(c\)\{[^\n]+\}/)[0];vm.runInContext(sourceName,context);ok(context.sourceName204(q)==='AI','Legacy source widget recognizes model source as AI');
   const before=lateCalls;context.window.receiveMarketPage({scan_id:r.scan_id,catalog_id:'8508433',url:'https://www.pricecharting.com/game/8508433'});ok(lateCalls===before,'Model quote rejects unrelated late catalog callback');
   for(const mutate of [x=>x.price_hypothesis_v359.decision.quote.low=90,x=>x.market_presentation.current.high=90,x=>x.price_hypothesis_v359.decision.quote.kind='market_estimate',x=>x.price_hypothesis_v359.decision.quote.url='https://www.pricecharting.com/game/8508433',x=>x.price_hypothesis_v359.decision.quote.source_bound=true]){const wrong=copy(r);mutate(wrong);ok(api.probableQuote(wrong)===null,'Model interval rejects changed source/range binding');}
   continue;
  }
  const q=api.probableQuote(r),a=api.probableAnchor(r);ok(!!q,name+' probable quote bound');ok(!!a,name+' probable instrument anchor bound');
  const formatted=context.displayMoney(q.amount,q.currency);ok(name.endsWith('-usd')?q.currency==='USD'&&q.amount===(name==='trade-usd'?316.79:58.95)&&formatted.includes('$')&&!formatted.includes('€'):q.currency==='EUR'&&formatted.includes('€'),name+' original UI formatter respects actual quote currency');
  ok(nodes.set.textContent.includes(r.result.identity.year)&&nodes.set.textContent.includes(r.result.identity.set),name+' full probable year/set preserved');
  ok(nodes.valueLabel.textContent==='Stima · identità probabile',name+' amount truthfully labeled estimate');ok(trend.map.span.textContent.includes('PriceCharting'),name+' estimate source shown');
  ok(chart.map['.instrument-label'].textContent==='Variazione · riferimento',name+' chart explicitly reference');
  const id=a.catalog_id,url=a.url,before=lateCalls;
  for(const invalid of [{scan_id:'other',catalog_id:id,url},{scan_id:r.scan_id,catalog_id:'999',url},{scan_id:r.scan_id,error:'ACCESS_DENIED'},{scan_id:r.scan_id,catalog_id:id,url:'https://www.pricecharting.com/game/999'},{scan_id:r.scan_id,catalog_id:id,url,original_sha256:'a'.repeat(64)},{scan_id:r.scan_id,catalog_id:id,url,instrument_reference_v279:{catalog_id:'999',url:'https://www.pricecharting.com/game/999'}}]){
   context.window.receiveMarketPage(invalid);ok(lateCalls===before,name+' rejects wrong late page '+JSON.stringify(invalid));
  }
  context.window.receiveMarketPage({scan_id:r.scan_id,catalog_id:id,url,series:{},volume:{}});ok(lateCalls===before+1,name+' accepts same price-reference page');
  const wrong=copy(r);wrong.market_metrics_reference_v279={instruments_only:true,price_adjusted:false,catalog_id:'6235247',url:'https://www.pricecharting.com/game/6235247'};
  wrong.catalog_page={scan_id:r.scan_id,catalog_id:'6235247',series:{used:[[Date.now(),10000]]},volume:{used:{monthly_equivalent:12,count:144,period:'year'}}};
  ok(context.marketAnchor(wrong).catalog_id===id,name+' stale unrelated metric reference cannot override price quote');
  ok(context.marketInstrumentReference(wrong).key===null,name+' stale page yields no series');ok(context.marketLiquidity(wrong).source?.count!==144,name+' stale page yields no source volume');
  for(const mutate of [x=>x.scan_id='other',x=>x.controller_v348.original_sha256='a'.repeat(64),x=>x.price_hypothesis_v359.decision.original_sha256='a'.repeat(64),x=>x.price_hypothesis_v359.decision.hypothesis_catalog_id='999',x=>x.price_hypothesis_v359.decision.hypothesis_provider='wrong',x=>x.market_presentation.current.amount=1,x=>x.market_presentation.current.url='https://www.pricecharting.com/game/999',x=>x.price_hypothesis_v359.decision.target.variant='Other']){
   const mismatch=copy(r);mutate(mismatch);ok(api.probableQuote(mismatch)===null,name+' refuses mismatched active quote binding');ok(context.marketAnchor(mismatch)===null,name+' mismatched quote cannot fall back to old anchor');
  }
 }else{ok(api.probableQuote(r)===null,name+' exact amount not replaced by probable estimate');}
}
const exact=copy(records.lugia);exact.catalog_resolution_required=true;exact.identity_status='UNRESOLVED';exact.presentation_policy={identity_review_required:true};exact.result.identity.printing_review_required=true;
const usdRecord=records['zoro-usd'],usdQuote=usdRecord.market_presentation.current,usdMoney=context.displayMoney(usdQuote.amount,usdQuote.currency);
ok(usdQuote.amount===58.95&&usdQuote.currency==='USD'&&usdMoney.includes('$')&&!usdMoney.includes('€'),'Integration Zoro no-FX quote uses actual USD58.95, never EUR58.95');
ok(api.resolved(exact), 'Native exact decision overrides stale legacy review flags');
context.state.record=exact;context.renderResult();ok(identitySpan.textContent==='Identificata','Lugia previously probable button restored to verified');ok(!identityButton.classes.has('identity-pending280'),'Lugia verified badge no pending styling');
ok(context.marketAnchor(exact).catalog_id==='14451156','Lugia exact price/reference unchanged');ok(api.annual(exact)?.count===2685,'Lugia recorded volume shown as aggregate reference');
const wrongCompletion=copy(records.lugia);wrongCompletion.controller_completion_v358.decision.original_sha256='a'.repeat(64);ok(api.completion(wrongCompletion)===null,'Mismatched completion hash cannot override presentation');
const pending={...records.zoro,state:'IDENTITY_RUNNING'};ok(api.completion(pending)===null,'Running scan remains pending');
ok(nativeCalls===0,'UI adds no lookup or API call in tested renders');
const report={status:'PASS',assertions:checks,source:'Actual uploaded test227 logs replayed through native publication, plus explicitly controlled model40–80 and no-FX fixtures; UI predicates/DOM stub',live_api_calls:0,device_browser_render:false,scope:'Exact/probable badge state, restored metadata, sourced price caption, model amount+range without catalog anchors, bound probable instrument reference and late callback guards'};
fs.writeFileSync(path.join(__dirname,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
