package com.flipcheck.nativebeta;
import java.nio.file.*;import org.json.*;
public final class ExportUi359 {
 public static void main(String[] args)throws Exception{
  Path out=Paths.get("work359/ui-tests/fixtures");Files.createDirectories(out);
  for(String[] entry:new String[][]{{"05ca52dc","zoro"},{"69cfdfb1","trade"},{"69cfdfb1","trade-usd"},{"1604bbdc","lugia"},{"56ebc7cd","bulbasaur"}}){
   Path p;try(java.util.stream.Stream<Path>s=Files.list(Paths.get("upload"))){p=s.filter(x->x.getFileName().toString().startsWith("flipcheck-"+entry[0])).findFirst().get();}
   JSONObject r=new JSONObject(new String(Files.readAllBytes(p),"UTF-8"));if(entry[1].equals("trade-usd"))r.remove("market_fx");ReviewerV354.publish(r);
   Files.write(out.resolve(entry[1]+".json"),r.toString(2).getBytes("UTF-8"));
  }
 }
}
