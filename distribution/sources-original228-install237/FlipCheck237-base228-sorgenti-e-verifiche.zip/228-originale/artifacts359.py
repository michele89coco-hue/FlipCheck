from pathlib import Path
import hashlib,json,zipfile

root=Path(__file__).resolve().parent
deliver=root/'deliverables';deliver.mkdir(exist_ok=True)
read=lambda p:json.loads((root/p).read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
overlay=read('stage/overlay-audit.json');package=read('out/package-audit.json')
signed=read('out/signed-audit.json');actual=read('out/actual-dex-test-report.json')
integration=read('regression-tests/controller359-final-dex-report.json')
ui=read('ui-tests/report.json');scope=read('audit/final-dex359-audit.json')
prices=read('audit/final-dex-price-scope-report.json')
for report in [overlay,package,signed,actual,integration,ui]:assert report['status']=='PASS'
assert scope['status']=='PASS_INDEPENDENT_DEX359_SCOPE_AUDIT'
assert prices['status']=='PASS_INDEPENDENT_PRICE_SCOPE_AUDIT'
assert scope['final_dex_sha256']==overlay['dex_sha256']==signed['dex_sha256']==actual['dex_sha256']
assert integration['actual_final_dex_guards_exercised'] is True
for name,value in overlay['source_sha256'].items():assert sha(root/name)==value
asset_sha='ef9392eb5fb63fb3440d4b821b8f9de354f9944ef199346f2d9589a22a661cb0'
assert sha(root/'assets/fixes280.js')==asset_sha
apk=deliver/'FlipCheck228.apk'
assert sha(apk)==signed['apk_sha256']
with zipfile.ZipFile(apk) as z:
 assert hashlib.sha256(z.read('classes.dex')).hexdigest()==overlay['dex_sha256']
 assert hashlib.sha256(z.read('assets/fixes280.js')).hexdigest()==asset_sha

body=f'''FlipCheck / Rarok 2.31-test228 — versionCode 359
Verifiche del 6 ottobre 2026

L'APK aggiorna la test227 conservando package e certificato di firma.
La scansione termina con l'identità più probabile ricavata dalla foto e dai
riferimenti compatibili. L'identità probabile resta esplicitamente distinta
dalla stampa esatta verificata; non viene aggiunto un sigillo di certezza.

Nei replay dei log inviati:
Zoro: Roronoa Zoro, OP01-025, JPN, 2022, One Piece Japanese Romance Dawn,
       Foil / Textured Alternate Art; stima 52,62 EUR.
       Riferimento PriceCharting 8508433, loose-price 58,95 USD;
       snapshot CSV 22/09/2026, cambio registrato 0,892538 EUR/USD.
Trade Please!: JPN, 1998, Unnumbered Promos, Non-Holo, senza numero.
       Identità probabile CardTrader 202942; stima 282,75 EUR dal riferimento
       PriceCharting 5154287, loose-price 316,79 USD, CSV 30/09/2026.
       L'equivalenza esatta fra i due cataloghi non viene dichiarata.
Lugia: identità esatta già verificata, 142/103, JPN, 2026,
       Pokémon Japanese 30th Celebration, timbro 30; 169,85 EUR conservati.
       Il badge torna a Identificata anche se restano vecchi flag provvisori.
Bulbasaur: identità esatta e 200,44 EUR conservati nel replay precedente.

Questi importi sono dati di catalogo registrati, non quotazioni live.
La scheda e lo stato RAW/SLAB devono essere coerenti. Mancando il cambio
valuta si mostra USD: non si etichetta come EUR un importo in dollari.
Numero completo, prefissi promo, denominatore, lingua, variante e grado
restano vincolati alla scansione corrente. Le quote precedenti incompatibili
non vengono riutilizzate.

Quando manca un prezzo di catalogo, la stessa prima chiamata può restituire
una fascia MODEL_ESTIMATE in EUR. La schermata mostra Stima AI e la fascia,
senza inventare URL, fonte, storico o liquidità. Un test controllato sulla
forma reale della risposta primaria ha verificato fascia 40–80 EUR e valore
centrale 60 EUR. La fascia è stata inserita nel test, non ricevuta da una
nuova chiamata API. Se il modello non fornisce una stima plausibile, nessun
importo arbitrario viene creato.

Velocità: Gemini resta LOW. Il prompt primario è più compatto e omette
duplicazioni facoltative, conservando foto, OCR e prove fisiche discriminanti.
Il limite di output resta 8192 token per evitare troncamenti del JSON.
Le sei revisioni secondarie possono essere saltate quando esistono identità
compatibile e prezzo utilizzabile, anche una nuova stima AI coerente.
La prima identificazione e i canali di ricerca prezzo restano consentiti.
Contraddizioni fisiche esplicite conservano il confronto supplementare.

Nei tre log test227 il totale era circa 24,6 / 28,4 / 28,1 secondi;
la seconda chiamata aggiungeva circa 11,5 / 9,2 / 7,6 secondi.
Il nuovo percorso evita quella chiamata nei casi compatibili. Il tempo della
nuova scansione sul telefono non è ancora misurato: non si garantiscono
6–8 secondi né si attribuisce al telefono una misura ottenuta offline.

Verifiche superate sul codice effettivo estratto dal DEX finale:
64 identità; 62 prezzi; 60 completamento; 441 configurazione e gate rapidi;
162 integrazione; 169 schermata con DOM di test; 39 audit prezzo/numero
indipendenti. Totale 997 asserzioni di comportamento/contratto.
Audit meccanico separato: {scope['assertions']} confronti di scope.
Classi 9644 → 9647; tutti i sei hook della 227 preservati.
Sono cambiati soltanto manifest, classes.dex, etichetta versione HTML e
fixes280.js. classes2.dex e gli altri payload restano identici.
Nessuna nuova chiamata API e nessuna nuova scansione sul telefono.
Il rendering è verificato con uno stub DOM, non con il browser del telefono.

Firma v1/v2/v3 verificata, allineamento 16 KB verificato, certificato
identico alla test227. Il payload firmato è identico al payload verificato.

APK SHA256: {signed['apk_sha256']}
DEX SHA256: {signed['dex_sha256']}
Certificato SHA256: {signed['certificate_sha256']}
Asset UI SHA256: {asset_sha}
APK byte: {signed['apk_bytes']}

L'archivio sorgenti contiene helper, test, script di build, DEX e report.
Non contiene chiavi di firma, credenziali o i log originali dell'utente.
Gli script di replay richiedono i log d'ingresso indicati nei sorgenti;
la ricostruzione richiede l'APK base 227 e la toolchain Android indicata.
'''
report_path=deliver/'FlipCheck228-verifiche.txt';report_path.write_text(body,encoding='utf-8')

selected=set()
for folder in ['src','tests','identity-tests','price-tests','completion-tests','regression-tests','ui-tests','audit']:
 for p in (root/folder).rglob('*.java'):selected.add(p)
for name in ['build359.py','package359.py','sign359.py','host359.py','verify359.py','artifacts359.py',
 'assets/fixes280.js','ui-tests/ui359-test.js','ui-tests/report.json','identity-tests/report.json',
 'stage/overlay-audit.json','stage/base.dex','stage/patched.dex','stage/tested-helpers.dex','stage/tested-helpers-host.jar',
 'out/package-audit.json','out/signed-audit.json','out/actual-dex-test-report.json','out/signature-verification.txt',
 'audit/final-dex359-audit.json','audit/final-dex-price-scope-report.json',
 'regression-tests/controller359-final-dex-report.json','regression-tests/final-dex-verification-manifest.json']:
 p=root/name;assert p.is_file(),name;selected.add(p)
selected.add(report_path)
manifest={'version':'2.31-test228','version_code':359,'apk_sha256':signed['apk_sha256'],
 'dex_sha256':signed['dex_sha256'],'live_api_calls':0,'new_phone_scans':0,
 'files':{str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(selected)}}
manifest_path=deliver/'source-manifest228.json';manifest_path.write_text(json.dumps(manifest,indent=2))
archive=deliver/'FlipCheck228-sorgenti-verifiche.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(selected):
  name=p.relative_to(root).as_posix();assert not name.startswith('private/') and not name.endswith(('.p12','.jks'))
  z.write(p,name)
 z.write(manifest_path,'source-manifest228.json')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert not any('/private/' in name or name.endswith(('.p12','.jks')) for name in z.namelist())
 for name,info in manifest['files'].items():assert hashlib.sha256(z.read(name)).hexdigest()==info['sha256']
print(json.dumps({'status':'PASS','apk_sha256':signed['apk_sha256'],'report':report_path.name,
 'archive':archive.name,'archive_sha256':sha(archive),'archived_files':len(selected)+1},indent=2))
