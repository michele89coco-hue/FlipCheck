package com.flipcheck.nativebeta;
import org.json.*;import java.nio.file.*;import java.nio.charset.StandardCharsets;
public class IdentityHypothesis359Test {
 static int count;
 static void ok(boolean b,String m){count++;if(!b)throw new AssertionError(m);}
 static JSONObject read(String prefix)throws Exception{
  try(java.util.stream.Stream<Path> paths=Files.list(Paths.get("upload"))){Path p=paths.filter(x->x.getFileName().toString().startsWith("flipcheck-"+prefix)).findFirst().get();return new JSONObject(new String(Files.readAllBytes(p),StandardCharsets.UTF_8));}
 }
 static JSONObject cp(JSONObject x)throws Exception{return new JSONObject(x.toString());}
 public static void main(String[] args)throws Exception{
  JSONObject z=read("05ca52dc"),trade=read("69cfdfb1"),lugia=read("1604bbdc");
  JSONObject zh=IdentityHypothesisV359.hypothesis(z),th=IdentityHypothesisV359.hypothesis(trade),zt=zh.getJSONObject("target"),tt=th.getJSONObject("target");
  ok(zh.optString("catalog_id").equals("8508433"),"Zoro JPN alternate art wins native constraints");
  ok(zh.optString("provider").equals("pricecharting"),"Zoro current PC candidate");
  ok(zt.optString("card_number").equals("OP01-025"),"Zoro number retained");
  ok(zt.optString("year").equals("2022"),"Zoro probable year retained");
  ok(zt.optString("set").equals("One Piece Japanese Romance Dawn"),"Zoro probable set complete");
  ok(zt.optString("variant").equals("Foil / Textured Alternate Art"),"Zoro actual finish retained");
  ok(zh.getJSONObject("row").optInt("loose-price")==5895,"Zoro correct JPN snapshot amount");
  ok(!zh.getJSONObject("provenance").optBoolean("exact_printing_verified"),"Hypothesis does not claim exact proof");
  ok(th.optString("catalog_id").equals("202942"),"Trade native validated CT match preferred");
  ok(th.optString("provider").equals("cardtrader"),"Trade CT channel");
  ok(tt.optString("year").equals("1998"),"Trade probable year retained");
  ok(tt.optString("set").equals("Unnumbered Promos"),"Trade model set retained with hypothesis label");
  ok(tt.optString("card_number").isEmpty(),"Trade absent number retained");
  ok(th.getJSONObject("price_reference_row").optString("id").equals("5154287"),"Trade plausible PC reference excludes numbered reprint");
  ok(th.getJSONObject("price_reference_row").optInt("loose-price")==31679,"Trade plausible PC quote available");
  ok(!IdentityHypothesisV359.hypothesis(trade).toString().contains("exact_printing_verified\":true"),"No exact seal from a hypothesis");
  JSONObject raw=ControllerV348.original(z),row=cp(zh.getJSONObject("row"));
  row.put("product-name","Roronoa Zoro [Alternate Art] OP01-026");ok(IdentityHypothesisV359.comparison(raw,zt,row).length()==0,"Wrong collector number rejected");
  row=cp(zh.getJSONObject("row"));row.put("product-name","Monkey D. Luffy [Alternate Art] OP01-025");ok(IdentityHypothesisV359.comparison(raw,zt,row).length()==0,"Wrong subject rejected");
  row=cp(zh.getJSONObject("row"));row.put("page_language","ENG").put("language","ENG").put("console-name","One Piece Romance Dawn");ok(IdentityHypothesisV359.comparison(raw,zt,row).length()==0,"Different language not chosen over same-language identity");
  row=cp(zh.getJSONObject("row"));JSONObject uncertainTarget=cp(zt);uncertainTarget.put("set","Hypothesized different label");ok(IdentityHypothesisV359.comparison(raw,uncertainTarget,row).length()>0,"Inferred set label never vetoes matching number variant");
  JSONObject slabRaw=cp(raw);slabRaw.put("grading_evidence",new JSONObject().put("label_visible",true).put("label_fields",new JSONObject().put("year","2021")));
  ok(IdentityHypothesisV359.comparison(slabRaw,zt,row).length()==0,"Visible slab label year mismatch rejects reference");
  slabRaw.getJSONObject("grading_evidence").getJSONObject("label_fields").put("year","2022");ok(IdentityHypothesisV359.comparison(slabRaw,zt,row).length()>0,"Matching slab label year permits reference");
  JSONObject fractionTarget=cp(zt);fractionTarget.put("card_number","1/23");JSONObject fractionRow=cp(row);fractionRow.put("product-name","Roronoa Zoro [Alternate Art] #12/3");
  ok(IdentityHypothesisV359.explicitNumberConflict(raw,fractionTarget,fractionRow),"Fraction normalization is not destructive");
  JSONObject lugiaRaw=ControllerV348.original(lugia),lugiaTarget=IdentityHypothesisV359.initial(lugia),lugiaRow=lugia.getJSONObject("controller_algorithms_v355").getJSONArray("candidates").getJSONObject(0);
  ok(IdentityHypothesisV359.comparison(lugiaRaw,lugiaTarget,lugiaRow).length()==0,"Visible event25 cannot quote event30 candidate or skip review");
  JSONObject unreadableEvent=cp(lugiaRaw);unreadableEvent.getJSONObject("variant_check").getJSONObject("event_logo").put("visible",false);unreadableEvent.getJSONObject("variant_check").put("region_visible",false);
  ok(IdentityHypothesisV359.comparison(unreadableEvent,lugiaTarget,lugiaRow).length()>0,"Unreadable event remains unknown rather than becoming physical veto");
  JSONObject matchedEvent=cp(lugiaRaw);matchedEvent.getJSONObject("variant_check").getJSONObject("event_logo").put("text","30th Anniversary");matchedEvent.getJSONObject("variant_check").put("selected_variant","30th Anniversary Holo");
  ok(IdentityHypothesisV359.comparison(matchedEvent,lugiaTarget,lugiaRow).length()>0,"Same visible event permits probable candidate");
  row=cp(zh.getJSONObject("row"));row.put("product-name","Roronoa Zoro [Alternate Art 1st Edition] OP01-025");
  ok(IdentityHypothesisV359.comparison(raw,zt,row).length()==0,"Explicit visible first_edition false rejects first-edition reference");
  JSONObject firstRaw=cp(raw);firstRaw.getJSONObject("printing_evidence").put("first_edition",true);
  ok(IdentityHypothesisV359.comparison(firstRaw,zt,row).length()>0,"Matching visible first edition permits reference");
  row=cp(zh.getJSONObject("row"));row.put("product-name","Roronoa Zoro [Alternate Art Winner] OP01-025");
  ok(IdentityHypothesisV359.comparison(raw,zt,row).length()==0,"Visible absent prize mark rejects Winner reference");
  row=cp(zh.getJSONObject("row"));row.put("product-name","Roronoa Zoro [Manga] OP01-025");
  ok(IdentityHypothesisV359.comparison(raw,zt,row).length()==0,"Visible alternate artwork rejects Manga reference");
  row=cp(zh.getJSONObject("row"));row.put("product-name","Roronoa Zoro [Non-Holo Alternate Art] OP01-025");
  ok(IdentityHypothesisV359.comparison(raw,zt,row).length()==0,"Visible foil rejects Non-Holo reference");
  row=cp(zh.getJSONObject("row"));row.getJSONObject("controller_candidate_v355").put("hard_conflicts",new JSONArray().put("PHYSICAL_EDITION"));
  ok(IdentityHypothesisV359.comparison(raw,zt,row).length()==0,"Recorded hard physical edition conflict is not ignored");
  row=cp(zh.getJSONObject("row"));row.getJSONObject("controller_candidate_v355").put("hard_conflicts",new JSONArray().put("UNKNOWN_HARD_CONFLICT"));
  ok(IdentityHypothesisV359.comparison(raw,zt,row).length()==0,"Unknown hard conflict fails closed for candidate price");
  row=cp(zh.getJSONObject("row"));row.getJSONObject("controller_candidate_v355").put("hard_conflicts",new JSONArray().put("MODEL_SET_MISMATCH").put("INFERRED_YEAR_MISMATCH"));
  ok(IdentityHypothesisV359.comparison(raw,zt,row).length()>0,"Explicit inferred model set/year conflicts are soft");
  row=cp(th.getJSONObject("price_reference_row"));row.put("product-name","Trade Please! #282/XY-P");ok(IdentityHypothesisV359.comparison(ControllerV348.original(trade),tt,row).length()==0,"Numbered reprint rejected for absent collector number");
  JSONObject changed=cp(trade);changed.remove("requests");ok(!IdentityHypothesisV359.hypothesis(changed).optString("provider").equals("cardtrader"),"Detached CT proof cannot be preferred");
  changed=cp(trade);changed.getJSONObject("cardtrader_visual_v168").getJSONObject("comparison").put("reference_image_sha256","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");ok(!IdentityHypothesisV359.hypothesis(changed).optString("provider").equals("cardtrader"),"Mismatched reference SHA cannot be preferred");
  for(String badName:new String[]{"Dark Trade Please!","Trade Please! Dark","Trade Please! Winner","Please!"}){
   changed=cp(trade);changed.getJSONObject("cardtrader_visual_v168").getJSONObject("comparison").put("reference_subject",badName);
   ok(!IdentityHypothesisV359.hypothesis(changed).optString("provider").equals("cardtrader"),"A prefix, suffix, or partial subject cannot be preferred: "+badName);
  }
  changed=cp(trade);changed.getJSONObject("cardtrader_visual_v168").getJSONObject("comparison").remove("user_subject");ok(!IdentityHypothesisV359.hypothesis(changed).optString("provider").equals("cardtrader"),"Missing current user name prevents preferred CT reference");
  changed=cp(trade);changed.getJSONObject("cardtrader_visual_v168").getJSONObject("comparison").put("user_subject","Dark Trade Please!");ok(!IdentityHypothesisV359.hypothesis(changed).optString("provider").equals("cardtrader"),"Different current user name prevents preferred CT reference");
  JSONObject tradeRaw=ControllerV348.original(trade);
  ok(ReviewEvidenceV356.subject(tradeRaw,tt,"とりかえっこプリーズ！ (Trade Please!)"),"Complete bilingual name allowed");
  ok(ReviewEvidenceV356.subject(tradeRaw,tt,"Trade Please!"),"Complete known translation allowed");
  ok(ReviewEvidenceV356.subject(tradeRaw,tt,"とりかえっこプリーズ！"),"Complete observed printed name allowed");
  ok(!ReviewEvidenceV356.subject(tradeRaw,tt,"Dark Trade Please!"),"Additional subject prefix is never stripped");
  ok(!ReviewEvidenceV356.subject(tradeRaw,tt,"Trade Please! Dark"),"Additional subject suffix is never stripped");
  JSONObject originalCopy=cp(lugia);ok(ControllerCompletionV358.exact(lugia),"Actual Lugia exact seal remains active");ok(lugia.toString().equals(originalCopy.toString()),"Lugia analysis is read-only");
  JSONObject noRows=cp(z);noRows.remove("catalog_snapshot_products_v284");noRows.remove("charting_selection");noRows.remove("charting_result");noRows.remove(ControllerAlgorithmsV355.KEY);
  JSONObject fallback=IdentityHypothesisV359.hypothesis(noRows);ok(fallback.optString("provider").equals("model"),"No catalog evidence closes on model hypothesis");ok(fallback.getJSONObject("target").optString("card_number").equals("OP01-025"),"Fallback preserves observed number");
  noRows.remove(ControllerCompletionV358.KEY);JSONObject primaryOnly=IdentityHypothesisV359.hypothesis(noRows),primaryTarget=primaryOnly.getJSONObject("target");
  ok(primaryOnly.optString("provider").equals("model"),"Actual primary schema without completion/catalog still yields model hypothesis");
  ok(primaryTarget.optString("subject").equals("Roronoa Zoro"),"Actual primary subject_name maps to subject");
  ok(primaryTarget.optString("set").equals("Romance Dawn"),"Actual primary set_name maps to set rather than being erased");
  ok(primaryTarget.optString("year").equals("2022"),"Actual primary year retained without prior normalized target");
  ok(primaryTarget.optString("language").equals("JPN"),"Actual primary card_language maps to language");
  ok(primaryTarget.optString("state").equals("RAW"),"Actual primary raw state retained");
  ok(primaryTarget.optString("category").equals("TCG"),"Actual primary analysis category retained");
  ok(primaryTarget.optString("variant").equals("Foil / Textured Alternate Art"),"Observed target finish is retained without hiding primary wording difference");
  JSONObject canonicalPrimary=IdentityHypothesisV359.modelIdentity(ControllerV348.original(z));
  ok(canonicalPrimary.optString("variant").equals("Parallel (Alternate Art)"),"Primary variant_or_parallel maps without rewriting its scope");
  JSONObject primarySlab=cp(ControllerV348.original(z));primarySlab.put("state","SLAB").put("grader","PSA").put("grade","10").put("grade_qualifier","OC");
  JSONObject canonicalSlab=IdentityHypothesisV359.modelIdentity(primarySlab);
  ok(canonicalSlab.optString("state").equals("SLAB"),"Primary slab state retained");
  ok(canonicalSlab.optString("grader").equals("PSA"),"Primary slab grader retained");
  ok(canonicalSlab.optString("grade").equals("10")&&canonicalSlab.optString("grade_qualifier").equals("OC"),"Primary slab grade and qualifier retained separately");
  System.out.println(new JSONObject().put("status","PASS").put("assertions",count).put("zoro_id",zh.optString("catalog_id")).put("trade_id",th.optString("catalog_id")).put("trade_price_reference_id",th.getJSONObject("price_reference_row").optString("id")));
 }
}
