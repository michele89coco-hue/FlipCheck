package com.flipcheck.nativebeta;
import org.json.*;
import java.nio.file.*;
public class PriceHypothesis359Test {
 static int assertions=0;
 static void check(boolean b,String m){assertions++;if(!b)throw new AssertionError(m);}
 static JSONObject load(String name)throws Exception{
  try(java.util.stream.Stream<Path> paths=Files.list(Paths.get("upload"))){Path path=paths.filter(p->p.getFileName().toString().startsWith("flipcheck-"+name)).findFirst().get();return new JSONObject(new String(Files.readAllBytes(path),"UTF-8"));}
 }
 static JSONObject cp(JSONObject r)throws Exception{return new JSONObject(r.toString());}
 static JSONObject o(JSONObject r,String k){return PriceHypothesisV359.o(r,k);}
 public static void main(String[] args)throws Exception{
  JSONObject z=load("05ca52dc"),t=load("69cfdfb1"),l=load("1604bbdc");
  JSONObject zh=IdentityHypothesisV359.hypothesis(z),th=IdentityHypothesisV359.hypothesis(t);
  JSONObject zq=PriceHypothesisV359.quote(z,zh),tq=PriceHypothesisV359.quote(t,th);
  check(zq.optString("catalog_id").equals("8508433"),"same-language PC candidate selected");
  check(zq.optDouble("amount")==52.62,"Zoro JPN 5895USDc translated with recorded ECB FX");
  check(tq.optString("catalog_id").equals("5154287"),"Trade original numberless reference selected");
  check(tq.optDouble("amount")==282.75,"Trade 31679USDc translated with recorded FX");
  for(JSONObject q:new JSONObject[]{zq,tq}){
   check(q.optBoolean("provisional_identity"),"explicitly probable estimate");
   check(!q.optBoolean("exact_identity_bound"),"no false exact printing proof");
   check(q.optString("currency").equals("EUR"),"currency from FX");
   check(q.optString("reference_language").equals("JPN"),"same JPN language");
   check(!q.optBoolean("language_adjustment_applied"),"no unnecessary EN discount");
   check(q.optString("catalog_snapshot_date").equals(q.optString("catalog_id").equals("8508433")?"2026-09-22":"2026-09-30"),"dated actual snapshot");
   check(q.optString("catalog_price_field").equals("loose-price"),"RAW price not slab");
  }
  check(PriceHypothesisV359.publish(z,zh),"publication returns available quote");
  check(o(o(z,"result"),"market").optDouble("current_estimate")==52.62,"active result contains probable quote");
  check(!ControllerV348.accepted(z),"quote does not accept identity");
  check(!FinalIdentityV319.active(z),"quote does not create catalogue seal");
  JSONObject wrong=cp(z);wrong.put("scan_id","unrelated");check(PriceHypothesisV359.quote(wrong,zh).length()==0,"cross-scan hypothesis rejected");
  JSONObject other=cp(zh);other.put("original_sha256","x");check(PriceHypothesisV359.quote(z,other).length()==0,"original hash mismatch rejected");
  JSONObject nofx=cp(t);nofx.remove("market_fx");JSONObject usd=PriceHypothesisV359.quote(nofx,th);
  check(usd.optString("currency").equals("USD"),"missing FX does not fabricate euro amount");check(usd.optDouble("amount")==316.79,"USD amount preserved");
  JSONObject slab=cp(zh);o(slab,"target").put("state","SLAB").put("grader","PSA").put("grade","10");JSONObject sq=PriceHypothesisV359.quote(z,slab);
  check(sq.optString("state").equals("SLAB"),"slab quote selected");check(sq.optString("grader").equals("PSA"),"exact grader price selected");check(sq.optString("grade").equals("10"),"exact grade selected");check(sq.optString("catalog_price_field").equals("manual-only-price"),"PSA10 field");
  JSONObject foreign=cp(zh);o(foreign,"target").put("language","ITA");JSONObject fq=PriceHypothesisV359.quote(z,foreign);
  check(fq.optBoolean("language_reference_only"),"language mismatch explicit");check(fq.optDouble("amount")==52.62,"no undocumented multiplier from JPN to ITA");
  JSONObject zero=cp(zh);o(zero,"row").put("loose-price",0);check(PriceHypothesisV359.quote(load("05ca52dc"),zero).length()==0,"zero native price never fabricated");
  JSONObject error=cp(th);o(error,"price_reference_row").put("loose-price",-100);check(PriceHypothesisV359.quote(t,error).length()==0,"negative money refused");
  check(o(o(l,"result"),"market").optDouble("current_estimate")==169.85,"actual exact Lugia price untouched");
  JSONObject english=cp(zh);o(english,"row").remove("page_language");o(english,"row").remove("language");o(english,"row").put("console-name","One Piece Romance Dawn");
  JSONObject eq=PriceHypothesisV359.quote(z,english);check(eq.optString("reference_language").equals("ENG"),"UNK falls through to existing English catalogue parser");check(eq.optInt("language_discount_percent")==18,"ENG to JPN estimate policy");
  check(!zq.optBoolean("indicative_grade")&&!zq.optString("qualification").contains("grado indicativo"),"RAW never mislabeled approximate grading");
  JSONObject current=load("05ca52dc"),mh=cp(zh),primary=cp(ControllerV348.original(current));
  mh.put("target",PriceHypothesisV359.primaryIdentity(primary)).put("row",new JSONObject()).put("catalog_id","").put("provider","model");
  JSONObject model=new JSONObject().put("currency","EUR").put("low",15).put("high",25).put("state","RAW").put("grader","").put("grade","").put("basis","MODEL_ESTIMATE");
  primary.put("market_estimate",model);current.put("identity_response_before_release_check",primary);mh.put("original_sha256",ObservedIdentityV309.hash(ControllerV348.original(current)));
  JSONObject mq=PriceHypothesisV359.quote(current,mh);check(mq.optDouble("amount")==20,"first-call explicit model range midpoint");check(mq.optBoolean("model_only_estimate")&&mq.optString("url").isEmpty(),"AI quote never invents market source");
  JSONObject badscope=cp(mh);o(badscope,"target").put("year","2040");check(PriceHypothesisV359.quote(current,badscope).length()==0,"model year mismatch rejected");
  JSONObject badset=cp(mh);o(badset,"target").put("set","Unknown unrelated set");check(PriceHypothesisV359.quote(current,badset).length()==0,"model set mismatch rejected");
  model.put("low",30);check(PriceHypothesisV359.quote(current,mh).length()==0,"inverted AI interval refused");
  model.put("low",40).put("high",80);o(mh,"target").put("variant","Foil / Textured Alternate Art");mh.put("original_sha256",ObservedIdentityV309.hash(ControllerV348.original(current)));
  JSONObject alias=PriceHypothesisV359.quote(current,mh);check(alias.optDouble("amount")==60,"actual alternate art synonym and extra foil description retain primary model estimate");
  check(o(mh,"target").optString("variant").equals("Foil / Textured Alternate Art"),"model quote does not rewrite observed variant");
  check(!PriceHypothesisV359.variantCompatible("One Piece","Parallel (Alternate Art)","Manga"),"different artwork rejected");
  check(!PriceHypothesisV359.variantCompatible("Pokemon","Non-Holo","Reverse Holo"),"different finish rejected");
  check(!PriceHypothesisV359.variantCompatible("One Piece","Alternate Art","Alternate Art Winner"),"extra prize stamp rejected");
  check(!PriceHypothesisV359.variantCompatible("Pokemon","Holo 25th Anniversary","Holo 30th Anniversary"),"different event rejected");
  check(!PriceHypothesisV359.variantCompatible("Pokemon","Holo","Holo Green"),"unknown parallel/color descriptor rejected");
  JSONObject stale=load("05ca52dc"),noquote=cp(zh);o(noquote,"row").put("loose-price",0);
  JSONObject sqold=cp(zq);sqold.remove("scan_id");sqold.remove("original_sha256");o(stale,"market_presentation").put("current",sqold);
  check(PriceHypothesisV359.quote(stale,noquote).length()==0,"quote without current scan/hash rejected");
  check(!PriceHypothesisV359.sameNumber("1/23","12/3"),"collector fractions never collapse punctuation");
  check(!PriceHypothesisV359.sameNumber("GG35","TG35"),"collector namespace retained");
  check(!PriceHypothesisV359.sameNumber("033/L-P","033/L"),"whole promo namespace retained");
  check(!PriceHypothesisV359.sameNumber("033/L-P","033L-P"),"promo slash separator retained");
  check(!PriceHypothesisV359.sameNumber("OP01-025","OP01025"),"set-code separator retained");
  check(!PriceHypothesisV359.sameNumber("TG01/TG30","TG01TG30"),"whole trainer-gallery fraction retained");
  check(PriceHypothesisV359.sameNumber("033/L-P","033/L-P"),"leading-zero promo number accepted intact");
  check(PriceHypothesisV359.sameNumber("","")&&!PriceHypothesisV359.sameNumber("","142/103"),"numberless distinct from numbered card");
  JSONObject s1=cp(o(mh,"target")),s2=cp(s1);s1.put("card_number","1/23");s2.put("card_number","12/3");check(!PriceHypothesisV359.sameScope(s1,s2),"storedquote complete fraction scope rejects destructive norm collision");
  s1.put("card_number","GG35");s2.put("card_number","TG35");check(!PriceHypothesisV359.sameScope(s1,s2),"stored quote namespace scope rejects mismatch");
  s1.put("card_number","033/L-P");s2.put("card_number","033/L-P");check(PriceHypothesisV359.sameScope(s1,s2)&&s2.optString("card_number").equals("033/L-P"),"scope retains leading zero and whole promo code");
  System.out.println("PASS "+assertions+" price hypothesis assertions; Zoro EUR52.62, Trade EUR282.75; zero API calls.");
 }
}
