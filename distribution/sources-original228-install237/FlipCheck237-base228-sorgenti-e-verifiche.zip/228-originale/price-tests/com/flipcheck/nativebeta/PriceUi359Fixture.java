package com.flipcheck.nativebeta;
import org.json.*;
import java.nio.file.*;
public class PriceUi359Fixture {
 public static void main(String[] args)throws Exception{
  Path directory=Paths.get("work359/ui-fixtures");Files.createDirectories(directory);
  for(String name:new String[]{"05ca52dc","69cfdfb1","1604bbdc"}){
   JSONObject record=PriceHypothesis359Test.load(name);ControllerCompletionV358.publish(record);
   Files.write(directory.resolve(name+".json"),record.toString().getBytes("UTF-8"));
  }
  JSONObject record=PriceHypothesis359Test.load("05ca52dc"),primary=PriceHypothesisV359.cp(ControllerV348.original(record));
  primary.put("market_estimate",new JSONObject().put("currency","EUR").put("low",40).put("high",80).put("state","RAW").put("grader","").put("grade","").put("basis","MODEL_ESTIMATE"));
  record.put("identity_response_before_release_check",primary);
  record.remove("catalog_snapshot_products_v284");record.remove("charting_selection");record.remove("charting_result");
  JSONObject algorithm=PriceHypothesisV359.o(record,ControllerAlgorithmsV355.KEY);algorithm.put("candidates",new JSONArray());
  ControllerCompletionV358.publish(record);
  JSONObject quote=PriceHypothesisV359.o(PriceHypothesisV359.o(record,"market_presentation"),"current");
  if(quote.optDouble("amount")!=60||!quote.optBoolean("model_only_estimate"))throw new AssertionError("actual model-only migration quote: "+quote);
  Files.write(directory.resolve("model-estimate-40-80.json"),record.toString().getBytes("UTF-8"));
  System.out.println("Wrote native migrated Zoro, Trade, Lugia and MODEL40–80→60 fixtures.");
 }
}
