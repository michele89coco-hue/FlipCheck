from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, tempfile, zipfile

root=Path(__file__).resolve().parent;out=root/'out';deliver=root/'deliverables'
deliver.mkdir(exist_ok=True)
backup=None if '--verify-only' in sys.argv else Path(sys.argv[1]).resolve()
signer=root.parent/'low-build/toolchain/work207/tools219/android-15/lib/apksigner.jar'
tools=signer.parent.parent
certificate='cf7cb81d2bcb16fd34b4e8ed87691d586417a579b5723a3d8d97cfd77386f04c'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit=json.loads((out/'package-audit.json').read_text());assert audit['status']=='PASS'
destination=deliver/'FlipCheck228.apk'
if backup is not None:
 os.chmod(backup,0o600)
 try:
  with tempfile.TemporaryDirectory(prefix='flipcheck359-sign-',dir='/tmp') as temp:
   private=Path(temp);os.chmod(private,0o700)
   with zipfile.ZipFile(backup) as archive:
    for name in ['flipcheck-release.p12','password.txt']:
     target=private/name;target.write_bytes(archive.read(name));os.chmod(target,0o600)
   keypass=private/'key-password.txt';keypass.write_bytes((private/'password.txt').read_bytes());os.chmod(keypass,0o600)
   result=subprocess.run(['java','-XX:-UsePerfData','-jar',str(signer),'sign',
     '--ks',str(private/'flipcheck-release.p12'),'--ks-type','PKCS12','--ks-key-alias','flipcheck',
     '--ks-pass','file:'+str(private/'password.txt'),'--key-pass','file:'+str(keypass),
     '--v1-signing-enabled','true','--v2-signing-enabled','true','--v3-signing-enabled','true',
     '--v4-signing-enabled','false','--out',str(private/'signed.apk'),str(out/'aligned.apk')],capture_output=True)
   if result.returncode:raise RuntimeError('APK signing failed; private diagnostics withheld')
   with zipfile.ZipFile(private/'signed.apk') as z:assert z.testzip() is None
   ready=destination.with_suffix('.ready')
   with (private/'signed.apk').open('rb') as src,ready.open('wb') as dst:
    shutil.copyfileobj(src,dst);dst.flush();os.fsync(dst.fileno())
   assert sha(ready)==sha(private/'signed.apk');ready.replace(destination)
 finally:backup.unlink(missing_ok=True)
def verify(apk):
 r=subprocess.run(['java','-XX:-UsePerfData','-jar',str(signer),'verify','--verbose','--print-certs',str(apk)],capture_output=True,text=True,check=True)
 assert re.search(r'Signer #1 certificate SHA-256 digest: '+certificate,r.stdout)
 for v in [1,2,3]:assert re.search(r'Verified using v'+str(v)+r' scheme.*: true',r.stdout)
 return r.stdout
verify(root.parent/'low-build/deliverables/FlipCheck227.apk')
(out/'signature-verification.txt').write_text(verify(destination))
with zipfile.ZipFile(out/'aligned.apk') as unsigned,zipfile.ZipFile(destination) as signed:
 assert signed.testzip() is None
 for name in unsigned.namelist():assert signed.read(name)==unsigned.read(name),name
 added=sorted(set(signed.namelist())-set(unsigned.namelist()))
 assert all(n.startswith('META-INF/') and n.endswith(('.MF','.RSA','.SF')) for n in added)
 assert hashlib.sha256(signed.read('classes.dex')).hexdigest()==audit['dex_sha256']
subprocess.run([str(tools/'zipalign'),'-c','-P','16','4',str(destination)],check=True)
badging=subprocess.run([str(tools/'aapt'),'dump','badging',str(destination)],capture_output=True,text=True,check=True).stdout.splitlines()[0]
assert "versionCode='359'" in badging and "versionName='2.31-test228'" in badging
signedaudit={'status':'PASS','apk':destination.name,'package':badging,'apk_sha256':sha(destination),
 'apk_bytes':destination.stat().st_size,'dex_sha256':audit['dex_sha256'],'certificate_sha256':certificate,
 'certificate_matches_previous_build':True,'apk_signature_schemes':[1,2,3],
 'signed_payload_matches_tested_unsigned_payload':True,'zipalign_16kb':True,
 'private_material_in_deliverables':False,'new_phone_scans':0,'live_api_calls':0,'device_latency_verified':False,
 'distribution':'INTERNAL_TEST_APK','production_release_gate_passed':False}
(out/'signed-audit.json').write_text(json.dumps(signedaudit,indent=2));print(json.dumps(signedaudit,indent=2))
