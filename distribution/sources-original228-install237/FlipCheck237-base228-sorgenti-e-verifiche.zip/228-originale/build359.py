from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
root=Path(__file__).resolve().parent;stage=root/'stage';stage.mkdir(exist_ok=True)
tools=root.parent/'low-build/toolchain/work207/tools219'
base=root.parent/'low-build/deliverables/FlipCheck227.apk'
host=root.parent/'low-build/stage/tested-helpers-host.jar'
oldhost=root.parent/'build226-review/source/work207/build357/patched357-host.jar'
android=tools/'android-all.jar'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args):subprocess.run([str(x) for x in args],check=True)
assert sha(base)=='359a5e86fbc3c4917af58a2793fdc5f7bf96343ce8ade1c50baae1ddd2d4b5c6'
with zipfile.ZipFile(base) as z:(stage/'base.dex').write_bytes(z.read('classes.dex'))
assert sha(stage/'base.dex')=='3350cd65e3d41eb8c73e92e928cb611ba180670861e25ad537e5bfe99c0c4dde'
if not (stage/'base-smali').exists():
 run(['java','-XX:-UsePerfData','-Xmx3g','-cp',tools/'*','org.jf.baksmali.Main','disassemble','--jobs','2',stage/'base.dex','-o',stage/'base-smali'])
shutil.rmtree(stage/'smali',ignore_errors=True);shutil.copytree(stage/'base-smali',stage/'smali')
sources=sorted((root/'src').rglob('*.java'));names={p.stem for p in sources}
assert names=={'ControllerCompletionV358','ReviewerV354','IdentityHypothesisV359','PriceHypothesisV359','QuickIdentityV359'},names
sourcehash={str(p.relative_to(root)):sha(p) for p in sources}
classes=stage/'classes';shutil.rmtree(classes,ignore_errors=True);classes.mkdir()
classpath=':'.join(map(str,[android,host,oldhost]))
run(['java','-XX:-UsePerfData','com.sun.tools.javac.Main','--release','8','-cp',classpath,'-d',classes,*sources])
with zipfile.ZipFile(stage/'helpers.jar','w') as z:
 for p in sorted(classes.rglob('*.class')):z.write(p,p.relative_to(classes).as_posix())
dexdir=stage/'helper-dex';shutil.rmtree(dexdir,ignore_errors=True);dexdir.mkdir()
run(['java','-XX:-UsePerfData','-Xmx2g','-cp',tools/'android-15/lib/d8.jar','com.android.tools.r8.D8',
 '--release','--min-api','23','--lib',android,'--classpath',host,'--classpath',oldhost,'--output',dexdir,stage/'helpers.jar'])
helpersmali=stage/'helper-smali';shutil.rmtree(helpersmali,ignore_errors=True)
run(['java','-XX:-UsePerfData','-Xmx2g','-cp',tools/'*','org.jf.baksmali.Main','disassemble','--jobs','2',dexdir/'classes.dex','-o',helpersmali])
for p in helpersmali.rglob('*.smali'):
 rel=p.relative_to(helpersmali);assert rel.parent.as_posix()=='com/flipcheck/nativebeta' and rel.stem in names,rel
 shutil.copyfile(p,stage/'smali'/rel)
package=stage/'smali/com/flipcheck/nativebeta'

def prefix(file,signature,code):
 p=package/file;text=p.read_text();start=text.index('.method static '+signature);end=text.index('.end method',start)
 block=text[start:end]
 # Insert after registers/annotations, before the original completion guard.
 at=block.index('    invoke-static')
 assert '.registers' in block[:at] and int(re.search(r'\.registers (\d+)',block).group(1))>=5
 p.write_text(text[:start]+block[:at]+code+block[at:]+text[end:])

prefix('ControllerAuthorityV350.smali','allow(Lorg/json/JSONObject;Ljava/lang/String;)Z',
 '    invoke-static {p0, p1}, Lcom/flipcheck/nativebeta/QuickIdentityV359;->skipReview(Lorg/json/JSONObject;Ljava/lang/String;)Z\n\n'
 '    move-result v0\n\n    if-eqz v0, :quick_v359_continue\n\n    const/4 v0, 0x0\n\n    return v0\n\n    :quick_v359_continue\n')
# The wire guard applies only to secondary identity phases; the initial image
# request and price-provider phases continue through their existing authority.
prefix('ControllerAuthorityV350.smali','authorizeRequest(Lorg/json/JSONObject;Ljava/lang/String;)Z',
 '    invoke-static {p1}, Lcom/flipcheck/nativebeta/ControllerAuthorityV350;->reviewPhase(Ljava/lang/String;)Z\n\n'
 '    move-result v0\n\n    if-eqz v0, :quick_v359_continue\n\n'
 '    invoke-static {p0}, Lcom/flipcheck/nativebeta/QuickIdentityV359;->fastReviewPolicy(Lorg/json/JSONObject;)Z\n\n'
 '    move-result v0\n\n    if-eqz v0, :quick_v359_continue\n\n    const/4 v0, 0x0\n\n    return v0\n\n    :quick_v359_continue\n')
p=package/'IdentityRequestV309.smali';text=p.read_text();start=text.index('.method static configure(Lorg/json/JSONObject;Ljava/lang/String;Lorg/json/JSONObject;)V')
end=text.index('.end method',start);block=text[start:end]
old='    invoke-static {p0, p1, p2}, Lcom/flipcheck/nativebeta/IdentityPromptV340;->configure(Lorg/json/JSONObject;Ljava/lang/String;Lorg/json/JSONObject;)V'
assert block.count(old)==1
hook='\n\n    invoke-static {p0, p1, p2}, Lcom/flipcheck/nativebeta/QuickIdentityV359;->apply(Lorg/json/JSONObject;Ljava/lang/String;Lorg/json/JSONObject;)V'
p.write_text(text[:start]+block.replace(old,old+hook)+text[end:])
for name in ['BuildConfig.smali','MainActivityV16.smali']:
 p=package/name;text=p.read_text();assert text.count('2.31-test227')==1;text=text.replace('2.31-test227','2.31-test228')
 if name=='BuildConfig.smali':
  assert text.count('VERSION_CODE:I = 0x166')==1;text=text.replace('VERSION_CODE:I = 0x166','VERSION_CODE:I = 0x167')
 p.write_text(text)
before={p.relative_to(stage/'base-smali').as_posix():sha(p) for p in (stage/'base-smali').rglob('*.smali')}
after={p.relative_to(stage/'smali').as_posix():sha(p) for p in (stage/'smali').rglob('*.smali')}
changed=sorted(k for k in before if before[k]!=after.get(k));added=sorted(set(after)-set(before))
prefixpath='com/flipcheck/nativebeta/'
required={prefixpath+n+'.smali' for n in ['ControllerCompletionV358','ControllerAuthorityV350','IdentityRequestV309','BuildConfig','MainActivityV16']}
assert required<=set(changed)<=required|{prefixpath+'ReviewerV354.smali'},changed
assert added==sorted(prefixpath+n+'.smali' for n in ['IdentityHypothesisV359','PriceHypothesisV359','QuickIdentityV359']),added
assert set(before)<=set(after)
run(['java','-XX:-UsePerfData','-Xmx3g','-cp',tools/'*','org.jf.smali.Main','assemble','--jobs','2','--api','23',stage/'smali','-o',stage/'patched.dex'])
assert sourcehash=={str(p.relative_to(root)):sha(p) for p in sources},'Source changed during compilation'
audit={'status':'PASS','base_classes':len(before),'final_classes':len(after),'changed_classes':changed,'added_classes':added,
 'other_class_sources_identical':True,'base227_six_hooks_preserved':True,'new_hooks':3,'source_sha256':sourcehash,
 'dex_sha256':sha(stage/'patched.dex'),'live_api_calls':0,'new_phone_scans':0}
(stage/'overlay-audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))
