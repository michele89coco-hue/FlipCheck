package com.flipcheck.nativebeta;
import org.json.*;import java.nio.file.*;import java.util.*;
public class QuickIdentity359Test {
 static int n;
 static void yes(boolean x,String m){n++;if(!x)throw new AssertionError(m);}
 static JSONObject copy(JSONObject x)throws Exception{return new JSONObject(x.toString());}
 static void requiredSame(JSONObject old,JSONObject now,String path){
  JSONArray req=old.optJSONArray("required");yes(String.valueOf(req).equals(String.valueOf(now.optJSONArray("required"))),"required unchanged "+path);
  JSONObject p=old.optJSONObject("properties"),q=now.optJSONObject("properties");
  for(int i=0;req!=null&&i<req.length();i++){String k=req.optString(i);yes(q!=null&&q.has(k),"required field retained "+path+"/"+k);requiredSame(p.optJSONObject(k),q.optJSONObject(k),path+"/"+k);}
 }
 public static void main(String[] args)throws Exception{
  for(String filename:args){JSONObject r=new JSONObject(new String(Files.readAllBytes(Paths.get(filename)),"UTF-8"));JSONObject req=r.getJSONArray("requests").getJSONObject(0);JSONObject old=copy(req.getJSONObject("generation_config").getJSONObject("responseSchema"));
   JSONObject photo=new JSONObject().put("inlineData",new JSONObject().put("mimeType","image/jpeg").put("data","UNCHANGED_CURRENT_IMAGE"));JSONObject ocr=new JSONObject().put("text","CURRENT OCR: "+r.optString("local_ocr_text"));
   JSONArray parts=new JSONArray().put(new JSONObject().put("text",req.getString("prompt"))).put(photo).put(ocr).put(new JSONObject().put("text","Controller evidence contract v349: native appendix"));
   JSONObject b=new JSONObject().put("contents",new JSONArray().put(new JSONObject().put("role","user").put("parts",parts))).put("generationConfig",copy(req.getJSONObject("generation_config")));
   QuickIdentityV359.apply(r,"identity",b);JSONObject cfg=b.getJSONObject("generationConfig"),schema=cfg.getJSONObject("responseSchema");requiredSame(old,schema,"root");
   JSONArray after=b.getJSONArray("contents").getJSONObject(0).getJSONArray("parts");yes(after.length()==3,"native instructions merged only");yes(after.getJSONObject(1).toString().equals(photo.toString()),"images exact");yes(after.getJSONObject(2).toString().equals(ocr.toString()),"OCR exact");
   yes(cfg.getInt("maxOutputTokens")==8192,"no truncation ceiling");yes(cfg.getJSONObject("thinkingConfig").getString("thinkingLevel").equals("low"),"LOW actual cfg");
   for(String k:new String[]{"analysis","printed_subject","card_language","state","grading_evidence","printing_evidence","variant_check","number_evidence","number_kind","other_number_observations","card_text","market_search"})yes(schema.getJSONObject("properties").has(k),"observations kept "+k);
   for(String k:new String[]{"aliases","distributions","market_query","riscontri_indizi"})yes(!schema.getJSONObject("properties").has(k),"duplicates omitted "+k);
   yes(schema.getJSONObject("properties").has("market_estimate"),"same primary optional estimate schema");yes(!QuickIdentityV359.required(schema,"market_estimate"),"estimate optional");
   JSONObject estimate=schema.getJSONObject("properties").getJSONObject("market_estimate");for(String k:new String[]{"currency","low","high","state","grader","grade","basis"})yes(estimate.getJSONObject("properties").has(k),"estimate field "+k);
   String serialized=b.toString();QuickIdentityV359.apply(r,"catalog_variant_verification",b);yes(serialized.equals(b.toString()),"other phase untouched");b.put("tools",new JSONArray());serialized=b.toString();QuickIdentityV359.apply(r,"identity",b);yes(serialized.equals(b.toString()),"tool requests untouched");
   if(filename.contains("69cfdfb1"))for(String reason:new String[]{"CONTROLLER_ALGORITHM_REVIEW","CARDTRADER_REVIEW","CATALOG_CHOICE","OCR_REVIEW","VARIANT_CHECK","REFERENCE_PREPARATION"})yes(QuickIdentityV359.skipReview(r,reason),"priced actual candidate skips known review "+reason);
   if(filename.contains("05ca52dc")){
    JSONObject modelRecord=copy(r);for(String key:new String[]{"controller_algorithms_v355","controller_completion_v358","catalog_snapshot_products_v284","charting_selection","charting_result","cardtrader_visual_v168","second_identity_call"})modelRecord.remove(key);
    JSONObject primary=copy(ControllerV348.original(modelRecord));JSONObject range=new JSONObject().put("currency","EUR").put("low",40).put("high",80).put("state","RAW").put("grader","").put("grade","").put("basis","MODEL_ESTIMATE");
    primary.put("market_estimate",range);modelRecord.put("identity_response_before_release_check",primary);
    yes(IdentityHypothesisV359.hypothesis(modelRecord).optString("provider").equals("model"),"no-catalog fixture uses model identity channel");
    for(String reason:new String[]{"CONTROLLER_ALGORITHM_REVIEW","CARDTRADER_REVIEW","CATALOG_CHOICE","OCR_REVIEW","VARIANT_CHECK","REFERENCE_PREPARATION"})yes(QuickIdentityV359.skipReview(modelRecord,reason),"same-primary model price skips review without row "+reason);
    yes(modelRecord.getJSONObject("quick_review_policy_v359").optString("basis").equals("CURRENT_PRIMARY_MODEL_ESTIMATE"),"model audit explicit");
    JSONObject badScope=copy(modelRecord);badScope.getJSONObject("identity_response_before_release_check").getJSONObject("analysis").getJSONObject("identity").put("year","2040");
    badScope.put("controller_algorithms_v355",new JSONObject().put("scan_id",badScope.optString("scan_id")).put("original_sha256",ObservedIdentityV309.hash(ControllerV348.original(badScope))).put("source_target",PriceHypothesisV359.primaryIdentity(primary)).put("candidates",new JSONArray()));
    yes(!QuickIdentityV359.fastReviewPolicy(badScope),"different primary estimate identity rejected");
    JSONObject contrary=copy(modelRecord);contrary.getJSONObject("identity_response_before_release_check").getJSONObject("analysis").getJSONObject("identity").put("variant_or_parallel","Manga");yes(!QuickIdentityV359.fastReviewPolicy(contrary),"contradicted artwork estimate rejected");
    JSONObject none=copy(modelRecord);none.getJSONObject("identity_response_before_release_check").remove("market_estimate");yes(!QuickIdentityV359.fastReviewPolicy(none),"no estimate keeps price/review channel open");
    JSONObject wrongState=copy(modelRecord);wrongState.getJSONObject("identity_response_before_release_check").getJSONObject("market_estimate").put("state","SLAB");yes(!QuickIdentityV359.fastReviewPolicy(wrongState),"wrong model price scope rejected");
    JSONObject conflict=copy(modelRecord);conflict.getJSONObject("identity_response_before_release_check").getJSONObject("variant_check").put("selected_variant","Alternate Art Winner").put("status","CONFIRMED").put("discriminating_detail",true).put("region_visible",true);
    yes(IdentityHypothesisV359.physical(ControllerV348.original(conflict)).optBoolean("conflict"),"contradictory winner-present and absent observations detected");
    yes(PriceHypothesisV359.quote(conflict,IdentityHypothesisV359.hypothesis(conflict)).optDouble("amount",0)>0,"scope-valid model amount is not physical proof");yes(!QuickIdentityV359.fastReviewPolicy(conflict),"physical contradiction preserves review despite model amount");
   }
  }
  JSONObject h=new JSONObject().put("catalog_id","123").put("target",new JSONObject().put("subject","Any card")).put("row",new JSONObject().put("id","123").put("loose-price",100));JSONObject r=new JSONObject();
  yes(QuickIdentityV359.fastReady(r,h),"priced likely candidate allows quick gate");h.getJSONObject("row").put("controller_candidate_v355",new JSONObject().put("hard_conflicts",new JSONArray().put("NUMBER")));yes(!QuickIdentityV359.fastReady(r,h),"hard conflict keeps review");h.getJSONObject("row").remove("controller_candidate_v355");h.getJSONObject("row").remove("loose-price");yes(!QuickIdentityV359.fastReady(r,h),"no price does not stop price route");
  for(String reason:new String[]{"identity","PRICE_LOOKUP","PRIMARY_CONTROLLER","market_estimate","SLAB_LABEL_IDENTITY",null})yes(!QuickIdentityV359.skipReview(r,reason),"non-review gate untouched "+reason);
  System.out.println("QuickIdentity359Test PASS "+n+" assertions; prompt chars="+QuickIdentityV359.PROMPT.length()+" words="+QuickIdentityV359.PROMPT.split("\\s+").length);
 }
}
