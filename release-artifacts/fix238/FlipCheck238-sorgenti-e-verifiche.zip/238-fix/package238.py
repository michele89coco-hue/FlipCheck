"""Version, align, sign and verify the tested payload. Never delete signing backup."""
from pathlib import Path
import argparse,hashlib,json,struct,zipfile,copy,subprocess,tempfile,os,re
parser=argparse.ArgumentParser();parser.add_argument('--tools',type=Path,required=True);parser.add_argument('--base-apk',type=Path,required=True);parser.add_argument('--signing-backup',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
root=Path(__file__).resolve().parent;stage=root/'package';stage.mkdir(exist_ok=True);tools=args.tools.resolve()/'android-15';destination=args.output.resolve();destination.parent.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();cert='cf7cb81d2bcb16fd34b4e8ed87691d586417a579b5723a3d8d97cfd77386f04c'
assert sha(args.base_apk.read_bytes())=='1c9d53c0066820e464bceb6fb26087546b3da670a0c523b9ad428dcefadb0b92'
report=json.loads((root/'test-output/verification.json').read_text());dex=(root/'build/patched.dex').read_bytes();assert report['status']=='PASS' and report['tested_dex_sha256']==sha(dex)
u16=lambda b,p:struct.unpack_from('<H',b,p)[0];u32=lambda b,p:struct.unpack_from('<I',b,p)[0]
def strings(b,at):
 result=[];count=u32(b,at+8);start=at+u32(b,at+20);flags=u32(b,at+16);header=u16(b,at+2)
 for i in range(count):
  p=start+u32(b,at+header+4*i)
  if flags&256:
   def length(p):
    v=b[p];return ((((v&127)<<8)|b[p+1]),p+2) if v&128 else (v,p+1)
   _,p=length(p);n,p=length(p);encoding='utf-8'
  else:
   n=u16(b,p);p+=2
   if n&32768:n=((n&32767)<<16)|u16(b,p);p+=2
   n*=2;encoding='utf-16le'
  result.append((b[p:p+n].decode(encoding),p,n,encoding))
 return result
def sig(n):return n.startswith('META-INF/') and n.endswith(('.SF','.RSA','.DSA','.EC','.MF'))
with zipfile.ZipFile(args.base_apk) as base:
 manifest=base.read('AndroidManifest.xml');b=bytearray(manifest);at=8;table=None;code_at=None
 while at<len(b):
  kind,size=u16(b,at),u32(b,at+4);assert size>=8
  if kind==1:table=strings(b,at)
  if kind==258 and table[u32(b,at+20)][0]=='manifest':
   start=at+16+u16(b,at+24);width,count=u16(b,at+26),u16(b,at+28)
   for i in range(count):
    p=start+width*i;name=table[u32(b,p+4)][0]
    if name=='versionCode':assert code_at is None and b[p+15]==16 and u32(b,p+16)==368;code_at=p+16;struct.pack_into('<I',b,code_at,369)
    if name=='versionName':assert table[u32(b,p+16)][0]=='2.31-test237'
  at+=size
 assert code_at is not None
 old=[v for v in table if v[0]=='2.31-test237'];assert len(old)==1;_,name_at,n,encoding=old[0];v='2.31-test238'.encode(encoding);assert len(v)==n;b[name_at:name_at+n]=v
 diff={i for i,(x,y) in enumerate(zip(manifest,b)) if x!=y};assert diff<=(set(range(code_at,code_at+4))|set(range(name_at,name_at+n)))
 expected={'AndroidManifest.xml':bytes(b),'classes.dex':dex,'assets/fixes280.js':(root.parent/'228-originale/assets/fixes280.js').read_bytes()}
 with zipfile.ZipFile(stage/'unsigned.apk','w') as z:
  for e in base.infolist():
   if not sig(e.filename):z.writestr(copy.copy(e),expected.get(e.filename,base.read(e.filename)))
run=lambda v:subprocess.run(list(map(str,v)),check=True,capture_output=True,text=True)
for n in ['zipalign','aapt']:os.chmod(tools/n,0o755)
run([tools/'zipalign','-P','16','-f','4',stage/'unsigned.apk',stage/'aligned.apk'])
with tempfile.TemporaryDirectory(prefix='flipcheck238-sign-',dir='/tmp') as temporary:
 private=Path(temporary);os.chmod(private,0o700)
 from cryptography.hazmat.primitives.serialization import Encoding,PrivateFormat,NoEncryption
 from cryptography.hazmat.primitives.serialization.pkcs12 import load_key_and_certificates
 from cryptography.hazmat.primitives import hashes
 with zipfile.ZipFile(args.signing_backup) as z:
  key,certificate,others=load_key_and_certificates(z.read('flipcheck-release.p12'),z.read('password.txt'))
 assert certificate.fingerprint(hashes.SHA256()).hex()==cert
 keypath=private/'key.pk8';certpath=private/'certificate.pem'
 keypath.write_bytes(key.private_bytes(Encoding.DER,PrivateFormat.PKCS8,NoEncryption()));os.chmod(keypath,0o600)
 certpath.write_bytes(certificate.public_bytes(Encoding.PEM));os.chmod(certpath,0o600)
 result=subprocess.run(['java','-jar',str(tools/'lib/apksigner.jar'),'sign','--key',str(keypath),'--cert',str(certpath),'--v1-signing-enabled','true','--v2-signing-enabled','true','--v3-signing-enabled','true','--v4-signing-enabled','false','--out',str(destination),str(stage/'aligned.apk')],capture_output=True)
 if result.returncode:raise RuntimeError('APK signing failed; private diagnostics withheld')
verify=run(['java','-jar',tools/'lib/apksigner.jar','verify','--verbose','--print-certs',destination]).stdout
assert 'Signer #1 certificate SHA-256 digest: '+cert in verify
for v in [1,2,3]:assert re.search('Verified using v'+str(v)+r' scheme.*: true',verify)
run([tools/'zipalign','-c','-P','16','4',destination]);badging=run([tools/'aapt','dump','badging',destination]).stdout.splitlines()[0];assert "versionCode='369'" in badging and "versionName='2.31-test238'" in badging
changed=[]
with zipfile.ZipFile(args.base_apk) as base,zipfile.ZipFile(destination) as final:
 assert final.testzip() is None
 assert {n for n in base.namelist() if not sig(n)}=={n for n in final.namelist() if not sig(n)}
 for n in base.namelist():
  if sig(n):continue
  if base.read(n)!=final.read(n):changed.append(n)
  assert final.read(n)==expected.get(n,base.read(n)),n
assert sorted(changed)==sorted(expected)
audit={'status':'PASS','package':badging,'version_name':'2.31-test238','version_code':369,'apk':destination.name,'apk_bytes':destination.stat().st_size,'apk_sha256':sha(destination.read_bytes()),'tested_dex_sha256':sha(dex),'certificate_sha256':cert,'same_certificate_as_237':True,'signature_schemes':[1,2,3],'zipalign_16kb':True,'changed_payload_entries':changed,'all_other_payload_entries_identical':True,'private_signing_material_in_package':False,'new_phone_scans':0,'live_api_calls':0,'device_latency_verified':False}
(root/'test-output/package-verification.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))
