const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname);let checks=0,lateCalls=0,nativeCalls=0;
function ok(x,reason){checks++;if(!x)throw Error(reason);}
function copy(x){return JSON.parse(JSON.stringify(x));}
class Element{
 constructor(text=''){this.own=text;this.children=[];this.dataset={};this.style={};this.hidden=false;this.attrs={};this.classes=new Set();this.classList={toggle:(k,v)=>v?this.classes.add(k):this.classes.delete(k)};}
 get textContent(){return this.children.length?this.children.map(x=>x.textContent).join(''):this.own;}
 set textContent(x){this.own=String(x);this.children=[];}
 append(...xs){this.children.push(...xs);}
 querySelector(s){return this.map?.[s]||null;}
 querySelectorAll(s){return this.lists?.[s]||[];}
 setAttribute(k,v){this.attrs[k]=v;}
 remove(){}
}
const strong=new Element('Da verificare'),badgeNote=new Element('Apri i dettagli'),badge=new Element(),stateNote=new Element();badge.map={strong,p:badgeNote};
const identitySpan=new Element('Identità probabile'),identityIcon=new Element(),identityButton=new Element();identityButton.append(identitySpan);identityButton.map={span:identitySpan,svg:identityIcon};
const chart=new Element(),gauge=new Element();for(const e of [chart,gauge])e.map={'.instrument-label':new Element(),'.instrument-empty':new Element(),'.instrument-caption':new Element()};
const trend=new Element();trend.map={span:new Element()};
const nodes={set:new Element(),chartPreview:chart,liquidityPreview:gauge,rarokTrend174:trend,valueLabel:new Element(),range:new Element()};
const context={console,state:{record:null},cropPreviewActive:false,
 document:{querySelector:s=>({'.rr-verified':badge,'.rr-state-note':stateNote})[s]||null,querySelectorAll:s=>s==='.rr-sources button'?[identityButton]:[]},$(){return nodes[arguments[0]]||null;},
 marketCondition:r=>r.market_presentation?.current||r.result?.identity,marketConditionLabel:r=>r?.state==='RAW'?'Raw':[r?.grader,r?.grade].filter(Boolean).join(' '),
 marketPresentation218:{labels:q=>({title:'Valore',caption:'Stima da catalogo',detail:q.qualification||''})},
 marketLiquidity:r=>{const key=context.marketInstrumentReference(r,'volume').key,v=r.catalog_page?.volume?.[key];return v?{level:1,text:v.count+' vendite',source:v}:{level:null};},
 marketReferenceLabel:()=>'',marketInstrumentReference:()=>({key:null}),showMarketLiquidity(){},
 marketAnchor:r=>r.catalog_match||r.market_presentation?.current||null,
 renderResult(){},renderMarketInstruments(){},showTab(){},el(){return new Element();},native(){nativeCalls++;},marketPageRequests:new Set(),
 window:{receiveMarketPage(page){lateCalls++;context.state.record.catalog_page=page;},addEventListener(){}},requestAnimationFrame(){}};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root,'instruments279.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(root,'../228-originale/assets/fixes280.js'),'utf8'),context);
const api=context.window.fixes280;
const records=Object.fromEntries(['lugia','pikachu','bulbasaur'].map(n=>[n,JSON.parse(fs.readFileSync(path.join(root,'test-output',n+'.json'),'utf8'))]));
context.state.record=copy(records.pikachu);context.renderResult();
const q=api.probableQuote(records.pikachu);
ok(q&&q.amount===180.07&&q.provider==='cardtrader','Native Pikachu asking mean visible');
ok(nodes.valueLabel.textContent==='Prezzo richiesto · CardTrader','Source and asking-price label visible');
ok(trend.map.span.textContent.includes('CardTrader'),'CardTrader named in caption');
ok(api.probableAnchor(records.pikachu)===null,'CardTrader offers cannot create unrelated PriceCharting chart');
ok(api.probableQuote(records.lugia)===null,'No wrong Lugia price visible');
ok(api.resolved(records.bulbasaur),'Bulbasaur remains verified');
for(const mutate of [x=>x.scan_id='other',x=>x.market_presentation.current.amount=1,x=>x.price_hypothesis_v359.decision.quote.model_only_estimate=true,x=>x.price_hypothesis_v359.decision.quote.kind='ai_deduced',x=>x.price_hypothesis_v359.decision.quote.basis='CURRENT_PRIMARY_MODEL_ESTIMATE']){
 const stale=copy(records.pikachu);mutate(stale);ok(api.probableQuote(stale)===null,'Invalid/stale/AI quote hidden');
}
ok(nativeCalls===0,'UI adds no provider or AI requests');
const report={status:'PASS',checks,real_native_fixtures:true,device_browser_render:false,live_api_calls:0};
fs.writeFileSync(path.join(root,'test-output','ui-report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
