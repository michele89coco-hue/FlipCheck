from pathlib import Path
import argparse,subprocess,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--tools',type=Path,required=True);p.add_argument('--logs',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parent;tools=a.tools.resolve();out=root/'test-output';out.mkdir(exist_ok=True);host=root/'build/final238-host.jar'
def run(args):subprocess.run(list(map(str,args)),check=True)
run(['bash',tools/'dex-tools-v2.4/d2j-dex2jar.sh','-f',root/'build/patched.dex','-o',host])
classes=root/'testclasses';classes.mkdir(exist_ok=True)
run(['java','com.sun.tools.javac.Main','-source','8','-target','8','-Xlint:-options','-cp',str(host)+':'+str(tools/'android-all.jar'),'-d',classes,root/'Fix238Regression.java',root/'Wire238Test.java'])
logs=[next(a.logs.glob(f'{i}-*.json')) for i in [1,2,3]]
cp=str(classes)+':'+str(tools/'android-all.jar')+':'+str(host)
run(['java','-cp',cp,'com.flipcheck.nativebeta.Fix238Regression',*logs,out])
run(['java','-cp',cp,'com.flipcheck.nativebeta.Wire238Test',*logs,root/'old-duplicated-prompt.txt',out/'wire-report.json'])
run(['node',root/'ui238-test.js'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'status':'PASS','tested_dex_sha256':sha(root/'build/patched.dex'),'runtime':'DEX_TO_JAR_ACTUAL_FINAL_IMPLEMENTATION','android_json_runtime':True,'source_stubs_used':False,'new_phone_scans':0,'live_api_calls':0,'device_latency_verified':False,'reports':[json.loads((out/n).read_text()) for n in ['regression-report.json','wire-report.json','ui-report.json']]}
(out/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='reports'},indent=2))
