package com.flipcheck.nativebeta;
import org.json.*;
import java.nio.file.*;
import java.util.*;
public class Fix238Regression {
 static int checks=0;
 static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
 static JSONObject copy(JSONObject r)throws Exception{return new JSONObject(r.toString());}
 static JSONObject read(String p)throws Exception{return new JSONObject(new String(Files.readAllBytes(Paths.get(p)),"UTF-8"));}
 public static void main(String[] args)throws Exception{
  JSONObject lugia=read(args[0]),pikachu=read(args[1]),bulba=read(args[2]);
  JSONObject target=IdentityHypothesisV359.initial(pikachu);
  check(target.optString("variant").equals("Special Illustration Rare"),"Pikachu rarity preserved, foil separate");
  JSONObject q=PriceHypothesisV359.nativeCardTraderQuote(pikachu,target);
  check(Math.abs(q.optDouble("amount")-180.07)<0.005,"Pikachu current native quote = 180.07 EUR: "+q);
  JSONObject staleTime=copy(pikachu);JSONObject staleAudit=staleTime.getJSONObject(ControllerCompletionV358.KEY).getJSONObject("unverified_market_audit");
  staleAudit.getJSONObject("current_quote").put("retrieved_at",1);staleAudit.getJSONObject("cardtrader_active").put("retrieved_at",1);
  check(PriceHypothesisV359.nativeCardTraderQuote(staleTime,target).length()==0,"quote acquired before scan rejected");
  JSONObject h=IdentityHypothesisV359.hypothesis(pikachu);
  check("cardtrader".equals(h.optString("provider")),"Native CardTrader hypothesis selected: "+h);
  check("370914".equals(h.optString("catalog_id")),"correct blueprint");
  ControllerCompletionV358.publish(pikachu);
  check(Math.abs(pikachu.getJSONObject("result").getJSONObject("market").optDouble("current_estimate")-180.07)<0.005,"Pikachu quote survives terminal publish");
  check(pikachu.getJSONObject("price_policy_v231").optBoolean("has_price"),"price policy reflects publication");
  String stable=pikachu.getJSONObject("result").getJSONObject("market").toString();ControllerCompletionV358.publish(pikachu);
  check(stable.equals(pikachu.getJSONObject("result").getJSONObject("market").toString()),"repeat publication preserves quote");
  JSONObject foreign=copy(pikachu);foreign.put("scan_id","different-scan");
  check(PriceHypothesisV359.nativeCardTraderQuote(foreign,target).length()==0,"quote from another scan rejected");
  check(PriceHypothesisV359.nativeCardTraderQuote(pikachu,copy(target).put("set","Other Release")).length()==0,"wrong release rejected");
  JSONObject changed=copy(pikachu);JSONObject changedTarget=copy(target).put("card_number","276/217");
  check(PriceHypothesisV359.nativeCardTraderQuote(changed,changedTarget).length()==0,"neighboring number rejected");
  check(PriceHypothesisV359.nativeCardTraderQuote(changed,copy(target).put("language","JPN")).length()==0,"wrong-language offers rejected");
  check(PriceHypothesisV359.nativeCardTraderQuote(changed,copy(target).put("state","SLAB").put("grader","PSA").put("grade","10")).length()==0,"RAW offers do not become graded quote");
  JSONObject archived=changed.getJSONObject(ControllerCompletionV358.KEY).getJSONObject("unverified_market_audit");
  archived.getJSONObject("current_quote").put("scan_id","stale");archived.getJSONObject("cardtrader_active").put("scan_id","stale");changed.remove("cardtrader_active");changed.getJSONObject("market_presentation").put("current",JSONObject.NULL);
  check(PriceHypothesisV359.nativeCardTraderQuote(changed,target).length()==0,"explicit stale bindings are never rebound");
  h=IdentityHypothesisV359.hypothesis(lugia);
  check(h.optString("catalog_id").isEmpty(),"Lugia cannot select official price for metallic custom observation: "+h);
  check(PriceHypothesisV359.quote(lugia,h).length()==0,"Lugia incompatible catalogue and primary AI estimate rejected");
  check(!QuickIdentityV359.fastReviewPolicy(lugia),"Lugia cannot skip review based on wrong catalogue price");
  ControllerCompletionV358.publish(lugia);
  check(lugia.getJSONObject("result").getJSONObject("market").isNull("current_estimate"),"Lugia no misleading price at terminal publication");
  check(!lugia.getJSONObject("price_policy_v231").optBoolean("has_price"),"missing-price policy synchronized");
  check(PriceHypothesisV359.primaryEstimate(lugia,h).length()==0,"primary AI price dormant");
  JSONObject oldBulba=copy(bulba.getJSONObject("result").getJSONObject("market"));ControllerCompletionV358.publish(bulba);
  check(oldBulba.toString().equals(bulba.getJSONObject("result").getJSONObject("market").toString()),"Bulbasaur verified market unchanged");
  for(JSONObject r:new JSONObject[]{lugia,pikachu,bulba})check("DISABLED_USER_POLICY".equals(r.getJSONObject("ai_estimate").optString("status")),"AI flag disabled all outcomes");
  JSONObject schema=new JSONObject().put("type","OBJECT").put("properties",new JSONObject().put("number_evidence",new JSONObject().put("type","OBJECT")).put("market_estimate",new JSONObject().put("type","OBJECT"))).put("required",new JSONArray().put("number_evidence").put("market_estimate"));
  JSONObject photo=new JSONObject().put("inlineData",new JSONObject().put("mimeType","image/jpeg").put("data","UNCHANGED_IMAGE_DATA"));
  JSONObject body=new JSONObject().put("systemInstruction",new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text","Identifica la carta nelle foto e crop forniti. "+String.join("",Collections.nCopies(90,"original full instructions ")))).put(new JSONObject().put("text","Unrelated system instruction retained"))))
   .put("contents",new JSONArray().put(new JSONObject().put("role","user").put("parts",new JSONArray().put(photo).put(new JSONObject().put("text","OCR: 277/217 ASC IT" )).put(new JSONObject().put("text","Controller evidence contract v349: old appendix")))))
   .put("generationConfig",new JSONObject().put("responseSchema",schema));
  String image=photo.toString();QuickIdentityV359.apply(pikachu,"identity",body);
  check(body.getJSONObject("systemInstruction").getJSONArray("parts").getJSONObject(0).optString("text").equals(QuickIdentityV359.PROMPT),"short prompt installed in actual system channel");
  check(image.equals(body.getJSONArray("contents").getJSONObject(0).getJSONArray("parts").getJSONObject(0).toString()),"image unchanged");
  check(body.getJSONArray("contents").getJSONObject(0).getJSONArray("parts").getJSONObject(1).optString("text").equals("OCR: 277/217 ASC IT"),"OCR unchanged");
  check(body.getJSONArray("contents").getJSONObject(0).getJSONArray("parts").length()==2,"duplicate controller appendix removed");
  check(!schema.getJSONObject("properties").has("market_estimate"),"no AI price request in schema");
  check(schema.getJSONArray("required").length()==1,"removed required AI estimate without losing observed number");
  String idempotent=body.toString();QuickIdentityV359.apply(pikachu,"identity",body);check(idempotent.equals(body.toString()),"prompt transform idempotent");
  JSONObject other=copy(body);String unchanged=other.toString();QuickIdentityV359.apply(pikachu,"catalog_variant_verification",other);check(unchanged.equals(other.toString()),"secondary phase unchanged");
  other.put("tools",new JSONArray());unchanged=other.toString();QuickIdentityV359.apply(pikachu,"identity",other);check(unchanged.equals(other.toString()),"tool requests unchanged");
  JSONObject report=new JSONObject().put("status","PASS").put("checks",checks).put("pikachu_eur",180.07).put("lugia_price_available",false).put("bulbasaur_verified_price_preserved",true).put("ai_estimates_enabled",false).put("live_api_calls",0).put("new_phone_scans",0);
  if(args.length>3){
   Path out=Paths.get(args[3]);Files.createDirectories(out);
   Files.write(out.resolve("regression-report.json"),report.toString(2).getBytes("UTF-8"));
   for(JSONObject r:new JSONObject[]{lugia,pikachu,bulba}){
    JSONObject fixture=new JSONObject();for(String key:new String[]{"scan_id","state","controller_completion_v358","price_hypothesis_v359","controller_v348","identity_processing_complete","result","market_presentation","catalog_page"})if(r.has(key))fixture.put(key,r.get(key));
    Files.write(out.resolve(r==lugia?"lugia.json":r==pikachu?"pikachu.json":"bulbasaur.json"),fixture.toString().getBytes("UTF-8"));
   }
  }
  System.out.println(report.toString(2));
 }
}
