package com.flipcheck.nativebeta;
import java.nio.file.*;
import org.json.*;
public class Wire238Test {
 static int checks;
 static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
 public static void main(String[] args)throws Exception{
  String duplicated=new String(Files.readAllBytes(Paths.get(args[3])),"UTF-8");JSONArray cases=new JSONArray();
  for(int k=0;k<3;k++){
   JSONObject r=Fix238Regression.read(args[k]),req=r.getJSONArray("requests").getJSONObject(0),cfg=new JSONObject(req.getJSONObject("generation_config").toString());
   JSONArray parts=new JSONArray();for(int i=0;i<4;i++)parts.put(new JSONObject().put("inlineData",new JSONObject().put("mimeType","image/jpeg").put("data","CURRENT_CROP_"+i)));
   parts.put(new JSONObject().put("text","OCR corrente: numero, copyright, logo, label conservati"));String evidence=parts.toString();
   parts.put(new JSONObject().put("text",duplicated));
   JSONObject body=new JSONObject().put("systemInstruction",new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",req.getString("prompt")))))
    .put("contents",new JSONArray().put(new JSONObject().put("role","user").put("parts",parts))).put("generationConfig",cfg);
   JSONArray required=cfg.getJSONObject("responseSchema").optJSONArray("required");
   int before=QuickIdentityV359.textChars(body);QuickIdentityV359.apply(r,"identity",body);int after=QuickIdentityV359.textChars(body);
   check(after<before,"actual main+duplicate instructions shortened");
   check(body.getJSONObject("systemInstruction").getJSONArray("parts").getJSONObject(0).optString("text").equals(QuickIdentityV359.PROMPT),"actual system instruction replaced");
   check(body.getJSONArray("contents").getJSONObject(0).getJSONArray("parts").toString().equals(evidence),"four image parts and OCR retained");
   JSONObject schema=cfg.getJSONObject("responseSchema");check(!schema.getJSONObject("properties").has("market_estimate"),"actual identity schema has no market estimate");
   for(int i=0;required!=null&&i<required.length();i++)if(!required.optString(i).equals("market_estimate"))check(QuickIdentityV359.required(schema,required.optString(i)),"required observation retained: "+required.optString(i));
   check(cfg.optInt("maxOutputTokens")==8192,"no new truncation risk");
   cases.put(new JSONObject().put("scan_id",r.optString("scan_id")).put("text_chars_before",before).put("text_chars_after",after).put("photos_ocr_changed",false));
  }
  JSONObject out=new JSONObject().put("status","PASS").put("checks",checks).put("cases",cases).put("device_latency_verified",false).put("wire_body_reconstructed",true).put("schema_source","ACTUAL_UPLOADED_LOGS");
  Files.write(Paths.get(args[4]),out.toString(2).getBytes("UTF-8"));System.out.println(out.toString(2));
 }
}
