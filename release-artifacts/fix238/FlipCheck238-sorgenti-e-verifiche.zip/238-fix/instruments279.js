/* Reference selection affects charts and liquidity only. Values always come from the bound catalog page. */
(()=>{
 const KEY='market_metrics_reference_v279';
 const norm=x=>String(x||'').toUpperCase().replace(/\s+/g,' ').trim();
 const grader=x=>{const s=norm(x);return /\bCGC\b|CERTIFIED GUARANTY/.test(s)?'CGC':/\bBGS\b|BECKETT/.test(s)?'BGS':/\bPSA\b|PROFESSIONAL SPORTS AUTHENTICATOR/.test(s)?'PSA':/\bSGC\b|SPORTSCARD GUARANTY/.test(s)?'SGC':s;};
 const fullGrade=r=>norm([r?.grade,r?.grade_qualifier].filter(Boolean).join(' ')).replace(/GEM MINT\s*/g,'').replace(/\bBLACK LABEL\b/g,'BLACK');
 function reference(rec){const r=rec?.[KEY]||rec?.catalog_page?.instrument_reference_v279;
  return r?.instruments_only&&r.price_adjusted===false&&/^\d+$/.test(String(r.catalog_id))&&/^https:\/\/www\.(pricecharting|sportscardspro)\.com\/game\/\d+$/.test(r.url||'')?r:null;
 }
 const priorAnchor=marketAnchor;marketAnchor=rec=>reference(rec)||priorAnchor(rec);
 function target(rec){const id=rec?.result?.identity;return id&&/^(RAW|SLAB)$/.test(id.state)?{state:id.state,grader:id.grader||'',grade:id.grade||'',grade_qualifier:id.grade_qualifier||''}:marketCondition(rec);}
 const standard={used:{state:'RAW',grader:'',grade:''},cib:{state:'SLAB',grader:'GENERIC',grade:'7 / 7.5'},new:{state:'SLAB',grader:'GENERIC',grade:'8 / 8.5'},graded:{state:'SLAB',grader:'GENERIC',grade:'9'},boxonly:{state:'SLAB',grader:'GENERIC',grade:'9.5'},manualonly:{state:'SLAB',grader:'PSA',grade:'10'}};
 function choose(rec,kind='series',days=365,now=Date.now()){
  const original=target(rec),page=rec?.catalog_page||{},a=reference(rec)||marketAnchor(rec);
  if(page.catalog_id&&a?.catalog_id&&String(page.catalog_id)!==String(a.catalog_id))return {key:null,row:original,fallback:false,reason:'CATALOG_MISMATCH'};
  const has=k=>kind==='volume'?(page.volume?.[k]?.rare===true||Number.isFinite(page.volume?.[k]?.monthly_equivalent)&&page.volume[k].monthly_equivalent>0):
   (page.series?.[k]||[]).some(p=>Array.isArray(p)&&Number.isFinite(p[0])&&Number.isFinite(p[1])&&p[1]>0&&p[0]>=now-days*86400000&&p[0]<=now);
  const conditions={...standard,...page.series_conditions};
  const available=Object.entries(conditions).filter(([k,r])=>r&&has(k));
  const same=(a,b)=>a.state===b.state&&(a.state==='RAW'||grader(a.grader)===grader(b.grader)&&fullGrade(a)===fullGrade(b));
  let match=available.find(([k,r])=>same(r,original)),reason='EXACT';
  if(!match&&original?.state==='SLAB'){
   const wanted=String(original.grade||'').match(/\d+(?:\.\d+)?/)?.[0];
   // A source interval containing the actual grade stays explicitly labelled as an interval.
   const includes=r=>r.state==='SLAB'&&wanted&&(String(r.grade).match(/\d+(?:\.\d+)?/g)||[]).includes(wanted);
   const equivalents=available.filter(([k,r])=>includes(r)&&!/(PRISTINE|BLACK)/.test(fullGrade(r)));
   equivalents.sort((a,b)=>{
    const rank=r=>grader(r.grader)===grader(original.grader)?0:grader(r.grader)==='PSA'?1:grader(r.grader)==='GENERIC'?2:3;
    return rank(a[1])-rank(b[1])||a[0].localeCompare(b[0]);
   });
   match=equivalents[0];reason='SAME_GRADE_REFERENCE';
   if(!match){match=available.find(([k,r])=>r.state==='RAW');reason='RAW_REFERENCE';}
  }
  if(!match)return {key:null,row:original,fallback:false,reason:'NO_DOCUMENTED_DATA'};
  return {key:match[0],row:match[1],fallback:!same(match[1],original),reason,requested:original};
 }
 marketInstrumentReference=choose;
 function language(rec){const ref=reference(rec),a=marketAnchor(rec),current=rec?.market_presentation?.current;
  const lang=ref?.reference_language||a?.reference_language||current?.price_quality_v272?.reference_language||rec?.result?.identity?.language;
  return ({ENG:'mercato inglese',JPN:'mercato giapponese',ITA:'mercato italiano',FRA:'mercato francese',DEU:'mercato tedesco',SPA:'mercato spagnolo',KOR:'mercato coreano',CHN:'mercato cinese'})[norm(lang)]|| (lang?'mercato '+lang:'');
 }
 marketReferenceLabel=function(rec,kind='series',days=365){const r=choose(rec,kind,days);
  return [(r.fallback?'Riferimento ':'')+marketConditionLabel(r.row),language(rec)].filter(Boolean).join(' · ');
 };
 const receive=window.receiveMarketPage;
 window.receiveMarketPage=function(page,expand){const rec=state.record;if(!rec||page.scan_id!==rec.scan_id)return;
  if(page.instrument_reference_v279){const probe={...rec,[KEY]:page.instrument_reference_v279};if(reference(probe))rec[KEY]=page.instrument_reference_v279;}
  return receive(page,expand);
 };
 const priorRender=renderMarketInstruments;
 renderMarketInstruments=function(...args){const result=priorRender.apply(this,args),rec=state.record;if(!rec||cropPreviewActive)return result;
  for(const [id,kind] of [['chartPreview','series'],['liquidityPreview','volume']]){
   const panel=$(id);if(!panel)continue;
   for(const n of panel.querySelectorAll('.reference279,.english-market203,.source-market274'))n.remove();
   const r=choose(rec,kind),label=marketReferenceLabel(rec,kind);
   for(const n of panel.querySelectorAll('.instrument-caption'))if(n.textContent.trim()===label)n.remove();
   const caption=el('span',label,'instrument-caption reference279');
   if(r.fallback)caption.title='Dati di riferimento: '+marketConditionLabel(r.row)+'. La tua carta: '+marketConditionLabel(r.requested)+'.';
   panel.append(caption);
   if(rec.catalog_page?.cached_after_error_v279)panel.append(el('span','Dati salvati · '+new Date(rec.catalog_page.retrieved_at).toLocaleDateString('it-IT'),'instrument-caption reference279'));
   if(id==='chartPreview'&&rec.catalog_page?.error){const empty=panel.querySelector('.instrument-empty');if(empty)empty.textContent='Storico temporaneamente non disponibile';panel.disabled=rec.state!=='DONE';
    panel.onclick=()=>{marketPageRequests.delete(rec.scan_id);native('catalogchart',rec.scan_id);};}
  }
  // A verified English candidate may exist even when the main price comes from eBay/CardTrader.
  if(rec.state==='DONE'&&!rec.catalog_page&&!marketPageRequests.has(rec.scan_id)){
   marketPageRequests.add(rec.scan_id);native('catalogpreview',rec.scan_id);
  }
  return result;
 };
 window.marketInstruments279={choose,reference,grader,language,target};
})();
