"""Compile the incremental fixes and overlay only audited classes on original 237."""
from pathlib import Path
import argparse, hashlib, json, re, shutil, subprocess, zipfile
parser=argparse.ArgumentParser();parser.add_argument('--tools',type=Path,required=True);parser.add_argument('--base-apk',type=Path,required=True);args=parser.parse_args()
root=Path(__file__).resolve().parent;source=root.parent/'228-originale';tools=args.tools.resolve();stage=root/'build';stage.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(v):subprocess.run(list(map(str,v)),check=True)
assert sha(args.base_apk)=='1c9d53c0066820e464bceb6fb26087546b3da670a0c523b9ad428dcefadb0b92'
with zipfile.ZipFile(args.base_apk) as z:(stage/'base.dex').write_bytes(z.read('classes.dex'))
assert sha(stage/'base.dex')=='4d8856a67f875780a71fac7d3a7930e7777f058d04195613a3325d398aca62f7'
base_smali=stage/'base-smali'
if not base_smali.exists():run(['java','-Xmx3g','-cp',str(tools/'*'),'org.jf.baksmali.Main','disassemble','--jobs','2',stage/'base.dex','-o',base_smali])
smali=stage/'smali';shutil.rmtree(smali,ignore_errors=True);shutil.copytree(base_smali,smali)
classes=stage/'classes';shutil.rmtree(classes,ignore_errors=True);classes.mkdir()
files=sorted((source/'src').rglob('*.java'));names={p.stem for p in files}
assert names=={'QuickIdentityV359','IdentityHypothesisV359','PriceHypothesisV359','ControllerCompletionV358','ReviewerV354'}
source_hashes={str(p.relative_to(source)):sha(p) for p in files}
if not (tools/'base238-host.jar').exists():run(['bash',tools/'dex-tools-v2.4/d2j-dex2jar.sh','-f',stage/'base.dex','-o',tools/'base238-host.jar'])
run(['java','com.sun.tools.javac.Main','-source','8','-target','8','-Xlint:-options','-cp',str(tools/'android-all.jar')+':'+str(tools/'base238-host.jar'),'-d',classes,*files])
with zipfile.ZipFile(stage/'helpers.jar','w') as z:
 for p in classes.rglob('*.class'):z.write(p,p.relative_to(classes))
helper_dex=stage/'helper-dex';shutil.rmtree(helper_dex,ignore_errors=True);helper_dex.mkdir()
run(['java','-Xmx2g','-cp',tools/'r8.jar','com.android.tools.r8.D8','--release','--min-api','23','--lib',tools/'android-all.jar','--classpath',tools/'base238-host.jar','--output',helper_dex,stage/'helpers.jar'])
helper_smali=stage/'helper-smali';shutil.rmtree(helper_smali,ignore_errors=True)
run(['java','-Xmx2g','-cp',str(tools/'*'),'org.jf.baksmali.Main','disassemble','--jobs','2',helper_dex/'classes.dex','-o',helper_smali])
for p in helper_smali.rglob('*.smali'):
 assert p.stem in names and p.relative_to(helper_smali).parent.as_posix()=='com/flipcheck/nativebeta'
 shutil.copyfile(p,smali/p.relative_to(helper_smali))
package=smali/'com/flipcheck/nativebeta'
p=package/'CardTraderClosureV317.smali';s=p.read_text();start=s.index('.method static afterCardTrader(Lorg/json/JSONObject;)V');end=s.index('.end method',start);block=s[start:end];at=block.index('    invoke-static')
assert 'captureCardTrader' not in block
hook='    invoke-static {p0}, Lcom/flipcheck/nativebeta/PriceHypothesisV359;->captureCardTrader(Lorg/json/JSONObject;)V\n\n'
p.write_text(s[:start]+block[:at]+hook+block[at:]+s[end:])
for name in ['BuildConfig','MainActivityV16']:
 p=package/(name+'.smali');s=p.read_text();assert s.count('2.31-test228')==1;s=s.replace('2.31-test228','2.31-test238')
 if name=='BuildConfig':assert s.count('VERSION_CODE:I = 0x167')==1;s=s.replace('VERSION_CODE:I = 0x167','VERSION_CODE:I = 0x171')
 p.write_text(s)
# The existing independent AI request policy must remain disabled as well.
policy=(package/'ReleasePolicyV300.smali').read_text();method=policy[policy.index('.method static priceAiEnabled('):];method=method[:method.index('.end method')]
assert 'const/4 p0, 0x0' in method and 'return p0' in method
before={str(p.relative_to(base_smali)):sha(p) for p in base_smali.rglob('*.smali')};after={str(p.relative_to(smali)):sha(p) for p in smali.rglob('*.smali')}
changed=sorted(k for k in before if before[k]!=after[k]);allowed={f'com/flipcheck/nativebeta/{name}.smali' for name in names|{'CardTraderClosureV317','BuildConfig','MainActivityV16'}}
assert set(before)==set(after) and set(changed)<=allowed
run(['java','-Xmx3g','-cp',str(tools/'*'),'org.jf.smali.Main','assemble','--jobs','2','--api','23',smali,'-o',stage/'patched.dex'])
assert source_hashes=={str(p.relative_to(source)):sha(p) for p in files}
audit={'status':'PASS','base_apk_sha256':sha(args.base_apk),'base_dex_sha256':sha(stage/'base.dex'),'final_dex_sha256':sha(stage/'patched.dex'),'classes':len(before),'changed_classes':changed,'other_class_sources_identical':True,'ai_request_policy_disabled':True,'source_sha256':source_hashes,'version_name':'2.31-test238','version_code':369,'new_phone_scans':0,'live_api_calls':0}
(stage/'build-audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))
