package com.flipcheck.nativebeta;
import org.json.*;

/** A sourced estimate for the selected probable identity. This never creates
 * an exact-printing proof and never authorizes an identity/catalogue seal. */
final class PriceHypothesisV359 {
 static final String KEY="price_hypothesis_v359";
 static JSONObject o(JSONObject r,String k){return CatalogEvidenceV150.obj(r,k);}
 static JSONObject cp(JSONObject r)throws Exception{return new JSONObject(r.toString());}
 static String hash(JSONObject r)throws Exception{return ObservedIdentityV309.hash(r);}
 static boolean positive(double value){return value>0&&!Double.isInfinite(value)&&!Double.isNaN(value);}
 static double rounded(double value){return Math.round(value*100.0)/100.0;}
 static boolean bound(JSONObject r,JSONObject h){try{
  return !r.optString("scan_id").isEmpty()&&r.optString("scan_id").equals(h.optString("scan_id"))
   &&hash(ControllerV348.original(r)).equals(h.optString("original_sha256"));
 }catch(Exception ignored){return false;}}
 static String language(JSONObject row){
  String v=LanguageV100.normalize(row.optString("page_language",row.optString("language")));
  if(!v.isEmpty()&&!v.equals("UNK")&&!v.equals("UNKNOWN"))return v;
  v=CatalogEvidenceV150.productLanguage(row);
  if(!v.isEmpty()&&!v.equals("UNK")&&!v.equals("UNKNOWN"))return v;
  String console=row.optString("console-name").toLowerCase(java.util.Locale.ROOT);
  if(console.contains("japanese"))return "JPN";
  if(console.contains("italian"))return "ITA";
  if(console.contains("french"))return "FRA";
  if(console.contains("german"))return "GER";
  return "";
 }
 static JSONObject field(JSONObject target,JSONObject row)throws Exception{
  if(!"SLAB".equalsIgnoreCase(target.optString("state","RAW"))){
   return positive(row.optDouble("loose-price",0))||positive(o(row,"prices_eur").optDouble("loose-price",0))?CatalogQuotesV86.field("loose-price"):new JSONObject();
  }
  JSONObject indicative=new JSONObject();
  for(String[] f:ChartingV54.FIELDS){
   if(f[1].isEmpty()||!positive(row.optDouble(f[0],0))&&!positive(o(row,"prices_eur").optDouble(f[0],0)))continue;
   JSONObject d=CatalogQuotesV86.field(f[0]);d.put("field",f[0]);
   if(ChartingV54.gradeMatches(target,f[1],f[2]))return d;
   // Preserve the existing grade/qualifier policy. A same-numeric-grade
   // reference from another grader is an explicit indicative comparison.
   if(indicative.length()==0&&TcgOffersV111.indicativeGrade(target,f[1],f[2]))indicative=d;
  }
  return indicative;
 }
 static JSONObject catalogQuote(JSONObject r,JSONObject h,JSONObject row)throws Exception{
  if(row.optString("id").isEmpty())return new JSONObject();
  String provider=row.optString("provider"),source=row.optString("catalog_source"),sourceKey=row.optString("source_key");
  if(!provider.isEmpty()&&!provider.equals("pricecharting")&&!provider.equals("charting"))return new JSONObject();
  if(!source.startsWith("PRICECHARTING")&&!sourceKey.startsWith("pc:")&&!"pricecharting".equals(provider)&&!"pricecharting".equals(h.optString("provider")))return new JSONObject();
  JSONObject target=o(h,"target");
  if(IdentityHypothesisV359.comparison(ControllerV348.original(r),target,row).length()==0)return new JSONObject();
  JSONObject descriptor=field(target,row);
  if(descriptor.length()==0)return new JSONObject();
  String field=descriptor.optString("field","loose-price"),sourceId=row.optString("id");
  double eur=o(row,"prices_eur").optDouble(field,0),usd=row.optDouble(field,0)/100.0;
  boolean directEur=positive(eur);if(!directEur&&!positive(usd))return new JSONObject();
  JSONObject fx=o(r,"market_fx");double rate=fx.optDouble("rate_to_eur",0);
  // A missing FX rate does not become an invented euro amount.
  String currency=directEur||positive(rate)?"EUR":"USD";
  double amount=directEur?eur:positive(rate)?usd*rate:usd;
  String state=descriptor.optString("reference_state","RAW"),grader=descriptor.optString("grader"),grade=descriptor.optString("grade");
  boolean exactGrade=state.equals("RAW")||ChartingV54.gradeMatches(target,grader,grade);
  String date=row.optString("catalog_snapshot_date",o(r,"charting_result").optString("catalog_snapshot_date"));
  String title=row.optString("console-name")+" · "+row.optString("product-name");
  JSONObject q=new JSONObject().put("title",title).put("amount",rounded(amount)).put("currency",currency)
   .put("state",state).put("grader",grader).put("grade",grade).put("kind","probable_identity_estimate")
   .put("url","https://www.pricecharting.com/game/"+sourceId).put("catalog_id",sourceId)
   .put("catalog_source",row.optString("catalog_source","PRICECHARTING_CSV"))
   .put("catalog_snapshot_date",date).put("prices_are_live",false)
   .put("catalog_price_field",field).put("source_bound",true).put("exact_grade",exactGrade)
   .put("indicative_grade",!exactGrade).put("provisional_variant",true)
   .put("condition_scope",state.equals("RAW")?"RAW_UNSPECIFIED":"CATALOG_GRADE_REFERENCE")
   .put("retrieved_at",System.currentTimeMillis()).put("date","")
   .put("evidence","PriceCharting CSV "+date+", prodotto "+sourceId+", campo "+field+(directEur?" in EUR.":" in centesimi USD."));
  if(!directEur){q.put("original_amount",usd).put("original_currency","USD");if(positive(rate))q.put("fx",cp(fx));}
  String cardLanguage=LanguageV100.normalize(target.optString("language")),referenceLanguage=language(row);
  q.put("card_language",cardLanguage).put("reference_language",referenceLanguage)
   .put("catalog_language_evidence",new JSONObject().put("language",referenceLanguage).put("catalog_id",sourceId).put("console_name",row.optString("console-name")));
  String qualification="Stima per l'identità più probabile; stampa esatta non confermata. PriceCharting CSV"+(date.isEmpty()?"":" del "+date)+"; "+descriptor.optString("label")+".";
  if(!referenceLanguage.isEmpty()&&!cardLanguage.isEmpty()&&!referenceLanguage.equals(cardLanguage)){
   q.put("language_reference_only",true);
   if(referenceLanguage.equals("ENG")&&!cardLanguage.equals("ENG")){
    int discount=cardLanguage.equals("JPN")?18:25;
    q.put("language_reference_price",cp(q)).put("language_discount_percent",discount).put("language_factor",1-discount/100.0)
     .put("language_adjustment_applied",true).put("language_adjustment_basis","USER_LANGUAGE_ESTIMATE_POLICY")
     .put("amount",rounded(amount*(1-discount/100.0)));
    qualification+=" Riferimento ENG con coefficiente indicativo -"+discount+"% per "+cardLanguage+".";
   }else qualification+=" Riferimento in lingua "+referenceLanguage+", diverso dalla carta "+cardLanguage+".";
  }
  if(state.equals("SLAB")&&!exactGrade)qualification+=" Riferimento di grado indicativo, non vendita dello stesso grader e grado.";
  q.put("qualification",qualification);
  return q;
 }
 static boolean quoteScope(JSONObject q,JSONObject target){
  if(!positive(q.optDouble("amount",0))||!q.optString("currency").matches("[A-Z]{3}"))return false;
  String state=q.optString("state");if(!state.equalsIgnoreCase(target.optString("state","RAW")))return false;
  if(state.equalsIgnoreCase("SLAB"))return ChartingV54.gradeMatches(target,q.optString("grader"),q.optString("grade"))
   ||q.optBoolean("indicative_grade")&&TcgOffersV111.indicativeGrade(target,q.optString("grader"),q.optString("grade"));
  return true;
 }
 static boolean sameScope(JSONObject snapshot,JSONObject target){
  if(snapshot.optString("subject").isEmpty()||target.optString("subject").isEmpty())return false;
  for(String k:new String[]{"subject","year","set","state","grader","grade","grade_qualifier"})
   if(!CatalogSearchV349.norm(snapshot.optString(k)).equals(CatalogSearchV349.norm(target.optString(k))))return false;
  if(!sameNumber(snapshot.optString("card_number"),target.optString("card_number")))return false;
  if(!variantCompatible(target.optString("game",snapshot.optString("game")),snapshot.optString("variant"),target.optString("variant")))return false;
  String a=LanguageV100.normalize(snapshot.optString("language")),b=LanguageV100.normalize(target.optString("language"));
  return !a.equals("UNK")&&!a.equals("UNKNOWN")&&a.equals(b);
 }
 static boolean sameNumber(String a,String b){try{
  if(a.trim().isEmpty()||b.trim().isEmpty())return a.trim().isEmpty()&&b.trim().isEmpty();
  if(!CatalogRegistryV306.exactNumber(a,b))return false;
  if(CatalogDecisionV345.num(a).optBoolean("complete_fraction")||CatalogDecisionV345.num(b).optBoolean("complete_fraction"))return CatalogDecisionV345.sameComplete(a,b);
  return true;
 }catch(Exception ignored){return false;}}
 static boolean variantCompatible(String game,String a,String b){try{
  JSONObject left=NormalizedEvidenceV344.variant(game,a),right=NormalizedEvidenceV344.variant(game,b);
  for(JSONObject v:new JSONObject[]{left,right}){
   if(v.optBoolean("uncertain")||"CONFLICT".equals(v.optString("status")))return false;
   JSONArray forbidden=v.optJSONArray("forbidden");if(forbidden!=null&&forbidden.length()>0)return false;
  }
  if(CatalogSearchV349.norm(a).equals(CatalogSearchV349.norm(b)))return true;
  if(a.trim().isEmpty()||b.trim().isEmpty())return false;
  boolean anchor=false;
  for(String key:new String[]{"finish","pattern","artwork","edition","shadowless","stamp","parallel","color","rarity"}){
   String x=left.optString(key),y=right.optString(key);
   if(!x.isEmpty()&&!y.isEmpty()&&!x.equals(y))return false;
   if(!key.equals("finish")&&!key.equals("rarity")&&!x.equals(y))return false;
   if((key.equals("artwork")||key.equals("finish"))&&!x.isEmpty()&&x.equals(y))anchor=true;
  }
  String eventA=EventReadingV358.read(a),eventB=EventReadingV358.read(b);
  if(!eventA.equals(eventB))return false;
  for(JSONObject v:new JSONObject[]{left,right}){
   String rest=v.optString("unparsed").replaceAll("\\b(?:textured|texture|regular|standard)\\b","").replaceAll("[\\s/\\-]","");
   if(!rest.isEmpty())return false;
  }
  // This permits an additional observed foil/texture description on the same
  // artwork. It grants estimate scope only and never establishes exact print.
  return anchor;
 }catch(Exception ignored){return false;}}
 static boolean currentQuote(JSONObject r,JSONObject h,JSONObject q){
  return r.optString("scan_id").equals(q.optString("scan_id"))&&h.optString("original_sha256").equals(q.optString("original_sha256"))
   &&sameScope(o(q,"identity_snapshot"),o(h,"target"));
 }
 static JSONObject existingQuote(JSONObject r,JSONObject h)throws Exception{
  JSONObject target=o(h,"target"),row=o(h,"row"),reference=o(h,"price_reference_row");
  JSONObject audit=o(o(r,ControllerCompletionV358.KEY),"unverified_market_audit");
  for(JSONObject q:new JSONObject[]{o(o(r,"market_presentation"),"current"),o(audit,"current_quote"),o(o(r,"result"),"market").optJSONObject("source")}){
   if(q==null||aiQuote(q)||!quoteScope(q,target))continue;
   if(!currentQuote(r,h,q))continue;
   String id=q.optString("catalog_id",q.optString("blueprint_id"));
   if(id.isEmpty()||!id.equals(row.optString("id",h.optString("catalog_id")))&&!id.equals(reference.optString("id")))continue;
   return cp(q);
  }
  return new JSONObject();
 }
 /** Kept for binary compatibility; AI estimates remain dormant. */
 static JSONObject primaryEstimate(JSONObject r,JSONObject h)throws Exception{return new JSONObject();}
 /** Revalidate native acquisition evidence; never bind an arbitrary old amount. */
 static JSONObject nativeCardTraderQuote(JSONObject r,JSONObject target)throws Exception{
  JSONObject trace=o(r,"cardtrader_identity_closure_v317");String id=trace.optString("blueprint_id");
  if(id.isEmpty()||r.optString("scan_id").isEmpty()||!r.optString("scan_id").equals(trace.optString("scan_id"))
    ||!hash(ObservedIdentityV309.current(r)).equals(trace.optString("initial_sha256")))return new JSONObject();
  JSONObject catalog=o(trace,"catalog_identity"),bp=o(catalog,"blueprint"),exp=o(catalog,"expansion");
  JSONObject raw=ControllerV348.original(r);
  if(!id.equals(bp.optString("id"))||!trace.optString("expansion_id").equals(exp.optString("id"))
    ||!bp.optString("expansion_id").equals(exp.optString("id"))||!bp.optString("game_id").equals(exp.optString("game_id"))
    ||!CanonicalIdentityV79.subjectMatches(target,bp.optString("name")))return new JSONObject();
  String release=CatalogSearchV349.norm(target.optString("set")),expansion=CatalogSearchV349.norm(exp.optString("name"));
  if(release.startsWith("pokemon "))release=release.substring(8);
  if(expansion.isEmpty()||!release.equals(expansion))return new JSONObject();
  String number=ReferenceBridgeV298.printedNumber(target,bp);
  if(!sameNumber(target.optString("card_number"),number)||!CatalogDecisionV345.num(number).optBoolean("complete_fraction"))return new JSONObject();
  JSONObject comparisonRow=new JSONObject().put("product-name",bp.optString("name")+" "+bp.optString("version"))
   .put("console-name",exp.optString("name")).put("variant",o(bp,"fixed_properties").optString("pokemon_rarity"));
  if(!IdentityHypothesisV359.priceCriticalResolved(raw,target,comparisonRow,new JSONObject()))return new JSONObject();
  if(!CardTraderV73.blueprintReason(target,bp).isEmpty())return new JSONObject();
  boolean acquired=false;JSONArray requests=r.optJSONArray("requests");
  for(int i=0;requests!=null&&i<requests.length();i++){
   JSONObject req=requests.optJSONObject(i);if(req==null)continue;
   if("cardtrader".equals(req.optString("provider"))&&req.optInt("http_status")==200
     &&req.optString("endpoint").matches(".*[/]marketplace/products[?].*\\bblueprint_id="+id+"(?:&.*)?$"))acquired=true;
  }
  if(!acquired)return new JSONObject();
  JSONObject audit=o(o(r,ControllerCompletionV358.KEY),"unverified_market_audit");
  for(JSONObject source:new JSONObject[]{o(r,"cardtrader_active"),o(o(r,"market_presentation"),"current"),o(audit,"current_quote"),o(audit,"cardtrader_active")}){
   if(!"cardtrader".equals(source.optString("provider"))||!"OK".equals(source.optString("status"))||!positive(source.optDouble("amount",0))||aiQuote(source))continue;
   if(source.optLong("retrieved_at",0)<scanStarted(r))continue;
   if(source.has("scan_id")&&!r.optString("scan_id").equals(source.optString("scan_id")))continue;
   if(source.has("original_sha256")&&!hash(raw).equals(source.optString("original_sha256")))continue;
   if(source.has("identity_snapshot")&&!sameScope(o(source,"identity_snapshot"),target))continue;
   if(!id.equals(o(o(source,"catalog_identity"),"blueprint").optString("id")))continue;
   JSONArray rows=source.optJSONArray("rows");if(rows==null||rows.length()==0)continue;
   String wanted=LanguageV100.normalize(target.optString("language")),state=target.optString("state","RAW");
   boolean valid=true;double sum=0;java.util.Set<String> sellers=new java.util.HashSet<String>();
   for(int i=0;i<rows.length();i++){
    JSONObject row=rows.optJSONObject(i);if(row==null){valid=false;break;}
    JSONObject props=o(row,"properties");String seller=row.optString("seller_id");
    if(!id.equals(row.optString("blueprint_id"))||!wanted.equals(LanguageV100.normalize(row.optString("language")))
      ||!state.equals(row.optString("reference_state"))||!"EUR".equals(row.optString("currency"))
      ||!"EXACT".equals(row.optString("comparison_status"))||!positive(row.optDouble("amount",0))
      ||seller.isEmpty()||!sellers.add(seller)||props.optBoolean("signed")||props.optBoolean("altered")){valid=false;break;}
    if(state.equals("RAW")&&(!row.has("provider_graded")||row.optBoolean("provider_graded")
      ||!props.optString("condition").matches("Mint|Near Mint"))){valid=false;break;}
    if(state.equals("SLAB")&&!ChartingV54.gradeMatches(target,row.optString("reference_grader"),row.optString("reference_grade"))){valid=false;break;}
    sum+=row.optDouble("amount");
   }
   if(!valid||!"EUR".equals(source.optString("currency"))||Math.abs(rounded(sum/rows.length())-source.optDouble("amount"))>0.005)continue;
   JSONObject q=cp(source);
   q.put("scan_id",r.optString("scan_id")).put("original_sha256",hash(raw)).put("identity_snapshot",cp(target))
    .put("state",state).put("grader",target.optString("grader")).put("grade",target.optString("grade"))
    .put("catalog_id",id).put("blueprint_id",id).put("source_bound",true).put("model_only_estimate",false)
    .put("native_provider_binding",true).put("binding_basis","CURRENT_PHOTO_BLUEPRINT_AND_HTTP_OFFERS")
    .put("reference_language",wanted).put("card_language",wanted).put("condition_scope",source.optString("raw_condition_scope"))
    .put("qualification",source.optString("qualification")+" Prezzi richiesti per la stessa scheda e lingua; autenticità non certificata.");
   return q;
  }
  return new JSONObject();
 }
 static JSONObject nativeCardTrader(JSONObject r,JSONObject target)throws Exception{
  JSONObject q=nativeCardTraderQuote(r,target);if(q.length()==0)return new JSONObject();
  JSONObject catalog=o(q,"catalog_identity"),bp=o(catalog,"blueprint");
  return new JSONObject().put("id",q.optString("catalog_id")).put("provider","cardtrader").put("native_provider_binding",true)
   .put("product-name",bp.optString("name")+" "+bp.optString("version")).put("console-name",o(catalog,"expansion").optString("name"))
   .put("url",q.optString("url")).put("quote",q);
 }
 /** Runs on the native provider callback, before terminal projection. */
 static void captureCardTrader(JSONObject r)throws Exception{
  if(r==null)return;
  try{JSONObject q=nativeCardTraderQuote(r,IdentityHypothesisV359.initial(r));if(q.length()>0)r.put("cardtrader_active",q);}
  catch(Exception invalidProviderEvidence){r.put("cardtrader_binding_v360",new JSONObject().put("status","REJECTED_INVALID_EVIDENCE").put("error_type",invalidProviderEvidence.getClass().getSimpleName()));}
 }
 static long scanStarted(JSONObject r){
  long numeric=r.optLong("created_at",0);if(numeric>0)return numeric;
  try{return new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",java.util.Locale.ROOT).parse(r.optString("created_at")).getTime();}
  catch(Exception missingTimestamp){return Long.MAX_VALUE;}
 }
 static boolean aiQuote(JSONObject q){return q.optBoolean("model_only_estimate")||q.optString("kind").startsWith("ai_")||q.optString("basis").contains("MODEL_ESTIMATE")||"MODEL_ESTIMATE".equals(q.optString("catalog_source"));}
 static void disableAi(JSONObject r)throws Exception{
  if(r==null)return;
  r.put("ai_estimate",new JSONObject().put("status","DISABLED_USER_POLICY").put("enabled",false).put("policy_revision",360));
  JSONObject presentation=o(r,"market_presentation"),market=o(o(r,"result"),"market");
  if(aiQuote(o(presentation,"current")))presentation.put("current",JSONObject.NULL);
  if(aiQuote(o(market,"source"))||market.optString("valuation_type").startsWith("ai_")){
   market.put("current_estimate",JSONObject.NULL).put("source",JSONObject.NULL).put("valuation_type","UNAVAILABLE_AI_DISABLED");
   market.remove("low");market.remove("high");pricePolicy(r,false,"AI_DISABLED_USER_POLICY");
  }
 }
 static void pricePolicy(JSONObject r,boolean available,String basis)throws Exception{
  JSONObject p=o(r,"price_policy_v231");p.put("has_price",available).put("selected_basis",basis).put("ai_estimates_enabled",false).put("policy_revision",360);r.put("price_policy_v231",p);
 }
 static JSONObject primaryIdentity(JSONObject raw)throws Exception{
  JSONObject id=ObservationGraphV348.id(raw);
  return new JSONObject().put("subject",id.optString("subject",id.optString("subject_name"))).put("year",id.optString("year"))
   .put("set",id.optString("set",id.optString("set_name"))).put("card_number",id.optString("card_number"))
   .put("variant",id.optString("variant",id.optString("variant_or_parallel")))
   .put("game",raw.optString("game"))
   .put("language",raw.optString("language",raw.optString("card_language"))).put("state",raw.optString("state","RAW"))
   .put("grader",raw.optString("grader")).put("grade",raw.optString("grade")).put("grade_qualifier",raw.optString("grade_qualifier"));
 }
 static JSONObject quote(JSONObject r,JSONObject h)throws Exception{
  if(!bound(r,h))return new JSONObject();
  JSONObject q=existingQuote(r,h);
  if(q.length()==0&&"cardtrader".equals(h.optString("provider")))q=nativeCardTraderQuote(r,o(h,"target"));
  JSONObject candidate=catalogQuote(r,h,o(h,"row"));
  if(candidate.length()==0)candidate=catalogQuote(r,h,o(h,"price_reference_row"));
  // Existing provider offers have priority over a different-language catalogue.
  if(candidate.length()>0&&(q.length()==0||sourcePriority(candidate)<sourcePriority(q)))q=candidate;
  if(aiQuote(q))return new JSONObject();
  if(q.length()==0)return q;
  q.put("identity_status","PROVISIONAL").put("provisional_identity",true).put("exact_identity_bound",false)
   .put("probable_identity_catalog_id",h.optString("catalog_id")).put("probable_identity_provider",h.optString("provider"))
   .put("confidence","LOW").put("scan_id",r.optString("scan_id")).put("original_sha256",h.optString("original_sha256"))
   .put("identity_snapshot",cp(o(h,"target")));
  if(!q.optBoolean("model_only_estimate")&&(!q.optString("catalog_id").equals(h.optString("catalog_id"))||!"pricecharting".equals(h.optString("provider")))){
   q.put("price_reference_only",true).put("price_reference_basis",h.optString("price_reference_basis","CURRENT_SELECTED_PROBABLE_REFERENCE"));
   q.put("qualification",q.optString("qualification")+" Prezzo riferito alla scheda di catalogo probabile, senza equivalenza esatta certificata tra i cataloghi.");
  }
  if(!q.optString("qualification").contains("identità più probabile"))q.put("qualification",q.optString("qualification")+" Stima per l'identità più probabile; stampa esatta non confermata.");
  return q;
 }
 static int sourcePriority(JSONObject q){
  boolean same=q.optString("card_language").equals(q.optString("reference_language"))&&!q.optString("reference_language").isEmpty();
  boolean catalogue="cardtrader".equals(q.optString("provider"))||q.optString("catalog_source").startsWith("PRICECHARTING");
  return same&&catalogue?0:"ebay".equals(q.optString("provider"))?1:catalogue?2:3;
 }
 static boolean publish(JSONObject r,JSONObject h)throws Exception{
  disableAi(r);
  JSONObject q=quote(r,h);if(q.length()==0){pricePolicy(r,false,"NO_COMPATIBLE_MARKET_SOURCE");return false;}
  JSONObject decision=new JSONObject().put("scan_id",r.optString("scan_id")).put("original_sha256",h.optString("original_sha256"))
   .put("hypothesis_catalog_id",h.optString("catalog_id")).put("hypothesis_provider",h.optString("provider"))
   .put("target",cp(o(h,"target"))).put("quote",cp(q)).put("exact_identity_bound",false).put("extra_api_calls",0);
  r.put(KEY,new JSONObject().put("decision",decision).put("decision_sha256",hash(decision)));
  JSONObject presentation=o(r,"market_presentation"),result=o(r,"result"),market=o(result,"market");
  presentation.put("current",q);r.put("market_presentation",presentation);
  market.put("currency",q.optString("currency")).put("current_estimate",q.optDouble("amount"))
   .put("valuation_type",q.optString("kind","probable_identity_estimate")).put("source",q).put("exact_comps",new JSONArray());
  result.put("market",market);r.put("result",result);
  JSONArray sources=result.optJSONArray("sources");if(sources==null)sources=new JSONArray();
  String url=q.optString("url");
  // Keep an explicit source link; this is an estimate reference, not a seal.
  if(!url.isEmpty()){sources=new JSONArray();sources.put(new JSONObject().put("id","probable-price-"+q.optString("catalog_id")).put("title","Prezzo di riferimento · identità probabile").put("url",url));}
  result.put("sources",sources);
  JSONObject reviewer=o(r,ReviewerV354.KEY);reviewer.put("quote","AVAILABLE_PROVISIONAL");r.put(ReviewerV354.KEY,reviewer);
  pricePolicy(r,true,q.optString("provider","pricecharting"));
  return true;
 }
}
