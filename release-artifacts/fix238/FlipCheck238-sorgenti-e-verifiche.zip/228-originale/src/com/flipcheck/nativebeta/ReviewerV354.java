package com.flipcheck.nativebeta;
import org.json.*;

/** One decision, separate catalogue/quote outcomes. Legacy finish callbacks are
 * publication adapters only: they cannot classify or reopen an identity. */
final class ReviewerV354 {
 static final String KEY="reviewer_v354";
 static JSONObject o(JSONObject r,String k){return CatalogEvidenceV150.obj(r,k);}
 static boolean closed(JSONObject r){return r!=null&&ControllerTerminalV351.active(r);}
 static void publish(JSONObject r)throws Exception{
  if(r==null)return;
  if(!r.has(ControllerV348.KEY)||o(r,"result").length()==0){ControllerCompletionV358.publish(r);return;}
  boolean done=closed(r)||ControllerV348.accepted(r);
  String status=done?"RESOLVED":"UNRESOLVED";
  JSONObject result=o(r,"result"),verification=o(r,"verification");
  result.put("status",status).put("identity_status",status).put("identity_verified",done);
  verification.put("status",status).put("identity_status",status);
  r.put("result",result).put("verification",verification).put("identity_status",status).put("identity_model_confirmed",done);
  if(done){
   result.put("next_photo_request","");
   JSONObject check=o(result,"resolution_check");check.put("identity_resolved",true);result.put("resolution_check",check);
  }
  JSONObject match=o(r,"catalog_match"),quote=o(o(r,"market_presentation"),"current");
  boolean linked=FinalIdentityV319.active(r)||ControllerTerminalV351.linked(r);
  // Old price consumers read this flag. It is a projection of the reviewer's
  // actual bound catalogue proof, never a second source of identity authority.
  verification.put("identity_catalog_verified",done&&linked);
  r.put("identity_recognized",done);
  JSONObject audit=o(r,KEY);audit.put("authority","SINGLE_REVIEWER").put("scan_id",r.optString("scan_id"))
   .put("identity",done?"CLOSED":"NEEDS_EVIDENCE").put("catalogue",linked?"LINKED":"PENDING")
   .put("quote",quote.has("amount")?"AVAILABLE":"UNAVAILABLE").put("legacy_reclassification_enabled",false)
   .put("identity_finish_cascade_enabled",false).put("price_changes_identity",false).put("history_changes_identity",false);
  r.put(KEY,audit);
  if(quote.length()>0)quote.put("identity_status",status).put("provisional_identity",!done);
  ReviewTransportV357.publish(r);
  ControllerCompletionV358.publish(r);
 }
 /** Retained ABI for old callers; no legacy decision body is executed. */
 static void legacyFinish(JSONObject r)throws Exception{publish(r);}
}
