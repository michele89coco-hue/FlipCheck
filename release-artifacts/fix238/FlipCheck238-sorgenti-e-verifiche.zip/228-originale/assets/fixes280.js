/* Present native terminal identity and bound probable-price references. Never creates an exact seal. */
(()=>{
 const norm=x=>String(x||'').trim().toUpperCase();
 const hash=x=>/^[a-f0-9]{64}$/i.test(String(x||''));
 function bound(rec,evidence){
  const original=rec?.controller_v348?.original_sha256;
  return !!rec?.scan_id&&evidence?.scan_id===rec.scan_id&&hash(original)&&evidence.original_sha256===original;
 }
 function completion(rec){
  const c=rec?.controller_completion_v358?.decision;
  return /^(DONE|ERROR|MARKET_ERROR)$/.test(rec?.state||'')&&rec.identity_processing_complete===true&&c?.completion_status==='COMPLETE'&&bound(rec,c)?c:null;
 }
 function probableQuote(rec){
  const c=completion(rec),box=rec?.price_hypothesis_v359,d=box?.decision,q=d?.quote,h=c?.hypothesis;
  if(!c||c.outcome==='VERIFIED_EXACT'||!hash(box?.decision_sha256)||!bound(rec,d)||!bound(rec,q)||!bound(rec,h))return null;
  if(q.model_only_estimate===true||/^ai_/.test(q.kind||'')||/MODEL_ESTIMATE/.test(q.basis||''))return null;
  if(!h.provider||!h.catalog_id||String(d.hypothesis_catalog_id||'')!==String(h.catalog_id||'')||d.hypothesis_provider!==h.provider||String(q.probable_identity_catalog_id||'')!==String(h.catalog_id||'')||q.probable_identity_provider!==h.provider)return null;
  if(!Number.isFinite(q.amount)||q.amount<=0||q.exact_identity_bound!==false||q.provisional_identity!==true)return null;
  const active=rec?.market_presentation?.current;
  if(!active||active.scan_id!==q.scan_id||active.original_sha256!==q.original_sha256||String(active.catalog_id||'')!==String(q.catalog_id||'')||active.url!==q.url||active.amount!==q.amount||active.currency!==q.currency)return null;
  for(const field of ['subject','card_number','language','state','grader','grade','variant','year','set'])if(String(d.target?.[field]||'')!==String(c.target?.[field]||''))return null;
  return q;
 }
 function sourceId(url){return String(url||'').match(/^https:\/\/(?:www\.)?(?:pricecharting|sportscardspro)\.com\/game\/(\d+)\/?$/)?.[1]||'';}
 function probableAnchor(rec){
  const q=probableQuote(rec);if(!q||q.source_bound!==true||!/^\d+$/.test(String(q.catalog_id||''))||sourceId(q.url)!==String(q.catalog_id))return null;
  const h=completion(rec).hypothesis,row=[h.row,h.price_reference_row].find(r=>String(r?.id||'')===String(q.catalog_id));
  if(!row)return null;
  return {...q,provider:'pricecharting',reference_only:true,exact_catalog_binding:false,annual_sales_volume:row['sales-volume']??row.annual_sales_volume};
 }
 function probableRecord(rec){const d=rec?.controller_completion_v358?.decision,q=rec?.market_presentation?.current;return !!d?.outcome&&d.outcome!=='VERIFIED_EXACT'||q?.provisional_identity===true||q?.kind==='probable_identity_estimate';}
 const anchorBefore=marketAnchor;marketAnchor=rec=>{
  return probableRecord(rec)?probableAnchor(rec):anchorBefore(rec);
 };
 function instrumentRecord(rec){
  if(!probableRecord(rec))return rec;
  const a=probableAnchor(rec),page=rec?.catalog_page,valid=!!a&&page?.scan_id===rec.scan_id&&String(page.catalog_id||'')===String(a.catalog_id)&&(!page.url||sourceId(page.url)===String(a.catalog_id));
  // Old metric references can describe another language or printing. Keep only this quote's reference.
  return {...rec,market_metrics_reference_v279:undefined,catalog_page:valid?{...page,instrument_reference_v279:undefined}:undefined};
 }
 const instrumentBefore=marketInstrumentReference;
 marketInstrumentReference=function(rec,...args){return instrumentBefore.call(this,instrumentRecord(rec),...args);};
 function resolved(rec){
  const c=completion(rec);if(c)return c.outcome==='VERIFIED_EXACT'&&c.identity_verified===true&&c.exact_printing_verified===true;
  if(rec?.controller_completion_v358?.decision&&rec.identity_processing_complete===true)return false;
  if(!rec?.result?.identity||rec.identity_recognized===false||rec.catalog_resolution_required===true||rec.presentation_policy?.identity_review_required===true||rec.result.identity.printing_review_required===true||!!rec.result.next_photo_request)return false;
  const states=[rec.identity_status,rec.result.identity_status,rec.verification?.identity_status,rec.identity_closure_basis].map(norm);
  if(states.some(x=>/^(UNRESOLVED|PARTIAL|NEEDS_REVIEW|AMBIGUOUS|CONFLICT|UNKNOWN)$/.test(x))||rec.identity_status_alignment_v242?.identity_resolved===false)return false;
  return states.includes('RESOLVED')||rec.result.status==='RESOLVED';
 }
 const liquidityBefore=marketLiquidity;
 function annual(rec){
  if(!resolved(rec)&&!probableAnchor(rec))return null;
  const a=marketAnchor(rec);if(!a||!/^\d+$/.test(String(a.catalog_id))||!/^https:\/\/(?:www\.)?(pricecharting|sportscardspro)\.com\//.test(a.url||''))return null;
  let count=a.annual_sales_volume,date=null;
  // The recorded API product is used only when it is the same validated instrument reference.
  for(const key of ['charting_result','charting_selection']){
   const s=rec[key],p=s?.raw_response;
   if(s?.status==='OK'&&String(p?.id)===String(a.catalog_id)){
    if(p['sales-volume']!==undefined)count=p['sales-volume'];date=s.retrieved_at||null;break;
   }
  }
  if(!/^\d+$/.test(String(count)))return null;
  const n=Number(count);if(!Number.isSafeInteger(n)||n<=0)return null;
  return {count:n,period:'year',monthly_equivalent:n/12,scope:'ALL_CONDITIONS',source_url:a.url,retrieved_at:date,catalog_id:String(a.catalog_id)};
 }
 marketLiquidity=function(rec){
  const prior=liquidityBefore(instrumentRecord(rec));if(prior.level!==null)return prior;
  const s=annual(rec);if(!s)return prior;
  const n=s.monthly_equivalent;
  return {label:n<2?'Bassa':n<12?'Media':'Alta',level:n<2?0:n<12?1:2,text:s.count.toLocaleString('it-IT')+' vendite/anno',source:s,aggregate280:true};
 };
 const labelBefore=marketReferenceLabel;
 marketReferenceLabel=function(rec,kind='series',days=365){
  if(kind==='volume'&&marketLiquidity(rec).aggregate280)return ['Volume complessivo · tutti i gradi',marketInstruments279.language(rec)].filter(Boolean).join(' · ');
  return probableRecord(rec)?['Riferimento · identità probabile',labelBefore(instrumentRecord(rec),kind,days)].filter(Boolean).join(' · '):labelBefore(rec,kind,days);
 };
 const priceLabelsBefore=marketPresentation218.labels;
 marketPresentation218.labels=function(q={}){
  const prior=priceLabelsBefore(q);
  if(q.kind!=='probable_identity_estimate'&&q.provisional_identity!==true)return prior;
  const provider=/pricecharting\.com|sportscardspro\.com/.test(q.url||'')?'PriceCharting':/cardtrader\.com/.test(q.url||'')?'CardTrader':'Fonte di riferimento';
  return {...prior,title:q.provider==='cardtrader'?'Prezzo richiesto · CardTrader':'Prezzo di riferimento',caption:[provider,'riferimento probabile'].join(' · '),detail:q.qualification||prior.detail};
 };
 const sheetBefore=showMarketLiquidity;
 showMarketLiquidity=function(){
  const rec=state.record,info=marketLiquidity(rec);if(!info.aggregate280)return sheetBefore();
  openSheet('Liquidità · riferimento complessivo');const body=$('sheetBody');
  body.append(el('h3',marketReferenceLabel(rec,'volume')),marketGauge(info),el('h2',info.label),el('p',info.text));
  body.append(el('p','Volume annuo del prodotto riportato da PriceCharting, senza distinzione tra RAW, società e gradi. Indica l’attività generale su questa carta; non misura la liquidità del tuo specifico grado né garantisce un tempo di vendita.','hint'));
  body.append(el('p','Scala: bassa sotto 2 vendite/mese; media da 2 a meno di 12; alta da 12. Per questo riferimento si usa il volume annuo diviso 12.','hint'));
  if(info.source.retrieved_at)body.append(el('p','Dato acquisito il '+new Date(info.source.retrieved_at).toLocaleDateString('it-IT'),'hint'));
  body.append(hybridSourceButton(info.source.source_url));
 };
 function decorate(){
  const rec=state.record;if(!rec?.result||cropPreviewActive)return;
  const isResolved=resolved(rec),finished=completion(rec),provisional=finished&&!isResolved;
  const terminalLabel=finished?.outcome==='NOT_IDENTIFIED'?'Non identificabile':finished?.outcome==='OBSERVED_ONLY'?'Elementi rilevati':'Identità probabile';
  const terminalNote=finished?.outcome==='NOT_IDENTIFIED'?'Analisi conclusa con gli elementi disponibili.':finished?.outcome==='OBSERVED_ONLY'?'Analisi conclusa; edizione e variante non confermate.':'Analisi conclusa; stampa esatta non confermata.';
  const probableReference=finished?.reference_candidate,referenceText=probableReference?['Riferimento probabile: '+probableReference.title,probableReference.set,probableReference.release_date].filter(Boolean).join(' · '):'';
  const badge=document.querySelector('.rr-verified');if(badge){badge.classList.toggle('is-partial',!isResolved);const value=badge.querySelector('strong');if(value)value.textContent=isResolved?'Confermata':provisional?terminalLabel:'Da verificare';const p=badge.querySelector('p');if(p)p.textContent=isResolved?'Carta riconosciuta dagli elementi distintivi.':provisional?terminalNote:'Identità da completare: apri i dettagli.';}
  const verified=[...document.querySelectorAll('.rr-sources button')].find(b=>b.dataset.identityBadge359==='true'||/^(Identificata|Identità da verificare|Identità probabile|Elementi rilevati|Non identificabile)$/.test(b.textContent.trim()));
  if(verified){verified.hidden=false;verified.classList.toggle('identity-pending280',!isResolved);verified.setAttribute('aria-label',isResolved?'Identità confermata: apri dettagli':provisional?terminalLabel+': apri dettagli':'Identità da verificare: apri dettagli');
   verified.dataset.identityBadge359='true';
   const span=verified.querySelector('span');if(span)span.textContent=isResolved?'Identificata':provisional?terminalLabel:'Identità da verificare';
   const icon=verified.querySelector('svg');if(icon)icon.style.display=isResolved?'':'none';
  }
  if(isResolved){const note=document.querySelector('.rr-state-note');if(note){const q=rec.market_presentation?.current;note.textContent=q?.provisional_variant?q.qualification||'Valore indicativo: apri i dettagli della fonte.':'';note.hidden=!note.textContent;}}
  if(!isResolved){const note=document.querySelector('.rr-state-note');if(note){note.textContent=provisional?[(rec.result.resolution_check?.closure_reason||terminalNote),referenceText].filter(Boolean).join(' '):rec.result.resolution_check?.technical_error?(rec.result.resolution_check.closure_reason||'Confronto interrotto: riprova la scansione.'):(rec.result.next_photo_request||'Identità da verificare: il collegamento alla scheda esatta non è stato completato.');note.hidden=false;}}
  if(provisional)for(const chip of document.querySelectorAll('.chip.status'))chip.textContent=terminalLabel;
  if(provisional){
   const id=finished.target||rec.result.identity||{},line=[id.year&&!String(id.set||'').includes(String(id.year))?id.year:'',id.display_set||id.set,id.insert,id.card_number?'#'+String(id.card_number).replace(/^#/,''):''].filter(Boolean).join(' · '),set=$('set');if(set)set.textContent=line;
   const q=probableQuote(rec);if(q){const labels=marketPresentation218.labels(q),value=$('valueLabel'),trend=$('rarokTrend174'),range=$('range');if(value)value.textContent=labels.title;if(trend){const span=trend.querySelector('span');if(span)span.textContent=labels.caption;trend.title=labels.detail;}if(range)range.textContent='Fonte di mercato · identità probabile';}
  }
  const info=marketLiquidity(rec),gauge=$('liquidityPreview');
  if(gauge&&(info.aggregate280||provisional)){const label=gauge.querySelector('.instrument-label');if(label)label.textContent='Liquidità · riferimento';gauge.title=info.aggregate280?'Volume complessivo del prodotto, senza distinzione di grado':'Liquidità del riferimento probabile';if(info.aggregate280)gauge.onclick=showMarketLiquidity;}
  if(gauge&&info.level===null)for(const n of gauge.querySelectorAll('.reference279'))n.remove();
  const chart=$('chartPreview'),page=rec.catalog_page;
  if(chart&&provisional){const label=chart.querySelector('.instrument-label');if(label)label.textContent='Variazione · riferimento';chart.title='Storico della scheda di riferimento; stampa esatta non confermata';}
  if(!chart||!page?.error)return;
  const empty=chart.querySelector('.instrument-empty'),a=marketAnchor(rec),denied=page.load_status_v279==='ACCESS_DENIED';
  // No series has been loaded: do not label absent data as if it belonged to a grade.
  for(const n of chart.querySelectorAll('.reference279'))n.remove();
  if(a?.url&&(denied||page.terminal_identity)){
   if(empty)empty.textContent=denied?'Storico non accessibile dalla fonte':'Storico del riferimento non caricato';
   const caption=chart.querySelector('.instrument-caption');if(caption)caption.textContent='Apri la scheda su PriceCharting ↗';
   chart.disabled=false;chart.onclick=()=>hybridSourceButton(a.url).click();
   chart.setAttribute('aria-label','Storico non accessibile: apri la scheda della fonte');
  }else if(!a){
   if(empty)empty.textContent=isResolved?'Storico non disponibile':finished?'Storico non collegato':'Storico in attesa di identità verificata';
   const caption=chart.querySelector('.instrument-caption');if(caption)caption.textContent=isResolved?'Nessuno storico collegato a questa carta':'Nessuna scheda esatta collegata';
   chart.disabled=true;chart.onclick=null;
  }
 }
 const renderBefore=renderResult;renderResult=function(...args){const result=renderBefore.apply(this,args);decorate();return result;};
 const instrumentsBefore=renderMarketInstruments;renderMarketInstruments=function(...args){const result=instrumentsBefore.apply(this,args);decorate();return result;};
 const pageBefore=window.receiveMarketPage;window.receiveMarketPage=function(...args){
  const rec=state.record,c=completion(rec),page=args[0];
  if(probableRecord(rec)){
   const a=probableAnchor(rec),ref=page?.instrument_reference_v279;
   if(!a||page?.scan_id!==rec.scan_id||String(page.catalog_id||'')!==String(a.catalog_id)||page.url&&sourceId(page.url)!==String(a.catalog_id)||page.original_sha256&&page.original_sha256!==c.original_sha256||ref&&String(ref.catalog_id||'')!==String(a.catalog_id)||ref?.url&&sourceId(ref.url)!==String(a.catalog_id))return;
  }
  const result=pageBefore.apply(this,args);decorate();return result;
 };
 const tabBefore=showTab;showTab=function(...args){const result=tabBefore.apply(this,args);decorate();return result;};
 window.addEventListener('resize',()=>requestAnimationFrame(decorate));
  window.fixes280={resolved,annual,completion,probableQuote,probableAnchor,instrumentRecord};
})();
